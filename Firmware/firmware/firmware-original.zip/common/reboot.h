/////////////////////////////////////////////////////////////
//
//  reboot.h
//
//  Reboot utility
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef reboot_h
#define reboot_h


void reboot();


#endif
