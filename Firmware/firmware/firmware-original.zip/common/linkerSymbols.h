#ifndef linkerSymbols_h
#define linkerSymbols_h

///////////////////////////////////////
// Externals from linker

extern void*  __scratch_start;
extern void*  __scratch_end;
extern uint32 __scratch_size;

#endif
