/////////////////////////////////////////////////////////////
//
//  eeprom.h
//
//  Plate Cycler SPI EEPROM Driver
//
//  Copyright 2008-2010 Idaho Technology
//  Created by David Hawks

#include <types.h>
#include <spi.h>

typedef void (*SpiSetAddrPtr)(volatile uint32*, uint32);

typedef struct
{
    SpiInterface*    spiInterface;
    volatile uint32* spiAddrReg;
    int              spiSelectAddr;
    int              spiDeselectAddr;
    SpiSetAddrPtr    spiSetAddr;
} Eeprom;


void   eepromInterfaceInit(Eeprom* eeprom, SpiInterface* spiInterface,
                           volatile uint32* spiAddrReg,
                           int spiSelectAddr, int spiDeselectAddr,
                           SpiSetAddrPtr spiSetAddrPtr);
uint8  getEepromStatus(Eeprom* eeprom);
void   readEeprom(Eeprom* eeprom, uint16 address, uint8* buffer, uint8 count);
uint8  readEepromUint8(Eeprom* eeprom, uint16 address);
uint16 readEepromUint16(Eeprom* eeprom, uint16 address);
uint32 readEepromUint32(Eeprom* eeprom, uint16 address);
void   writeEeprom(Eeprom* eeprom, uint16 address, uint8* buffer, uint8 count);
void   writeEepromUint8(Eeprom* eeprom, uint16 address, uint8 value);
void   writeEepromUint16(Eeprom* eeprom, uint16 address, uint16 value);
void   writeEepromUint32(Eeprom* eeprom, uint16 address, uint32 value);
void   writeEepromCRC(Eeprom* eeprom, uint16 address, uint16 size);
bool   validateEepromCRC(Eeprom* eeprom, uint16 address, uint16 size);
