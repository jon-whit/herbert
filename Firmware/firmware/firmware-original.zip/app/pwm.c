/////////////////////////////////////////////////////////////
//
//  pwm.c
//
//  PWM Driver
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#include <pwm.h>
#include <xparameters.h>
#include <assert.h>
#include <string.h>
#include <timer.h>
#include <lcd.h>



///////////////////////////////////////////////////
// Constants

#define DEFAULT_PWM_PERIOD_us     100

#define PWM_DIR_POSITIVE          true
#define PWM_DIR_NEGATIVE          false

#define PWM_ALL_ENABLE            0xffffff
#define PWM_ALL_DISABLE           0

#define DEFAULT_LID_PWM_PERIOD_us 1000



///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    volatile uint32 blockPeriod;                            // Block PWM period in clock ticks (32 bits)
    volatile uint32 blockEnable;                            // H-Bridge Enable (24 bits)
    volatile uint32 blockError;                             // H-Bridge Error  (24 bits)
    volatile uint32 blockDutyCycle[PWM_BLOCK_CHANNEL_COUNT];// Block duty cycle in clock ticks (32 bits * 24)
    volatile uint32 lidPeriod;                              // Lid PWM period in clock ticks (32 bits)
    volatile uint32 lidDutyCycle[PWM_LID_CHANNEL_COUNT];    // Lid duty cycle in clock ticks (32 bits * 2)
} PwmRegs;


#define PWM  (*((PwmRegs*)XPAR_PWM_BASEADDR))

typedef struct
{
    unsigned pwmHardwareIndex[PWM_BLOCK_CHANNEL_COUNT];
    bool     pwmInverted;
} PwmMap;



static const PwmMap pwmMaps[pwmMap_typeCount] =
{   // Hardware Index
    //  A1  A2  A3  A4  A5  A6
    //  B1  B2  B3  B4  B5  B6
    //  C1  C2  C3  C4  C5  C6
    //  D1  D2  D3  D4  D5  D6     Inverted
    { {  0,  1,  2,  3,  4,  5,
         6,  7,  8,  9, 10, 11,
        12, 13, 14, 15, 16, 17,
        18, 19, 20, 21, 22, 23 }, false },  // Type 0

    { {  0,  1,  2,  3,  4,  5,
         6,  7,  8,  9, 10, 11,
        12, 13, 14, 15, 16, 17,
        18, 19, 20, 21, 22, 23 }, true  },  // Type 1

    { {  0,  1,  2,  3,  4,  5,
         6,  7,  8,  9, 10, 11,
        12, 13, 14, 15, 16, 17,
        18, 19, 20, 21, 22, 23 }, false },  // Type 2

    { { 23, 22, 21, 20, 19, 18,
        17, 16, 15, 14, 13, 12,
        11,  5, 10,  1,  6,  0,
         3,  9,  4,  7,  2,  8 }, true  }   // Type 3
};



typedef struct
{
    volatile uint32 period_us;
    unsigned        pwmMapType;
} PwmData;



#define PERIOD_TO_TICKS(period)                 (USEC_TO_TICKS((period)) - 1)
#define DUTY_CYCLE_TO_TICKS(period, dutyCycle)  (((int32)PERIOD_TO_TICKS((period))) * (dutyCycle) / 1000)  // Dutycycle is fixed point, tenth percent



///////////////////////////////////////////////////
// Local function prototypes



///////////////////////////////////////////////////
// Local data

static PwmData pwmData;


///////////////////////////////////////////////////
// Interface functions

void pwmInit()
{
    pwmReset();
    
    pwmData.pwmMapType = pwmMap_default;
}



bool pwmProcess(void* unused)
{
    return true;
}



void setPwmMapping(unsigned mapType)
{
    ASSERT(mapType < pwmMap_typeCount);
    pwmData.pwmMapType = mapType;
}



void pwmAbort()
{
    int i;
    
    PWM.blockEnable = PWM_ALL_DISABLE;
    
    for(i = 0; i < PWM_BLOCK_CHANNEL_COUNT; i++)
    {
        PWM.blockDutyCycle[i] = 0;
    }

    for(i = 0; i < PWM_LID_CHANNEL_COUNT; i++)
    {
        PWM.lidDutyCycle[i] = 0;
    }
}


void pwmReset()
{
    pwmData.period_us = DEFAULT_PWM_PERIOD_us;
    PWM.blockPeriod   = PERIOD_TO_TICKS(pwmData.period_us);
    PWM.lidPeriod     = PERIOD_TO_TICKS(DEFAULT_LID_PWM_PERIOD_us);    

    pwmAbort();
}



void setPwmDutyCycle(int channel, int percentDutyCycle)
{
    if(channel >= PWM_FIRST_BLOCK_CHANNEL && channel <= PWM_LAST_BLOCK_CHANNEL)
    {
        ASSERT(percentDutyCycle >= -1000 && percentDutyCycle <= 1000);

        PWM.blockEnable = PWM_ALL_ENABLE;
        
        unsigned index = pwmMaps[pwmData.pwmMapType].pwmHardwareIndex[channel - PWM_FIRST_BLOCK_CHANNEL];
        uint32   value = DUTY_CYCLE_TO_TICKS(pwmData.period_us, percentDutyCycle) * (pwmMaps[pwmData.pwmMapType].pwmInverted ? -1 : 1);
        
        PWM.blockDutyCycle[index] = value;
    }
    else if(channel >= PWM_FIRST_LID_CHANNEL && channel <= PWM_LAST_LID_CHANNEL)
    {
        ASSERT(percentDutyCycle >= 0 && percentDutyCycle <= 1000);

        PWM.blockEnable = PWM_ALL_ENABLE;
        PWM.lidDutyCycle[channel - PWM_FIRST_LID_CHANNEL] = DUTY_CYCLE_TO_TICKS(DEFAULT_LID_PWM_PERIOD_us, percentDutyCycle);
    }
    else
    {
        ASSERT(false); // Bad channel number
    }
}



void setPwmFrequency(int frequency_hz)
{
    if(frequency_hz <= 0 || frequency_hz > 1000000)
    {
        return;
    }
    
    uint32 newPeriod_us = 1000000 / frequency_hz;
    int    i;
    
    for(i = 0; i < PWM_BLOCK_CHANNEL_COUNT; i++)
    {
        PWM.blockDutyCycle[i] = PWM.blockDutyCycle[i] * newPeriod_us / pwmData.period_us;
    }
    
    pwmData.period_us = newPeriod_us;
    PWM.blockPeriod   = PERIOD_TO_TICKS(pwmData.period_us);
}



int getPwmFrequency()
{
    return 1000000 / pwmData.period_us;
}



uint32 getErrorStatus()
{
    return PWM.blockError;
}



///////////////////////////////////////////////////
// Local functions


//TODO: add ISR and handler for error condition


// EOF
