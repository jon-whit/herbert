/////////////////////////////////////////////////////////////
//
//  cache.h
//
//  Processor cache interface
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef cache_h
#define cache_h


void cacheInit();


#endif
