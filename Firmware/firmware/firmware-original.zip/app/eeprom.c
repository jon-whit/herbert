/////////////////////////////////////////////////////////////
//
//  eeprom.c
//
//  Plate Cycler SPI EEPROM Driver
//
//  Copyright 2008-2010 Idaho Technology
//  Created by David Hawks

#include <eeprom.h>
#include <assert.h>
#include <timer.h>
#include <crc32.h>

#include <string.h>


#define TX_TIMEOUT_us                 5000
#define RX_TIMEOUT_us                 10000
#define EEPROM_WRITE_CYCLE_TIME_ms    10

#define EEPROM_BUFFER_SIZE            40
#define EEPROM_DATA_TRANSFER_SIZE     (EEPROM_BUFFER_SIZE - 4)

#define EEPROM_CMD_WREN               0x06
#define EEPROM_CMD_WRDI               0x04
#define EEPROM_CMD_RDSR               0x05
#define EEPROM_CMD_READ               0x03
#define EEPROM_CMD_WRITE              0x02

#define EEPROM_CRC_RETRIES            1


void eepromInterfaceInit(Eeprom* eeprom, SpiInterface* spiInterface,
                         volatile uint32* spiAddrReg,
                         int spiSelectAddr, int spiDeselectAddr,
                         SpiSetAddrPtr spiSetAddr)
{
    ASSERT( eeprom && spiInterface && spiAddrReg && spiSetAddr );

    eeprom->spiInterface    = spiInterface;
    eeprom->spiAddrReg      = spiAddrReg;
    eeprom->spiSelectAddr   = spiSelectAddr;
    eeprom->spiDeselectAddr = spiDeselectAddr;
    eeprom->spiSetAddr      = spiSetAddr;
}


uint8 getEepromStatus(Eeprom* eeprom)
{
    ASSERT(eeprom);

    uint8  writeBuffer[EEPROM_BUFFER_SIZE];
    uint8  readBuffer[EEPROM_BUFFER_SIZE];
    uint16 readCount;


    writeBuffer[0] = EEPROM_CMD_RDSR;
    writeBuffer[1] = 0x00;

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiSelectAddr);

    spiWaitAndStartTransmit(eeprom->spiInterface, writeBuffer, 2, TX_TIMEOUT_us);
    spiWaitAndReadData(eeprom->spiInterface, readBuffer, 2, &readCount, RX_TIMEOUT_us);

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiDeselectAddr);

    if(readCount != 2) return 0; // SPI Read Error
    
    return readBuffer[1];
}


void readEeprom(Eeprom* eeprom, uint16 address, uint8* buffer, uint8 count)
{
    ASSERT(eeprom);
    ASSERT(buffer);
    ASSERT(count <= EEPROM_DATA_TRANSFER_SIZE);

    uint8  writeBuffer[EEPROM_BUFFER_SIZE];
    uint8  readBuffer[EEPROM_BUFFER_SIZE];
    uint16 readCount;

    writeBuffer[0] = EEPROM_CMD_READ;
    writeBuffer[1] = address >> 8;
    writeBuffer[2] = address & 0xff;

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiSelectAddr);

    spiWaitAndStartTransmit(eeprom->spiInterface, writeBuffer, 3 + count, TX_TIMEOUT_us);
    spiWaitAndReadData(eeprom->spiInterface, readBuffer, 3 + count, &readCount, RX_TIMEOUT_us);

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiDeselectAddr);

    memcpy(buffer, &readBuffer[3], count);
}


uint8 readEepromUint8(Eeprom* eeprom, uint16 address)
{
    uint8 value;
    readEeprom(eeprom, address, &value, sizeof(value));
    return value;
}


uint16 readEepromUint16(Eeprom* eeprom, uint16 address)
{
    uint16 value;
    readEeprom(eeprom, address, (uint8*)&value, sizeof(value));
    return value;
}


uint32 readEepromUint32(Eeprom* eeprom, uint16 address)
{
    uint32 value;
    readEeprom(eeprom, address, (uint8*)&value, sizeof(value));
    return value;
}




void writeEeprom(Eeprom* eeprom, uint16 address, uint8* buffer, uint8 count)
{
    ASSERT(eeprom);
    ASSERT(buffer);
    ASSERT(count <= EEPROM_DATA_TRANSFER_SIZE);
    ASSERT((address & 0x3f) + count <= 0x40); //Confirm write won't roll over in the 64-byte page

    uint8 writeBuffer[EEPROM_BUFFER_SIZE];

    writeBuffer[0] = EEPROM_CMD_WREN;
    
    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiSelectAddr);

    spiWaitAndStartTransmit(eeprom->spiInterface, writeBuffer, 1, TX_TIMEOUT_us);
    spiWaitForReady(eeprom->spiInterface, RX_TIMEOUT_us);
    
    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiDeselectAddr);

    writeBuffer[0] = EEPROM_CMD_WRITE;
    writeBuffer[1] = address >> 8;
    writeBuffer[2] = address & 0xff;

    memcpy(&writeBuffer[3], buffer, count);

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiSelectAddr);

    spiWaitAndStartTransmit(eeprom->spiInterface, writeBuffer, 3 + count, TX_TIMEOUT_us);
    spiWaitForReady(eeprom->spiInterface, RX_TIMEOUT_us);

    eeprom->spiSetAddr(eeprom->spiAddrReg, eeprom->spiDeselectAddr);
    
    Timer timer;
    startTimer(&timer, MSEC_TO_TICKS(EEPROM_WRITE_CYCLE_TIME_ms));
    
    while((getEepromStatus(eeprom) & 1) && !timerExpired(&timer))
    { ; } // Wait for write to complete
}



void writeEepromUint8(Eeprom* eeprom, uint16 address, uint8 value)
{
    writeEeprom(eeprom, address, &value, sizeof(value));
}


void writeEepromUint16(Eeprom* eeprom, uint16 address, uint16 value)
{
    writeEeprom(eeprom, address, (uint8*)&value, sizeof(value));
}


void writeEepromUint32(Eeprom* eeprom, uint16 address, uint32 value)
{
    writeEeprom(eeprom, address, (uint8*)&value, sizeof(value));
}


void writeEepromCRC(Eeprom* eeprom, uint16 address, uint16 size)
{
    uint8  buf[size];
    uint8 *bufPtr          = &buf[0];
    CRC32  crcValue        = INITIAL_CRC32_VALUE;
    uint16 remainingSize   = size;

    while(remainingSize >= EEPROM_DATA_TRANSFER_SIZE)
    {
        readEeprom(eeprom, address, bufPtr, EEPROM_DATA_TRANSFER_SIZE);
        bufPtr        += EEPROM_DATA_TRANSFER_SIZE;
        address       += EEPROM_DATA_TRANSFER_SIZE;
        remainingSize -= EEPROM_DATA_TRANSFER_SIZE;
    }

    if(remainingSize)
    {
        readEeprom(eeprom, address, bufPtr, (uint8)remainingSize);
        address += remainingSize;
    }

    crcValue = calcCRC32(crcValue, buf, size - sizeof(CRC32));

    writeEeprom(eeprom, address - sizeof(CRC32),
                (uint8 *)&crcValue, sizeof(CRC32));
}


bool validateEepromCRC(Eeprom* eeprom, uint16 address, uint16 size)
{
    int remainingAttempts = EEPROM_CRC_RETRIES + 1;

    while(remainingAttempts-- > 0)
    {
        uint8   buf[size];
        uint8  *bufPtr           = &buf[0];
        uint16  remainingSize    = size;
        int     currentAddress   = address;

        while(remainingSize >= EEPROM_DATA_TRANSFER_SIZE)
        {
            readEeprom(eeprom, currentAddress, bufPtr, EEPROM_DATA_TRANSFER_SIZE);
            bufPtr         += EEPROM_DATA_TRANSFER_SIZE;
            currentAddress += EEPROM_DATA_TRANSFER_SIZE;
            remainingSize  -= EEPROM_DATA_TRANSFER_SIZE;
        }

        if(remainingSize)
        {
            readEeprom(eeprom, currentAddress, bufPtr, (uint8)remainingSize);
        }

        if(*(CRC32 *)&buf[size-sizeof(CRC32)] ==
           calcCRC32(INITIAL_CRC32_VALUE, buf, size-sizeof(CRC32)))
        {
            return true;
        }
    }

    return false;
}
