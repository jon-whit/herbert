/////////////////////////////////////////////////////////////
//
//  ramp.c
//
//  Plate Cycler temperature ramp generator
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#include <math.h>
#include <string.h>

#include <ramp.h>
#include <assert.h>
#include <os.h>
#include <comm.h>


///////////////////////////////////////////////////
// Constants

#define MIN_SMOOTH_DELTA           ((float)1.0)
#define MIN_SMOOTH_RATE            ((float)0.1)
#define MIN_SMOOTH_TIME            ((float)2.0)
#define MAX_RAMP_POINTS            125000  // 100 degree / 0.1 degree/s * 20 Hz * (2.25 * 2 + 1) = 110000
#define INNER_LOOP_CALCS_PER_CALL  10000

#define DEFAULT_COOLING_TAKE_OFF_TRIM_CRIT ((float)1e-2)
#define DEFAULT_HEATING_TAKE_OFF_TRIM_CRIT ((float)1e-2)
#define DEFAULT_COOLING_SETTLE_TRIM_CRIT   ((float)1e-2)
#define DEFAULT_HEATING_SETTLE_TRIM_CRIT   ((float)1e-2)

enum SmoothingIterations
{
    DEFAULT_COOLING_TAKE_OFF_ITERATIONS = 18,
    DEFAULT_HEATING_TAKE_OFF_ITERATIONS = 18,
    DEFAULT_COOLING_SETTLE_ITERATIONS   = 26,
    DEFAULT_HEATING_SETTLE_ITERATIONS   = 16,
    DEFAULT_FINAL_SMOOTHING_ITERATIONS  = 20
};


///////////////////////////////////////////////////
// Local types and macros

typedef enum
{
    IDLE,
    STARTING,
    SMOOTHING,
    SMOOTHING_TAKE_OFF_CURVE,
    SMOOTHING_SETTLE_CURVE,
    COMBINING_CURVES,
    TRIMMING,
    SMOOTHING_FINAL_CURVE
} RampState;

typedef struct
{
    float takeOff;
    float settle;
} TrimCrit;

typedef struct
{
    float      startTemp;
    float      endTemp;
    float      rampRate;
    float      sampleFrequency;
    float     *ramp;
    int       *rampPoints;
    float      delta;
    bool       cooling;
    RampState  state;
    int        curvePoints;
    float      takeoffRamp[ MAX_RAMP_POINTS ];
    float      settleRamp[ MAX_RAMP_POINTS ];
    void     (*callbackFunc)(int, bool);
    int        callbackRef;
    int        iterationsRemaining;
    int        maxIterationsPerCall;
    int        coolingTakeOffIterations;
    int        heatingTakeOffIterations;
    int        coolingSettleIterations;
    int        heatingSettleIterations;
    int        finalSmoothingIterations;
    TrimCrit   coolingTrimCrit;
    TrimCrit   heatingTrimCrit;
    TrimCrit  *trimCrit;
    float      coolingTakeOffTrimCrit;
    float      heatingTakeOffTrimCrit;
    float      coolingSettleTrimCrit;
    float      heatingSettleTrimCrit;
    bool       status;
} GenRampData;


///////////////////////////////////////////////////
// Benchmarking definitions

//#define BENCHMARK

#ifdef BENCHMARK

#include <stdio.h>
#include <timer.h>

static int chunkIndex;
static uint64 times[20];
static void dispTimes( uint64 times[] );

#define BENCHMARK_INIT() (chunkIndex = 6)
#define BENCHMARK_RECORD_TIME( x ) (x = getSystemTicks())
#define BENCHMARK_RECORD_CHUNK_TIME() (times[chunkIndex++] = getSystemTicks())
#define BENCHMARK_DISP_TIMES( x ) (dispTimes( x ))

#else

#define BENCHMARK_INIT()
#define BENCHMARK_RECORD_TIME( x )
#define BENCHMARK_RECORD_CHUNK_TIME()
#define BENCHMARK_DISP_TIMES( x )
#endif


///////////////////////////////////////////////////
// Local function prototypes

static int   * getRampParamPtr( RampParam param );
static float * getRampFloatParamPtr( RampParam param );
static bool    generateRamp( void *dataPtr );
static void    diffusiveSmooth( float *curve, int numPoints,
                                int iterations, int spread );


///////////////////////////////////////////////////
// Local data

GenRampData genRampData;


///////////////////////////////////////////////////
// Interface functions

void rampInit()
{
    resetRampParams();
}

void resetRampParams( void )
{
    genRampData.coolingTakeOffIterations = DEFAULT_COOLING_TAKE_OFF_ITERATIONS;
    genRampData.heatingTakeOffIterations = DEFAULT_HEATING_TAKE_OFF_ITERATIONS;
    genRampData.coolingSettleIterations  = DEFAULT_COOLING_SETTLE_ITERATIONS;
    genRampData.heatingSettleIterations  = DEFAULT_HEATING_SETTLE_ITERATIONS;
    genRampData.finalSmoothingIterations = DEFAULT_FINAL_SMOOTHING_ITERATIONS;
    genRampData.coolingTrimCrit.takeOff  = DEFAULT_COOLING_TAKE_OFF_TRIM_CRIT;
    genRampData.heatingTrimCrit.takeOff  = DEFAULT_HEATING_TAKE_OFF_TRIM_CRIT;
    genRampData.coolingTrimCrit.settle   = DEFAULT_COOLING_SETTLE_TRIM_CRIT;
    genRampData.heatingTrimCrit.settle   = DEFAULT_HEATING_SETTLE_TRIM_CRIT;
}

void setRampParam( RampParam param, int value )
{
    *getRampParamPtr( param ) = value;
}

int getRampParam( RampParam param )
{
    return *getRampParamPtr( param );
}

void setRampFloatParam( RampParam param, float value )
{
    *getRampFloatParamPtr( param ) = value;
}

float getRampFloatParam( RampParam param )
{
    return *getRampFloatParamPtr( param );
}

bool startGenerateRamp( float startTemp, float endTemp, float rampRate,
                        float sampleFrequency, float *ramp, int *rampPoints,
                        void (*callbackFunc)(int, bool), int callbackRef )
{
    static GenRampData * const data = &genRampData;

    const int minMaxPoints = *rampPoints < MAX_RAMP_POINTS ? *rampPoints :
                                                             MAX_RAMP_POINTS;

    data->cooling = endTemp < startTemp;

    // We add the trimming criterion to both ends of the ramp so we trim it
    // back to the original targets when we trim.
    if( data->cooling )
    {
        data->trimCrit  = &data->coolingTrimCrit;
        data->startTemp = startTemp + data->trimCrit->takeOff;
        data->endTemp   = endTemp   - data->trimCrit->settle;
    }
    else
    {
        data->trimCrit  = &data->heatingTrimCrit;
        data->startTemp = startTemp - data->trimCrit->takeOff;
        data->endTemp   = endTemp   + data->trimCrit->settle;
    }

    data->rampRate        = rampRate;
    data->sampleFrequency = sampleFrequency;
    data->ramp            = ramp;
    data->rampPoints      = rampPoints;
    data->delta           = fabs( data->endTemp - data->startTemp );
    data->state           = STARTING;
    data->callbackFunc    = callbackFunc;
    data->callbackRef     = callbackRef;
    data->status          = false;

    BENCHMARK_INIT();
    BENCHMARK_RECORD_TIME( times[0] );

    // Only generate the ramp if the parameters are acceptable.
    if( data->delta                              >= MIN_SMOOTH_DELTA &&
        rampRate                                 >= MIN_SMOOTH_RATE  &&
        data->delta / rampRate                   >= MIN_SMOOTH_TIME  &&
        data->delta * sampleFrequency / rampRate <= minMaxPoints )
    {
        scheduleTask( generateRamp, &genRampData, false );
        return true;
    }

    return false;
}


///////////////////////////////////////////////////
// Local functions

static int * getRampParamPtr( RampParam param )
{
    int *paramPtr;

    switch( param )
    {
    case RAMP_COOLING_TAKE_OFF_ITERATIONS:
        paramPtr = &genRampData.coolingTakeOffIterations;
        break;
    case RAMP_HEATING_TAKE_OFF_ITERATIONS:
        paramPtr = &genRampData.heatingTakeOffIterations;
        break;
    case RAMP_COOLING_SETTLE_ITERATIONS:
        paramPtr = &genRampData.coolingSettleIterations;
        break;
    case RAMP_HEATING_SETTLE_ITERATIONS:
        paramPtr = &genRampData.heatingSettleIterations;
        break;
    case RAMP_FINAL_SMOOTHING_ITERATIONS:
        paramPtr = &genRampData.finalSmoothingIterations;
        break;
    default:
        ASSERT( 0 ); // Unknown parameter type!
    }

    return paramPtr;
}

static float * getRampFloatParamPtr( RampParam param )
{
    float *paramPtr;

    switch( param )
    {
    case RAMP_COOLING_TAKE_OFF_TRIM:
        paramPtr = &genRampData.coolingTrimCrit.takeOff;
        break;
    case RAMP_HEATING_TAKE_OFF_TRIM:
        paramPtr = &genRampData.heatingTrimCrit.takeOff;
        break;
    case RAMP_COOLING_SETTLE_TRIM:
        paramPtr = &genRampData.coolingTrimCrit.settle;
        break;
    case RAMP_HEATING_SETTLE_TRIM:
        paramPtr = &genRampData.heatingTrimCrit.settle;
        break;
    default:
        ASSERT( 0 ); // Unknown parameter type!
    }

    return paramPtr;
}

static bool generateRamp( void *dataPtr )
{
    GenRampData *data = (GenRampData *)dataPtr;

    switch( data->state )
    {
    case STARTING:
        {
            const float time    = data->delta / data->rampRate;
            const float step    =
                (data->endTemp - data->startTemp) / data->sampleFrequency / time;

            int   endPointCount = (int)(time * data->sampleFrequency * 1.5 + 0.5);
            int   i, j;
            float temperature;

            // Make sure we have enough room to store the full curve.
            if( endPointCount * 2 + time * data->sampleFrequency > MAX_RAMP_POINTS )
            {
                sendLogMsg( "GenRamp (Starting): Not enough room in internal array!" );
                data->state = IDLE;
                break;
            }

            // Construct a linear ramp with the necessary end points.
            for( i = 0; i < endPointCount; ++i )
            {
                data->takeoffRamp[ i ] = data->startTemp;
            }
            for( temperature = data->startTemp;
                 fabs( temperature - data->endTemp ) > fabs( step );
                 temperature += step )
            {
                data->takeoffRamp[ i++ ] = temperature;
                if( i >= MAX_RAMP_POINTS - endPointCount )
                {
                    break;
                }
            }
            for( j = 0; j < endPointCount; ++j )
            {
                data->takeoffRamp[ i++ ] = data->endTemp;
            }

            data->curvePoints = i;
            ASSERT( data->curvePoints <= MAX_RAMP_POINTS );
            data->state = SMOOTHING;
            break;
        }

    case SMOOTHING:
        memcpy( data->settleRamp, data->takeoffRamp,
                data->curvePoints * sizeof( float ) );
        BENCHMARK_RECORD_TIME( times[1] );
        data->iterationsRemaining =
            data->cooling ? data->coolingTakeOffIterations :
                            data->heatingTakeOffIterations;
        data->maxIterationsPerCall = INNER_LOOP_CALCS_PER_CALL/data->curvePoints;
        data->state = SMOOTHING_TAKE_OFF_CURVE;
        break;

    case SMOOTHING_TAKE_OFF_CURVE:
        if( data->iterationsRemaining )
        {
            int thisIterations = data->iterationsRemaining;

            if( thisIterations > data->maxIterationsPerCall )
            {
                thisIterations = data->maxIterationsPerCall;
            }

            diffusiveSmooth( data->takeoffRamp, data->curvePoints,
                             thisIterations, data->iterationsRemaining );
            data->iterationsRemaining -= thisIterations;

            BENCHMARK_RECORD_CHUNK_TIME();

            if( !data->iterationsRemaining )
            {
                BENCHMARK_RECORD_TIME( times[2] );
                data->iterationsRemaining =
                    data->cooling ? data->coolingSettleIterations :
                                    data->heatingSettleIterations;
                data->state = SMOOTHING_SETTLE_CURVE;
            }
            break;
        }

        BENCHMARK_RECORD_TIME( times[2] );
        data->iterationsRemaining =
            data->cooling ? data->coolingSettleIterations :
                            data->heatingSettleIterations;
        data->state = SMOOTHING_SETTLE_CURVE;
        break;

    case SMOOTHING_SETTLE_CURVE:
        if( data->iterationsRemaining )
        {
            int thisIterations = data->iterationsRemaining;

            if( thisIterations > data->maxIterationsPerCall )
            {
                thisIterations = data->maxIterationsPerCall;
            }

            diffusiveSmooth( data->settleRamp, data->curvePoints,
                             thisIterations, data->iterationsRemaining );
            data->iterationsRemaining -= thisIterations;

            BENCHMARK_RECORD_CHUNK_TIME();

            if( !data->iterationsRemaining )
            {
                BENCHMARK_RECORD_TIME( times[3] );
                data->state = COMBINING_CURVES;
            }
            break;
        }

        BENCHMARK_RECORD_TIME( times[3] );
        data->state = COMBINING_CURVES;
        break;

    case COMBINING_CURVES:
        {
            // Combine curves with takeoffRamp weighted average
            float *highCurve, *lowCurve;
            float minIn;
            int count;

            if( data->cooling )
            {
                highCurve = data->takeoffRamp;
                lowCurve  = data->settleRamp;
                minIn     = data->endTemp;
            }
            else
            {
                highCurve = data->settleRamp;
                lowCurve  = data->takeoffRamp;
                minIn     = data->startTemp;
            }

            for( count = 0; count < data->curvePoints; count++ )
            {
                float weight = (data->takeoffRamp[count] - minIn) / data->delta;

                data->takeoffRamp[count] = highCurve[count] * weight +
                                           lowCurve[count]  * (1 - weight);
            }
            data->state = TRIMMING;
            break;
        }

    case TRIMMING:
        {
            int i, j;

            // Trim the initial points from the final curve.
            for( i = 0; i < data->curvePoints; ++i )
            {
                if( fabs( data->takeoffRamp[ i ] - data->startTemp ) > data->trimCrit->takeOff )
                {
                    break;
                }
            }

            // Copy the final curve to the output array.
            for( j = 0; i < data->curvePoints; ++i )
            {
                // Make sure we have room.
                if( j >= *(data->rampPoints) )
                {
                    sendLogMsg( "GenRamp (Trimming): Not enough room in output array!" );
                    data->state = IDLE;
                    return true;
                }

                data->ramp[ j++ ] = data->takeoffRamp[ i ];

                // Trim the end points from the final curve.
                if( fabs( data->takeoffRamp[ i ] - data->endTemp ) < data->trimCrit->settle )
                {
                    // Populate the final points with the end temperature.
                    data->endTemp += data->trimCrit->settle * ( data->cooling ? 1 : -1 );
                    data->ramp[ j - 1 ] = data->endTemp;
                    if( j + 5 < *(data->rampPoints) )
                    {
                        int k;
                        for( k = 0; k < 5; ++k )
                        {
                            data->ramp[ j++ ] =  data->endTemp;
                        }
                    }
                    break;
                }
            }

            *(data->rampPoints) = j;

            BENCHMARK_RECORD_TIME( times[4] );
            data->iterationsRemaining = data->finalSmoothingIterations;
            data->state = SMOOTHING_FINAL_CURVE;
            break;
        }

    case SMOOTHING_FINAL_CURVE:
        if( !data->iterationsRemaining )
        {
            BENCHMARK_RECORD_TIME( times[5] );
            BENCHMARK_DISP_TIMES( times );
            data->status = true;
            data->state  = IDLE;
        }
        else
        {
            int thisIterations = data->iterationsRemaining;

            if( thisIterations > data->maxIterationsPerCall )
            {
                thisIterations = data->maxIterationsPerCall;
            }

            diffusiveSmooth( data->ramp, *data->rampPoints,
                             thisIterations, 1 );
            data->iterationsRemaining -= thisIterations;

            BENCHMARK_RECORD_CHUNK_TIME();
        }
        break;

    default:
        if( data->callbackFunc )
        {
            data->callbackFunc( data->callbackRef, data->status );
            data->callbackFunc = NULL;
        }
        return false;
    }

    return true;
}


static void diffusiveSmooth( float *curve, int numPoints,
                             int iterations, int spread )
{
    int i;

    if( spread < 1 )
    {
        spread = 1;
    }

    for( i = iterations; i > 0; --i )
    {
        float *previousPtr = &curve[ 0 ];
        float *currentPtr  = &curve[ spread ];
        float *nextPtr     = &curve[ spread + spread ];
        float *endPtr      = &curve[ numPoints - spread - 1 ];

        float previous     = *previousPtr;

        while( currentPtr <= endPtr )
        {
            float current  = *currentPtr;

            *currentPtr++ = (float)0.5*current + (float)0.25*(previous + *nextPtr++);
            previous      = spread == 1 ? current : *++previousPtr;
        }

        if( --spread < 1 )
        {
            spread = 1;
        }
    }
}


#ifdef BENCHMARK
static void dispTimes( uint64 times[] )
{
    int i;

    printf("Pre smoothing: %llu ms\n", TICKS_TO_MSEC(times[1] - times[0]));
    printf("Smoothing take off corner: %llu ms\n", TICKS_TO_MSEC(times[2] - times[1]));
    printf("Smoothing settle corner: %llu ms\n", TICKS_TO_MSEC(times[3] - times[2]));
    printf("Final smoothing: %llu ms\n", TICKS_TO_MSEC(times[4] - times[3]));
    printf("Post smoothing: %llu ms\n", TICKS_TO_MSEC(times[5] - times[4]));
    printf("Total elapsed time: %llu ms\n", TICKS_TO_MSEC(times[5] - times[0]));

    printf("Chunk time: %llu ms\n", TICKS_TO_MSEC(times[6] - times[1]));

    for( i = 7; i < chunkIndex; ++i )
    {
        printf("Chunk time: %llu ms\n", TICKS_TO_MSEC(times[i] - times[i-1]));
    }
}
#endif
