/////////////////////////////////////////////////////////////
//
//  selfTest.c
//
//  Plate Cycler Hardware Self Test
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#include <selfTest.h>
#include <os.h>
#include <sensors.h>
#include <timer.h>
#include <stdio.h>
#include <control.h>
#include <motion.h>
#include <illumination.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include <fan.h>
#include <initialization.h>



///////////////////////////////////////////////////
// Configuration



///////////////////////////////////////////////////
// Constants

static const float minAmbientTemp   = 15.0;
static const float maxAmbientTemp   = 50.0;
static const float minOperatingTemp = 0.0;
static const float maxOperatingTemp = 130.0;



///////////////////////////////////////////////////
// Local types and macros

#define ERROR_DESC_SIZE 200



typedef enum
{
    HeatsinkSensorTestState_Idle,
    HeatsinkSensorTestState_Starting,
    HeatsinkSensorTestState_Completed,
} HeatsinkSensorTestStates;

typedef struct
{
    HeatsinkSensorTestStates state;
    bool                     passed;
} HeatsinkSensorTest;




typedef enum
{
    AmbientSensorTestState_Idle,
    AmbientSensorTestState_Starting,
    AmbientSensorTestState_Completed,
} AmbientSensorTestStates;

typedef struct
{
    AmbientSensorTestStates state;
    bool                    passed;
} AmbientSensorTest;



typedef enum
{
    BlockTestState_Idle,
    BlockTestState_Starting,
    BlockTestState_Calibration,
    BlockTestState_Ambient,
    BlockTestState_CoolingSet,
    BlockTestState_CoolingRamping,
    BlockTestState_CoolingCheck,
    BlockTestState_HeatingSet,
    BlockTestState_HeatingRamping,
    BlockTestState_HeatingCheck,
    BlockTestState_Completed,
} BlockTestStates;

typedef struct
{
    BlockTestStates state;
    Timer           timer;
    float           targetTemp;
    float           lastError[BLOCK_TEMP_SENSOR_COUNT];
    bool            passed;
} BlockTest;



typedef enum
{
    LidThermalTestState_Idle,
    LidThermalTestState_Starting,
    LidThermalTestState_Calibration,
    LidThermalTestState_Ambient,
    LidThermalTestState_HeatingSet,
    LidThermalTestState_HeatingRamping,
    LidThermalTestState_HeatingCheck,
    LidThermalTestState_Completed,
} LidThermalTestStates;

typedef struct
{
    LidThermalTestStates state;
    Timer                timer;
    float                targetTemp;
    float                lastError[LID_TEMP_SENSOR_COUNT];
    bool                 passed;
} LidThermalTest;





typedef enum
{
    HeatsinkFanTestState_Idle,
    HeatsinkFanTestState_Starting,
    HeatsinkFanTestState_Running,
    HeatsinkFanTestState_Completed,
} HeatsinkFanTestStates;

typedef struct
{
    HeatsinkFanTestStates state;
    bool                  passed;
    Timer                 timer;
    int                   slowCount;
} HeatsinkFanTest;




typedef enum
{
    FilterWheelMotionTestState_Idle,
    FilterWheelMotionTestState_Starting,
    FilterWheelMotionTestState_Running,
    FilterWheelMotionTestState_Completed,
} FilterWheelMotionTestStates;

typedef struct
{
    FilterWheelMotionTestStates state;
    bool                        passed;
} FilterWheelMotionTest;




typedef enum
{
    LidMotionTestState_Idle,
    LidMotionTestState_Starting,
    LidMotionTestState_InitHome,
    LidMotionTestState_WaitingOnDoor,
    LidMotionTestState_WaitingOnBlock,
    LidMotionTestState_Lowering,
    LidMotionTestState_WaitingOnIllumination,
    LidMotionTestState_StartRaising,
    LidMotionTestState_Raising,
    LidMotionTestState_Completed,
} LidMotionTestStates;

typedef struct
{
    LidMotionTestStates state;
    bool                passed;
} LidMotionTest;




typedef enum
{
    DoorMotionTestState_Idle,
    DoorMotionTestState_Starting,
    DoorMotionTestState_InitHome,
    DoorMotionTestState_StartClose,
    DoorMotionTestState_Closing,
    DoorMotionTestState_WaitingForLid,
    DoorMotionTestState_Opening,
    DoorMotionTestState_Completed,
} DoorMotionTestStates;

typedef struct
{
    DoorMotionTestStates state;
    bool                 passed;
} DoorMotionTest;




typedef enum
{
    IlluminationTestState_Idle,
    IlluminationTestState_Starting,
    IlluminationTestState_WaitingOnCavity,
    IlluminationTestState_TestBlueStart,
    IlluminationTestState_TestBlueCheck,
    IlluminationTestState_TestGreenStart,
    IlluminationTestState_TestGreenCheck,
    IlluminationTestState_TestOrangeStart,
    IlluminationTestState_TestOrangeCheck,
    IlluminationTestState_TestRedStart,
    IlluminationTestState_TestRedCheck,
    IlluminationTestState_TestCrimsonStart,
    IlluminationTestState_TestCrimsonCheck,
    IlluminationTestState_Completed,
} IlluminationTestStates;

typedef struct
{
    IlluminationTestStates state;
    Timer                  timer;
    bool                   bluePassed;
    bool                   greenPassed;
    bool                   orangePassed;
    bool                   redPassed;
    bool                   crimsonPassed;
} IlluminationTest;









typedef enum
{
    SelfTestState_Idle,
    SelfTestState_Running,
} SelfTestStates;

typedef struct
{
    OfflineTaskCompleteCallback completedCallbackFunc;
    OfflineTaskInfoCallback     infoCallbackFunc;
    int                         reference;
} OperationCallback;



typedef struct
{
    SelfTestStates        state;
    OperationCallback     callback;

    HeatsinkSensorTest    heatsinkSensorTest;
    AmbientSensorTest     ambientSensorTest;
    BlockTest             blockTest;
    LidThermalTest        lidThermalTest;
    HeatsinkFanTest       heatsinkFanTest;
    FilterWheelMotionTest filterWheelMotionTest;
    LidMotionTest         lidMotionTest;
    DoorMotionTest        doorMotionTest;
    IlluminationTest      illuminationTest;

    ErrorCodes            error;

    bool                  ignoreErrors;
} SelfTestData;



///////////////////////////////////////////////////
// Local function prototypes

static bool startSelfTestTask(void* unused);
static void completeTest();
static void sendInfoStatus(TestDevices device, ErrorCodes error, const char* errorDesc);

static bool testSensorCalibration(int sensor, int calibrationCount, char* errorDesc, unsigned errorDescSize);
static bool testAmbientSensorReading(int sensor, float minTemp, float maxTemp, char* errorDesc, unsigned errorDescSize);
static bool testCurrentTemperature(int channel, float expectedTemp, float delta, char* errorDesc, unsigned errorDescSize);
static bool testCurrentDriveEffort(int channel, int* effort, int expectedEffort, int delta, char* errorDesc, unsigned errorDescSize);

static bool heatsinkSensorSelfTestTask(void* unused);
static bool ambientSensorSelfTestTask(void* unused);

static bool blockSelfTestTask(void* unused);
static void blockSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc);

static bool lidThermalSelfTestTask(void* unused);
static void lidThermalSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc);

static bool heatsinkFanSelfTestTask(void* unused);

static bool filterWheelMotionSelfTestTask(void* unused);
static void filterWheelMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc);

static bool lidMotionSelfTestTask(void* unused);
static void lidMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc);

static bool doorMotionSelfTestTask(void* unused);
static void doorMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc);

static bool illuminationSelfTestTask(void* unused);
static void illuminationSelfTestTurnOnLED(IlluminationColor color);
static bool illuminationSelfTestVerifyLED(IlluminationColor color, TestDevices device, float deltaPercent);



///////////////////////////////////////////////////
// Local data

static SelfTestData selfTestData;



///////////////////////////////////////////////////
// Interface functions

void selfTestInit()
{
    memset(&selfTestData, 0, sizeof(selfTestData));
    selfTestData.state        = SelfTestState_Idle;
    selfTestData.ignoreErrors = false;
}


bool startSelfTest(OfflineTaskCompleteCallback completedCallbackFunc, OfflineTaskInfoCallback infoCallbackFunc, int callbackRef)
{
    if(selfTestData.state != SelfTestState_Idle)
    {
        return false;
    }

    selfTestData.callback.completedCallbackFunc = completedCallbackFunc;
    selfTestData.callback.infoCallbackFunc      = infoCallbackFunc;
    selfTestData.callback.reference             = callbackRef;

    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
    illuminationAbort();
    resetSystemToDefaults();

    selfTestData.state = SelfTestState_Running;

    scheduleTask(startSelfTestTask, NULL, false);

    return true;
}



void abortSelfTests()
{
    if(selfTestData.state == SelfTestState_Running)
    {
        const char formatStr[] = "State %d";
        char errorDesc[ERROR_DESC_SIZE];

        if(selfTestData.heatsinkSensorTest.state != HeatsinkSensorTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.heatsinkSensorTest.state);
            sendInfoStatus(TestDevice_HeatsinkThermal, err_operationAborted, errorDesc);
        }

        if(selfTestData.ambientSensorTest.state != AmbientSensorTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.ambientSensorTest.state);
            sendInfoStatus(TestDevice_AmbientThermal, err_operationAborted, errorDesc);
        }

        if(selfTestData.blockTest.state != BlockTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.blockTest.state);
            sendInfoStatus(TestDevice_BlockThermal, err_operationAborted, errorDesc);
        }

        if(selfTestData.lidThermalTest.state != LidThermalTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.lidThermalTest.state);
            sendInfoStatus(TestDevice_LidThermal, err_operationAborted, errorDesc);
        }

        if(selfTestData.heatsinkFanTest.state != HeatsinkFanTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.heatsinkFanTest.state);
            sendInfoStatus(TestDevice_HeatsinkFan, err_operationAborted, errorDesc);
        }

        if(selfTestData.filterWheelMotionTest.state != FilterWheelMotionTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.filterWheelMotionTest.state);
            sendInfoStatus(TestDevice_FilterWheelMotion, err_operationAborted, errorDesc);
        }

        if(selfTestData.lidMotionTest.state != LidMotionTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.lidMotionTest.state);
            sendInfoStatus(TestDevice_LidMotion, err_operationAborted, errorDesc);
        }

        if(selfTestData.doorMotionTest.state != DoorMotionTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.doorMotionTest.state);
            sendInfoStatus(TestDevice_DoorMotion, err_operationAborted, errorDesc);
        }

        if(selfTestData.illuminationTest.state != IlluminationTestState_Completed)
        {
            snprintf(errorDesc, ERROR_DESC_SIZE, formatStr, selfTestData.illuminationTest.state);
            sendInfoStatus(TestDevice_IlluminationBlue, err_operationAborted, errorDesc);
            sendInfoStatus(TestDevice_IlluminationGreen, err_operationAborted, errorDesc);
            sendInfoStatus(TestDevice_IlluminationOrange, err_operationAborted, errorDesc);
            sendInfoStatus(TestDevice_IlluminationRed, err_operationAborted, errorDesc);
            sendInfoStatus(TestDevice_IlluminationCrimson, err_operationAborted, errorDesc);
        }
        
        if(selfTestData.callback.completedCallbackFunc)
        {
            selfTestData.callback.completedCallbackFunc(selfTestData.callback.reference,
                                                        err_operationAborted, NULL);
        }
    }
    
    selfTestData.callback.completedCallbackFunc = NULL;
    selfTestData.callback.infoCallbackFunc      = NULL;
    selfTestData.state                          = SelfTestState_Idle;

    selfTestData.heatsinkSensorTest.state       = HeatsinkSensorTestState_Idle;
    selfTestData.ambientSensorTest.state        = AmbientSensorTestState_Idle;
    selfTestData.blockTest.state                = BlockTestState_Idle;
    selfTestData.lidThermalTest.state           = LidThermalTestState_Idle;
    selfTestData.heatsinkFanTest.state          = HeatsinkFanTestState_Idle;
    selfTestData.filterWheelMotionTest.state    = FilterWheelMotionTestState_Idle;
    selfTestData.lidMotionTest.state            = LidMotionTestState_Idle;
    selfTestData.doorMotionTest.state           = DoorMotionTestState_Idle;
    selfTestData.illuminationTest.state         = IlluminationTestState_Idle;

    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
}


void selfTestIgnoreErrors()
{
    selfTestData.ignoreErrors = true;
}



///////////////////////////////////////////////////
// Local functions

static bool startSelfTestTask(void* unused)
{
    selfTestData.error = err_noError;

    // Kick off all parallel self tests

    selfTestData.heatsinkSensorTest.passed = false;
    selfTestData.heatsinkSensorTest.state  = HeatsinkSensorTestState_Starting;
    scheduleTask(heatsinkSensorSelfTestTask, NULL, false);

    selfTestData.ambientSensorTest.passed = false;
    selfTestData.ambientSensorTest.state  = AmbientSensorTestState_Starting;
    scheduleTask(ambientSensorSelfTestTask, NULL, false);

    selfTestData.blockTest.passed = false;
    selfTestData.blockTest.state  = BlockTestState_Starting;
    scheduleTask(blockSelfTestTask, NULL, false);

    selfTestData.lidThermalTest.passed = false;
    selfTestData.lidThermalTest.state  = LidThermalTestState_Starting;
    scheduleTask(lidThermalSelfTestTask, NULL, false);

    selfTestData.heatsinkFanTest.passed = false;
    selfTestData.heatsinkFanTest.state  = HeatsinkFanTestState_Starting;
    scheduleTask(heatsinkFanSelfTestTask, NULL, false);

    selfTestData.filterWheelMotionTest.passed = false;
    selfTestData.filterWheelMotionTest.state  = FilterWheelMotionTestState_Starting;
    scheduleTask(filterWheelMotionSelfTestTask, NULL, false);

    selfTestData.lidMotionTest.passed = false;
    selfTestData.lidMotionTest.state  = LidMotionTestState_Starting;
    scheduleTask(lidMotionSelfTestTask, NULL, false);

    selfTestData.doorMotionTest.passed = false;
    selfTestData.doorMotionTest.state  = DoorMotionTestState_Starting;
    scheduleTask(doorMotionSelfTestTask, NULL, false);

    selfTestData.illuminationTest.bluePassed    = false;
    selfTestData.illuminationTest.greenPassed   = false;
    selfTestData.illuminationTest.orangePassed  = false;
    selfTestData.illuminationTest.redPassed     = false;
    selfTestData.illuminationTest.crimsonPassed = false;
    selfTestData.illuminationTest.state         = IlluminationTestState_Starting;
    scheduleTask(illuminationSelfTestTask, NULL, false);


    //TODO: Add timeout for self tests

    return false;
}



static void completeTest()
{
    if(selfTestData.state                       == SelfTestState_Running                &&
       selfTestData.heatsinkSensorTest.state    == HeatsinkSensorTestState_Completed    &&
       selfTestData.ambientSensorTest.state     == AmbientSensorTestState_Completed     &&
       selfTestData.blockTest.state             == BlockTestState_Completed             &&
       selfTestData.lidThermalTest.state        == LidThermalTestState_Completed        &&
       selfTestData.heatsinkFanTest.state       == HeatsinkFanTestState_Completed       &&
       selfTestData.filterWheelMotionTest.state == FilterWheelMotionTestState_Completed &&
       selfTestData.lidMotionTest.state         == LidMotionTestState_Completed         &&
       selfTestData.doorMotionTest.state        == DoorMotionTestState_Completed        &&
       selfTestData.illuminationTest.state      == IlluminationTestState_Completed)
    {
        if(selfTestData.callback.completedCallbackFunc)
        {
            selfTestData.callback.completedCallbackFunc(selfTestData.callback.reference,
                                                        selfTestData.error, NULL);
        }

        selfTestData.callback.infoCallbackFunc = NULL;
        selfTestData.state                     = SelfTestState_Idle;

        resetTempControl(ALL_BLOCK_CHANNELS);
        resetTempControl(ALL_LID_CHANNELS);
    }
}





static void sendInfoStatus(TestDevices device, ErrorCodes error, const char* errorDesc)
{
    if(error != err_noError && error != err_selfTestSkipped)
    {
        selfTestData.error = err_selfTestFailure;
    }


    if(selfTestData.callback.infoCallbackFunc)
    {
        selfTestData.callback.infoCallbackFunc(device, error, errorDesc);
    }
}



static bool testSensorCalibration(int sensor, int calibrationCount, char* errorDesc, unsigned errorDescSize)
{
    ASSERT(calibrationCount  > 0);
    ASSERT(calibrationCount <= TEMP_SENSOR_CALIBRATION_COUNT);
    ASSERT(errorDesc);

    int calIndex;

    for(calIndex = 0; calIndex < calibrationCount; calIndex++)
    {
        float  lowCalPoint, highCalPoint;
        uint16 sensorLowValue, sensorHighValue;

        if(!getCalibrationPoint(sensor, false, calIndex, false,  &lowCalPoint)    ||
           !getCalibrationPoint(sensor, true,  calIndex, false,  &highCalPoint)   ||
           !getSensorCalibration(sensor, false, calIndex, false, &sensorLowValue) ||
           !getSensorCalibration(sensor, true,  calIndex, false, &sensorHighValue))
        {
            snprintf(errorDesc, errorDescSize,
                     "Temperaure Sensor %s cal index %d not calibrated.",
                     getSensorName(sensor), calIndex);
            return false;
        }
    }

    return true;
}



static bool testAmbientSensorReading(int sensor, float minTemp, float maxTemp, char* errorDesc, unsigned errorDescSize)
{
    ASSERT(minTemp < maxTemp);
    ASSERT(errorDesc);

    float temperature = getCurrentTemp(sensor);

    if(temperature < minTemp || temperature > maxTemp)
    {
        snprintf(errorDesc, errorDescSize,
                 "Temperature Sensor %s ambient reading (%.03f) out of range (%.03f, %.03f)",
                 getSensorName(sensor), temperature, minTemp, maxTemp);
        return false;
    }

    return true;
}



static bool testCurrentTemperature(int channel, float expectedTemp, float delta, char* errorDesc, unsigned errorDescSize)
{
    ASSERT(errorDesc);

    float temperature = getCurrentTemp(channel);

    if(fabs(expectedTemp - temperature) > delta)
    {
        snprintf(errorDesc, errorDescSize,
                 "Channel %s temperature reading out of range: Expected %.3f, Actual %.3f, Delta: %.3f",
                 getSensorName(channel), expectedTemp, temperature, delta);

        return false;
    }

    return true;
}



static bool testCurrentDriveEffort(int channel, int* effort, int expectedEffort, int delta, char* errorDesc, unsigned errorDescSize)
{
    ASSERT(effort);
    ASSERT(errorDesc);

    *effort = getPwm(channel, pwmCurrent);

    if(abs(expectedEffort - *effort) > delta)
    {
        snprintf(errorDesc, errorDescSize,
                 "Channel %s drive effort out of range: Expected %.1f%%, Actual %.1f%%, Delta: %.1f",
                 getSensorName(channel), expectedEffort/10.0, (*effort)/10.0, delta/10.0);

        return false;
    }

    return true;
}



////////////////////////////////////////////////////////////////////////////////////////////////
// Tests


////   Heatsink Sensor Self Test   /////////////////////

static bool heatsinkSensorSelfTestTask(void* unused)
{
    char errorDesc[ERROR_DESC_SIZE];
    errorDesc[0] = 0;

    switch(selfTestData.heatsinkSensorTest.state)
    {
    case HeatsinkSensorTestState_Idle:
        break;

    case HeatsinkSensorTestState_Starting:
        printf("Testing Heatsink Sensor\n");

        if(!testSensorCalibration(HEAT_SINK_TEMP_SENSOR, 1, errorDesc, ERROR_DESC_SIZE))
        {
            sendInfoStatus(TestDevice_HeatsinkThermal, err_blockHeatSinkSensorNotCalibrated, errorDesc);
            selfTestData.heatsinkSensorTest.state = HeatsinkSensorTestState_Completed;
            return true;
        }

        if(!testAmbientSensorReading(HEAT_SINK_TEMP_SENSOR, minAmbientTemp,
                                     maxAmbientTemp, errorDesc, ERROR_DESC_SIZE))
        {
            sendInfoStatus(TestDevice_HeatsinkThermal, err_blockHeatSinkSensorAmbientTestFailure, errorDesc);
            selfTestData.heatsinkSensorTest.state = HeatsinkSensorTestState_Completed;
            return true;
        }

        selfTestData.heatsinkSensorTest.passed = true;
        selfTestData.heatsinkSensorTest.state  = HeatsinkSensorTestState_Completed;
        sendInfoStatus(TestDevice_HeatsinkThermal, err_noError, NULL);
        return true;

    case HeatsinkSensorTestState_Completed:
        printf("Heatsink Sensor test complete - %s\n", selfTestData.heatsinkSensorTest.passed ? "passed" : "failed");
        completeTest();
        break;

    default:
        ASSERT(false);
        break;
    }

    return false;
}




////   Ambient Sensor Self Test   /////////////////////

static bool ambientSensorSelfTestTask(void* unused)
{
    char errorDesc[ERROR_DESC_SIZE];
    errorDesc[0] = 0;

    switch(selfTestData.ambientSensorTest.state)
    {
    case AmbientSensorTestState_Idle:
        break;

    case AmbientSensorTestState_Starting:
        printf("Testing Ambient Sensor\n");

        if(!testSensorCalibration(AMBIENT_TEMP_SENSOR, 1, errorDesc, ERROR_DESC_SIZE))
        {
            sendInfoStatus(TestDevice_AmbientThermal, err_ambientSensorNotCalibrated, errorDesc);
            selfTestData.ambientSensorTest.state = AmbientSensorTestState_Completed;
            return true;
        }

        if(!testAmbientSensorReading(AMBIENT_TEMP_SENSOR, minAmbientTemp,
                                     maxAmbientTemp, errorDesc, ERROR_DESC_SIZE))
        {
            sendInfoStatus(TestDevice_AmbientThermal, err_ambientSensorAmbientTestFailure, errorDesc);
            selfTestData.ambientSensorTest.state = AmbientSensorTestState_Completed;
            return true;
        }

        selfTestData.ambientSensorTest.passed = true;
        selfTestData.ambientSensorTest.state  = AmbientSensorTestState_Completed;
        sendInfoStatus(TestDevice_AmbientThermal, err_noError, NULL);
        return true;

    case AmbientSensorTestState_Completed:
        printf("Ambient Sensor test complete - %s\n", selfTestData.ambientSensorTest.passed ? "passed" : "failed");
        completeTest();
        break;

    default:
        ASSERT(false);
        break;
    }

    return false;
}




////   Thermal Block Self Test   /////////////////////

static bool blockSelfTestTask(void* unused)
{
    const uint64 maxCoolRampTime_ms      = 30000;
    const uint64 maxHeatRampTime_ms      = 50000;
    const uint64 ambientPollTime_ms      = 1000;

    const float  coolDriveDeltaTemp      = -10.0;
    const float  heatDriveDeltaTemp      =  20.0;
    const float  maxTargetDelta          =   1.0;
    const float  maxZoneVariation        =   2.0;

    const int    expectedCoolDriveEffort = -250;
    const int    expectedHeatDriveEffort =  300;
    const int    maxDriveEffortDelta     =   70;

    char errorDesc[ERROR_DESC_SIZE];
    int  zone;

    errorDesc[0] = 0;



    switch(selfTestData.blockTest.state)
    {
    case BlockTestState_Idle:
        return false;

    case BlockTestState_Starting:
        if(selfTestData.heatsinkSensorTest.state == HeatsinkSensorTestState_Completed &&
           selfTestData.ambientSensorTest.state  == AmbientSensorTestState_Completed  &&
           selfTestData.heatsinkFanTest.state    == HeatsinkFanTestState_Completed)
        {
            printf("Testing Block\n");

            if(!selfTestData.heatsinkSensorTest.passed || !selfTestData.ambientSensorTest.passed)
            {
                sendInfoStatus(TestDevice_BlockThermal, err_selfTestSkipped, "Heatsink Sensor or Ambient Sensor test failed");
                selfTestData.blockTest.state = BlockTestState_Completed;
                return true;
            }

            resetTempControl(ALL_BLOCK_CHANNELS);
            selfTestData.blockTest.state = BlockTestState_Calibration;
        }

        return true;

    case BlockTestState_Calibration:
        if(!validateSensorCalibrationCRCs())
        {
            sendInfoStatus(TestDevice_BlockThermal, err_blockNotCalibrated, errorDesc);
            selfTestData.blockTest.state = BlockTestState_Completed;
            return true;
        }

        for(zone = 0; zone < BLOCK_TEMP_SENSOR_COUNT; zone++)
        {
            selfTestData.blockTest.lastError[zone] = 0.0;

            if(!testSensorCalibration(FIRST_BLOCK_TEMP_SENSOR + zone, TEMP_SENSOR_CALIBRATION_COUNT, errorDesc, ERROR_DESC_SIZE))
            {
                sendInfoStatus(TestDevice_BlockThermal, err_blockNotCalibrated, errorDesc);
                selfTestData.blockTest.state = BlockTestState_Completed;
                return true;
            }
        }

        selfTestData.blockTest.state = BlockTestState_Ambient;
        startTimer(&selfTestData.blockTest.timer, 0);
        return true;

    case BlockTestState_Ambient:
        if(timerExpired(&selfTestData.blockTest.timer))
        {
            float zoneTemperatures[BLOCK_TEMP_SENSOR_COUNT];
            float zoneTempAverage = 0.0;

            // Check each zone absolute value
            for(zone = 0; zone < BLOCK_TEMP_SENSOR_COUNT; zone++)
            {
                float temperature = getCurrentTemp(FIRST_BLOCK_TEMP_SENSOR + zone);
                zoneTemperatures[zone] = temperature;
                zoneTempAverage += temperature;
                
                if(temperature < minAmbientTemp || temperature > maxAmbientTemp)
                {
                    if(temperature > minOperatingTemp && temperature < maxOperatingTemp)
                    {
                        float error = temperature - ((temperature < minAmbientTemp) ? minAmbientTemp : maxAmbientTemp);
                        
                        if(selfTestData.blockTest.lastError[zone] == 0.0 ||
                           (((error < 0 && selfTestData.blockTest.lastError[zone] < 0) ||
                             (error > 0 && selfTestData.blockTest.lastError[zone] > 0)) &&
                            fabs(error) < fabs(selfTestData.blockTest.lastError[zone])))
                        {
                            // Temperature out of ambient range, but in operating range
                            // and error is decreasing - keep trying
                            printf("Block Ambient Test: Zone %s error (%.3f) is decreasing, trying again\n",
                                   getSensorName(FIRST_BLOCK_TEMP_SENSOR + zone), error);
                            selfTestData.blockTest.lastError[zone] = error;
                            startTimer(&selfTestData.blockTest.timer, MSEC_TO_TICKS(ambientPollTime_ms));
                            
                            return true;
                        }
                    }

                    snprintf(errorDesc, ERROR_DESC_SIZE,
                             "Temperature Sensor %s ambient reading (%.3f) out of range (%.3f, %.3f)",
                             getSensorName(FIRST_BLOCK_TEMP_SENSOR + zone), temperature, minAmbientTemp, maxAmbientTemp);

                    sendInfoStatus(TestDevice_BlockThermal, err_blockAmbientTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }
            
            // Check each zone against block average
            zoneTempAverage /= BLOCK_TEMP_SENSOR_COUNT;
            for(zone = 0; zone < BLOCK_TEMP_SENSOR_COUNT; zone++)
            {
                if(fabs(zoneTemperatures[zone] - zoneTempAverage) > maxZoneVariation)
                {
                    snprintf(errorDesc, ERROR_DESC_SIZE,
                             "Temperature Sensor %s ambient reading (%.3f) out of block average range (%.3f +/-%.3f)",
                             getSensorName(FIRST_BLOCK_TEMP_SENSOR + zone), zoneTemperatures[zone],
                             zoneTempAverage, maxZoneVariation);

                    sendInfoStatus(TestDevice_BlockThermal, err_blockAmbientTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }            

            selfTestData.blockTest.state = BlockTestState_CoolingSet;
        }
        return true;


    case BlockTestState_CoolingSet:
        {
            float heatsinkTemp = getCurrentTemp(HEAT_SINK_CHANNEL);

            selfTestData.blockTest.targetTemp = heatsinkTemp + coolDriveDeltaTemp;

            printf("Testing block cooling - heatsink %.3f, target %.3f\n", heatsinkTemp, selfTestData.blockTest.targetTemp);

            setTargetTemp(ALL_BLOCK_CHANNELS, selfTestData.blockTest.targetTemp,
                          blockSelfTestCallback, 0);

            selfTestData.blockTest.state = BlockTestState_CoolingRamping;
            startTimer(&selfTestData.blockTest.timer, MSEC_TO_TICKS(maxCoolRampTime_ms));

            return true;
        }

    case BlockTestState_CoolingRamping:
        if(timerExpired(&selfTestData.blockTest.timer))
        {
            sendInfoStatus(TestDevice_BlockThermal, err_blockCoolingTestFailure, "Timed out waiting to reach target temp");
            selfTestData.blockTest.state = BlockTestState_Completed;
        }
        return true;

    case BlockTestState_CoolingCheck:
        if(timerExpired(&selfTestData.blockTest.timer))
        {
            int driveEffort[BLOCK_CHANNEL_COUNT];
            int channel;

            for(channel = 0; channel < BLOCK_CHANNEL_COUNT; channel++)
            {
                if(!testCurrentTemperature(FIRST_BLOCK_CHANNEL + channel, selfTestData.blockTest.targetTemp, maxTargetDelta,
                                           errorDesc, ERROR_DESC_SIZE))
                {
                    sendInfoStatus(TestDevice_BlockThermal, err_blockCoolingTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }


            for(channel = 0; channel < BLOCK_CHANNEL_COUNT; channel++)
            {
                if(!testCurrentDriveEffort(FIRST_BLOCK_CHANNEL + channel, &driveEffort[channel],
                                           expectedCoolDriveEffort, maxDriveEffortDelta,
                                           errorDesc, ERROR_DESC_SIZE))
                {
                    sendInfoStatus(TestDevice_BlockThermal, err_blockCoolingTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }

            //TODO: send log information with block drive effort

            selfTestData.blockTest.state = BlockTestState_HeatingSet;
        }

        return true;

    case BlockTestState_HeatingSet:
        {
            float heatsinkTemp = getCurrentTemp(HEAT_SINK_CHANNEL);

            selfTestData.blockTest.targetTemp = heatsinkTemp + heatDriveDeltaTemp;

            printf("Testing block heating - heatsink %.3f, target %.3f\n", heatsinkTemp, selfTestData.blockTest.targetTemp);

            setTargetTemp(ALL_BLOCK_CHANNELS, selfTestData.blockTest.targetTemp,
                          blockSelfTestCallback, 0);

            selfTestData.blockTest.state = BlockTestState_HeatingRamping;
            startTimer(&selfTestData.blockTest.timer, MSEC_TO_TICKS(maxHeatRampTime_ms));

            return true;
        }

    case BlockTestState_HeatingRamping:
        if(timerExpired(&selfTestData.blockTest.timer))
        {
            sendInfoStatus(TestDevice_BlockThermal, err_blockHeatingTestFailure, "Timed out waiting to reach target temp");
            selfTestData.blockTest.state = BlockTestState_Completed;
        }
        return true;

    case BlockTestState_HeatingCheck:
        if(timerExpired(&selfTestData.blockTest.timer))
        {
            int driveEffort[BLOCK_CHANNEL_COUNT];
            int channel;

            for(channel = 0; channel < BLOCK_CHANNEL_COUNT; channel++)
            {
                if(!testCurrentTemperature(FIRST_BLOCK_CHANNEL + channel, selfTestData.blockTest.targetTemp, maxTargetDelta,
                                           errorDesc, ERROR_DESC_SIZE))
                {
                    sendInfoStatus(TestDevice_BlockThermal, err_blockHeatingTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }


            for(channel = 0; channel < BLOCK_CHANNEL_COUNT; channel++)
            {
                if(!testCurrentDriveEffort(FIRST_BLOCK_CHANNEL + channel, &driveEffort[channel],
                                           expectedHeatDriveEffort, maxDriveEffortDelta,
                                           errorDesc, ERROR_DESC_SIZE))
                {
                    sendInfoStatus(TestDevice_BlockThermal, err_blockHeatingTestFailure, errorDesc);
                    selfTestData.blockTest.state = BlockTestState_Completed;
                    return true;
                }
            }

            //TODO: send log information with block drive effort

            selfTestData.blockTest.passed = true;
            selfTestData.blockTest.state  = BlockTestState_Completed;
            sendInfoStatus(TestDevice_BlockThermal, err_noError, NULL);
        }

        return true;


    case BlockTestState_Completed:
        resetTempControl(ALL_BLOCK_CHANNELS);
        printf("Block test complete - %s\n", selfTestData.blockTest.passed ? "passed" : "failed");
        completeTest();
        return false;

    default:
        break;
    }

    return false;
}



static void blockSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    const uint32 coolHoldTime_ms = 10000;
    const uint32 heatHoldTime_ms = 10000;

    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_BlockThermal, error, errorDesc);
        selfTestData.blockTest.state = BlockTestState_Completed;
        return;
    }

    switch(selfTestData.blockTest.state)
    {
    case BlockTestState_CoolingRamping:
        startTimer(&selfTestData.blockTest.timer, MSEC_TO_TICKS(coolHoldTime_ms));
        selfTestData.blockTest.state = BlockTestState_CoolingCheck;
        break;

    case BlockTestState_HeatingRamping:
        startTimer(&selfTestData.blockTest.timer, MSEC_TO_TICKS(heatHoldTime_ms));
        selfTestData.blockTest.state = BlockTestState_HeatingCheck;
        break;

    case BlockTestState_Idle:
    case BlockTestState_Starting:
    case BlockTestState_Calibration:
    case BlockTestState_Ambient:
    case BlockTestState_CoolingSet:
    case BlockTestState_CoolingCheck:
    case BlockTestState_HeatingSet:
    case BlockTestState_HeatingCheck:
    case BlockTestState_Completed:
    default:
        break;
    }
}







////   Lid Thermal Self Test   /////////////////////

static bool lidThermalSelfTestTask(void* unused)
{
    //TODO: Reevaluate and tighten up the lid self test
    //      parameters once the production lid is defined
    //      and built.

    const uint64 maxHeatRampTime_ms        = 90000ULL;
    const uint64 ambientPollTime_ms        = 5000;

    const float  heatDriveDeltaTemp        = 20.0;
    const float  maxTargetDelta            =  5.0;

    const int    expectedCenterDriveEffort = 100; // 1/10%
    const int    expectedRingDriveEffort   =  60; // 1/10%
    const int    maxDriveEffortDelta       = 200; // 1/10%

    char errorDesc[ERROR_DESC_SIZE];
    int  zone;

    errorDesc[0] = 0;

    switch(selfTestData.lidThermalTest.state)
    {
    case LidThermalTestState_Idle:
        return false;

    case LidThermalTestState_Starting:
        if(selfTestData.heatsinkSensorTest.state == HeatsinkSensorTestState_Completed &&
           selfTestData.ambientSensorTest.state  == AmbientSensorTestState_Completed  &&
           selfTestData.heatsinkFanTest.state    == HeatsinkFanTestState_Completed)
        {
            printf("Testing Lid - thermal\n");
            resetTempControl(ALL_LID_CHANNELS);
            selfTestData.lidThermalTest.state = LidThermalTestState_Calibration;
        }

        return true;

    case LidThermalTestState_Calibration:
        for(zone = 0; zone < LID_TEMP_SENSOR_COUNT; zone++)
        {
            selfTestData.lidThermalTest.lastError[zone] = 0.0;
            if(!testSensorCalibration(FIRST_HEATED_LID_TEMP_SENSOR + zone, 1, errorDesc, ERROR_DESC_SIZE))
            {
                sendInfoStatus(TestDevice_LidThermal, err_lidThermalNotCalibrated, errorDesc);
                selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
                return true;
            }
        }

        startTimer(&selfTestData.lidThermalTest.timer, 0);
        selfTestData.lidThermalTest.state = LidThermalTestState_Ambient;
        return true;

    case LidThermalTestState_Ambient:
        if(timerExpired(&selfTestData.lidThermalTest.timer))
        {
            // Check each zone absolute value
            for(zone = 0; zone < LID_TEMP_SENSOR_COUNT; zone++)
            {
                float temperature = getCurrentTemp(FIRST_LID_CHANNEL + zone);

                if(temperature < minAmbientTemp || temperature > maxAmbientTemp)
                {
                    if(temperature > minOperatingTemp && temperature < maxOperatingTemp)
                    {
                        float error = temperature - ((temperature < minAmbientTemp) ? minAmbientTemp : maxAmbientTemp);
                        
                        if(selfTestData.lidThermalTest.lastError[zone] == 0.0 ||
                           (((error < 0 && selfTestData.lidThermalTest.lastError[zone] < 0) ||
                             (error > 0 && selfTestData.lidThermalTest.lastError[zone] > 0)) &&
                            fabs(error) < fabs(selfTestData.lidThermalTest.lastError[zone])))
                        {
                            // Temperature out of ambient range, but in operating range
                            // and error is decreasing - keep trying
                            printf("Lid Ambient Test: Zone %s error (%.3f) is decreasing, trying again\n",
                                   getSensorName(FIRST_LID_CHANNEL + zone), error);
                            selfTestData.lidThermalTest.lastError[zone] = error;
                            startTimer(&selfTestData.lidThermalTest.timer, MSEC_TO_TICKS(ambientPollTime_ms));
                            
                            return true;
                        }
                    }

                    snprintf(errorDesc, ERROR_DESC_SIZE,
                             "Temperature Sensor %s ambient reading (%.3f) out of range (%.3f, %.3f)",
                             getSensorName(FIRST_LID_CHANNEL + zone), temperature, minAmbientTemp, maxAmbientTemp);

                    sendInfoStatus(TestDevice_LidThermal, err_lidThermalAmbientTestFailure, errorDesc);
                    selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
                    return true;
                }
            }

            selfTestData.lidThermalTest.state = LidThermalTestState_HeatingSet;
        }
        return true;

    case LidThermalTestState_HeatingSet:
        {
            float ambientTemp = getCurrentTemp(AMBIENT_CHANNEL);

            selfTestData.lidThermalTest.targetTemp = ambientTemp + heatDriveDeltaTemp;

            printf("Testing lid heating - ambient %.3f, target %.3f\n", ambientTemp, selfTestData.lidThermalTest.targetTemp);

            setTargetTemp(ALL_LID_CHANNELS, selfTestData.lidThermalTest.targetTemp,
                          lidThermalSelfTestCallback, 0);

            selfTestData.lidThermalTest.state = LidThermalTestState_HeatingRamping;
            startTimer(&selfTestData.lidThermalTest.timer, MSEC_TO_TICKS(maxHeatRampTime_ms));
            return true;
        }

    case LidThermalTestState_HeatingRamping:
        if(timerExpired(&selfTestData.lidThermalTest.timer))
        {
            sendInfoStatus(TestDevice_LidThermal, err_lidThermalHeatingTestFailure, "Timed out waiting to reach target temp");
            selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
        }
        return true;

    case LidThermalTestState_HeatingCheck:
        if(timerExpired(&selfTestData.lidThermalTest.timer))
        {
            int driveEffort[LID_CHANNEL_COUNT];
            int channel;

            for(channel = 0; channel < LID_CHANNEL_COUNT; channel++)
            {
                if(!testCurrentTemperature(FIRST_LID_CHANNEL + channel, selfTestData.lidThermalTest.targetTemp, maxTargetDelta,
                                           errorDesc, ERROR_DESC_SIZE))
                {
                    sendInfoStatus(TestDevice_LidThermal, err_lidThermalHeatingTestFailure, errorDesc);
                    selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
                    return true;
                }
            }


            if(!testCurrentDriveEffort(LIDCENTER_CHANNEL, &driveEffort[0],
                                       expectedCenterDriveEffort, maxDriveEffortDelta,
                                       errorDesc, ERROR_DESC_SIZE))
            {
                sendInfoStatus(TestDevice_LidThermal, err_lidThermalHeatingTestFailure, errorDesc);
                selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
                return true;
            }

            if(!testCurrentDriveEffort(LIDRING_CHANNEL, &driveEffort[1],
                                       expectedRingDriveEffort, maxDriveEffortDelta,
                                       errorDesc, ERROR_DESC_SIZE))
            {
                sendInfoStatus(TestDevice_LidThermal, err_lidThermalHeatingTestFailure, errorDesc);
                selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
                return true;
            }

            //TODO: send log information with lidThermal drive effort

            selfTestData.lidThermalTest.passed = true;
            selfTestData.lidThermalTest.state  = LidThermalTestState_Completed;
            sendInfoStatus(TestDevice_LidThermal, err_noError, NULL);
        }

        return true;


    case LidThermalTestState_Completed:
        resetTempControl(ALL_LID_CHANNELS);
        printf("Lid Thermal test complete - %s\n", selfTestData.lidThermalTest.passed ? "passed" : "failed");
        completeTest();
        return false;

    default:
        break;
    }

    return false;
}



static void lidThermalSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    const uint32 heatHoldTime_ms = 30000;

    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_LidThermal, error, errorDesc);
        selfTestData.lidThermalTest.state = LidThermalTestState_Completed;
        return;
    }

    switch(selfTestData.lidThermalTest.state)
    {
    case LidThermalTestState_HeatingRamping:
        startTimer(&selfTestData.lidThermalTest.timer, MSEC_TO_TICKS(heatHoldTime_ms));
        selfTestData.lidThermalTest.state = LidThermalTestState_HeatingCheck;
        break;

    case LidThermalTestState_Idle:
    case LidThermalTestState_Starting:
    case LidThermalTestState_Calibration:
    case LidThermalTestState_Ambient:
    case LidThermalTestState_HeatingSet:
    case LidThermalTestState_HeatingCheck:
    case LidThermalTestState_Completed:
    default:
        break;
    }
}





////   Heat Sink Fan Self Test   /////////////////////

static bool heatsinkFanSelfTestTask(void* unused)
{
    const int dutyCycle    = 500;
    const int startupTicks = SEC_TO_TICKS(10);
    const int retryTicks   = SEC_TO_TICKS(1);
    const int minimumRPM   = 2400; // 80% of the target of 3000 RPM.
    const int maxSlowCount = 5;

    switch(selfTestData.heatsinkFanTest.state)
    {
    case HeatsinkFanTestState_Idle:
        break;

    case HeatsinkFanTestState_Starting:
        if(!fanIsControllable())
        {
            sendInfoStatus(TestDevice_HeatsinkFan,
                           err_selfTestSkipped, "Not Implemented");
            selfTestData.heatsinkFanTest.state = HeatsinkFanTestState_Completed;
        }
        else
        {
            selfTestData.heatsinkFanTest.slowCount = 0;
            setFanDutyCycle(FAN_BLOCK, dutyCycle);
            startTimer(&selfTestData.heatsinkFanTest.timer, startupTicks);
            selfTestData.heatsinkFanTest.state = HeatsinkFanTestState_Running;
        }
        return true;

    case HeatsinkFanTestState_Running:
        if(timerExpired(&selfTestData.heatsinkFanTest.timer))
        {
            int fanRPM = getFanRPM(FAN_BLOCK);
            if( fanRPM > minimumRPM )
            {
                selfTestData.heatsinkFanTest.passed = true;
                selfTestData.heatsinkFanTest.state =
                    HeatsinkFanTestState_Completed;
                sendInfoStatus(TestDevice_HeatsinkFan, err_noError, NULL);
            }
            else
            {
                if(++selfTestData.heatsinkFanTest.slowCount < maxSlowCount)
                {
                    startTimer(&selfTestData.heatsinkFanTest.timer, retryTicks);
                }
                else
                {
                    const int errorMsgSize = 50;
                    char errorMsg[errorMsgSize];
                    snprintf(errorMsg, errorMsgSize, "Minimum RPM = %d, Actual RPM = %d", minimumRPM, fanRPM);
                    sendInfoStatus(TestDevice_HeatsinkFan,
                                   err_blockHeatSinkFanLowRPM, errorMsg);

                    selfTestData.heatsinkFanTest.state =
                        HeatsinkFanTestState_Completed;
                }
            }
        }
        return true;

    case HeatsinkFanTestState_Completed:
        completeTest();
        break;

    default:
        break;
    }

    return false;
}






////   Filter Wheel Motion Self Test   /////////////////////

static bool filterWheelMotionSelfTestTask(void* unused)
{
    switch(selfTestData.filterWheelMotionTest.state)
    {
    case FilterWheelMotionTestState_Idle:
        break;

    case FilterWheelMotionTestState_Starting:
        if(!motionInitFilter(filterWheelMotionSelfTestCallback, TestDevice_FilterWheelMotion))
        {
            filterWheelMotionSelfTestCallback(TestDevice_FilterWheelMotion, err_filterInitializationFailure, "Filter busy");
            selfTestData.filterWheelMotionTest.state = FilterWheelMotionTestState_Completed;
        }
        else
        {
            selfTestData.filterWheelMotionTest.state = FilterWheelMotionTestState_Running;
        }

        return true;

    case FilterWheelMotionTestState_Running:
        //TODO: Timeout?
        return true;

    case FilterWheelMotionTestState_Completed:
        completeTest();
        break;

    default:
        break;
    }

    return false;
}



static void filterWheelMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_FilterWheelMotion, error, errorDesc);
        selfTestData.filterWheelMotionTest.state = FilterWheelMotionTestState_Completed;
        return;
    }

    switch(selfTestData.filterWheelMotionTest.state)
    {
    case FilterWheelMotionTestState_Running:
        selfTestData.filterWheelMotionTest.state = FilterWheelMotionTestState_Completed;
        sendInfoStatus(TestDevice_FilterWheelMotion, err_noError, NULL);
        break;

    case FilterWheelMotionTestState_Idle:
    case FilterWheelMotionTestState_Starting:
    case FilterWheelMotionTestState_Completed:
    default:
        break;
    }
}






////   Lid Motion Self Test   /////////////////////

static bool lidMotionSelfTestTask(void* unused)
{
    switch(selfTestData.lidMotionTest.state)
    {
    case LidMotionTestState_Idle:
        break;

    case LidMotionTestState_Starting:
        // Wait for filter to complete
        if(selfTestData.filterWheelMotionTest.state == FilterWheelMotionTestState_Completed)
        {
            if(!motionInitLid(lidMotionSelfTestCallback, TestDevice_LidMotion))
            {
                lidMotionSelfTestCallback(TestDevice_LidMotion, err_lidInitializationFailure, "Lid busy");
                selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
            }
            else
            {
                selfTestData.lidMotionTest.state = LidMotionTestState_InitHome;
            }
        }

        return true;

    case LidMotionTestState_InitHome:
        //TODO: Timeout?
        return true;

    case LidMotionTestState_WaitingOnDoor:
        // Wait for door to close
        //TODO: Timeout?
        if(selfTestData.doorMotionTest.state == DoorMotionTestState_WaitingForLid)
        {
            selfTestData.lidMotionTest.state = LidMotionTestState_WaitingOnBlock;
        }
        else if(selfTestData.doorMotionTest.state == DoorMotionTestState_Completed)
        {
            sendInfoStatus(TestDevice_LidMotion, err_selfTestSkipped, "Can't complete lid test");
            selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
        }

        return true;

    case LidMotionTestState_WaitingOnBlock:
        // Wait for block test to complete
        //TODO: Timeout?
        if(selfTestData.blockTest.state == BlockTestState_Completed)
        {
            DoorPosition doorPosition = getDoorPosition();

            if(doorPosition == door_closed)
            {
                lowerLid(lidMotionSelfTestCallback, TestDevice_LidMotion);
                selfTestData.lidMotionTest.state = LidMotionTestState_Lowering;
            }
            else
            {
                sendInfoStatus(TestDevice_LidMotion, err_lidCannotMoveDoorNotClosed, "Door not closed - can't move lid");
                selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
            }
        }

        return true;

    case LidMotionTestState_Lowering:
        //TODO: Timeout?
        return true;

    case LidMotionTestState_WaitingOnIllumination:
        if(selfTestData.illuminationTest.state == IlluminationTestState_Completed)
        {
            selfTestData.lidMotionTest.state = LidMotionTestState_StartRaising;
        }
        return true;

    case LidMotionTestState_StartRaising:
        {
            DoorPosition doorPosition = getDoorPosition();

            if(doorPosition == door_closed)
            {
                raiseLid(lidMotionSelfTestCallback, TestDevice_LidMotion);
                selfTestData.lidMotionTest.state = LidMotionTestState_Raising;
            }
            else
            {
                sendInfoStatus(TestDevice_LidMotion, err_lidRaiseFailure, "Door not closed");
                selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
            }
        }
        return true;

    case LidMotionTestState_Raising:
        //TODO: Timeout?
        return true;

    case LidMotionTestState_Completed:
        completeTest();
        break;

    default:
        break;
    }

    return false;
}



static void lidMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_LidMotion, error, errorDesc);
        selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
        return;
    }

    switch(selfTestData.lidMotionTest.state)
    {
    case LidMotionTestState_InitHome:
        selfTestData.lidMotionTest.state = LidMotionTestState_WaitingOnDoor;
        break;

    case LidMotionTestState_Lowering:
        {
            LidPosition lidPosition = getLidPosition();

            if(lidPosition == lid_lowered)
            {
                selfTestData.lidMotionTest.state = LidMotionTestState_WaitingOnIllumination;
            }
            else
            {
                sendInfoStatus(TestDevice_LidMotion, err_lidLowerFailure, "Lid did not lower");
                selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
            }
        }
        break;

    case LidMotionTestState_Raising:
        selfTestData.lidMotionTest.state = LidMotionTestState_Completed;
        sendInfoStatus(TestDevice_LidMotion, err_noError, NULL);
        break;

    case LidMotionTestState_Idle:
    case LidMotionTestState_Starting:
    case LidMotionTestState_WaitingOnDoor:
    case LidMotionTestState_WaitingOnBlock:
    case LidMotionTestState_WaitingOnIllumination:
    case LidMotionTestState_StartRaising:
    case LidMotionTestState_Completed:
    default:
        break;
    }
}




////   Door Motion Self Test   /////////////////////

static bool doorMotionSelfTestTask(void* unused)
{
    switch(selfTestData.doorMotionTest.state)
    {
    case DoorMotionTestState_Idle:
        break;

    case DoorMotionTestState_Starting:
        // Wait for lid to complete init
        if(selfTestData.lidMotionTest.state == LidMotionTestState_Completed)
        {
            doorMotionSelfTestCallback(TestDevice_DoorMotion, err_selfTestSkipped, "Lid motion test did not complete - Can't complete door test");
            selfTestData.doorMotionTest.state = DoorMotionTestState_Completed;
        }
        else if(selfTestData.lidMotionTest.state == LidMotionTestState_WaitingOnDoor)
        {
            if(!motionInitDoor(doorMotionSelfTestCallback, TestDevice_DoorMotion))
            {
                selfTestData.doorMotionTest.passed = false;
                selfTestData.doorMotionTest.state  = DoorMotionTestState_Completed;
            }
            else
            {
                selfTestData.doorMotionTest.state = DoorMotionTestState_InitHome;
            }
        }

        return true;

    case DoorMotionTestState_InitHome:
        //TODO: Timeout?
        return true;

    case DoorMotionTestState_StartClose:
        closeDoor(doorMotionSelfTestCallback, TestDevice_DoorMotion);
        selfTestData.doorMotionTest.state = DoorMotionTestState_Closing;
        return true;

    case DoorMotionTestState_Closing:
        //TODO: Timeout?
        return true;

    case DoorMotionTestState_WaitingForLid:
        // Wait for lid to complete self test
        //TODO: Timeout?
        if(selfTestData.lidMotionTest.state == LidMotionTestState_Completed)
        {
            LidPosition lidPosition = getLidPosition();

            if(lidPosition == lid_raised)
            {
                openDoor(doorMotionSelfTestCallback, TestDevice_DoorMotion);
                selfTestData.doorMotionTest.state = DoorMotionTestState_Opening;
            }
            else
            {
                doorMotionSelfTestCallback(TestDevice_DoorMotion, err_doorOpenFailure, "Lid not raised");
                selfTestData.doorMotionTest.state = DoorMotionTestState_Completed;
            }
        }

        return true;

    case DoorMotionTestState_Opening:
        //TODO: Timeout?
        return true;

    case DoorMotionTestState_Completed:
        completeTest();
        break;

    default:
        break;
    }

    return false;
}





static void doorMotionSelfTestCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_DoorMotion, error, errorDesc);
        selfTestData.doorMotionTest.state = DoorMotionTestState_Completed;
        return;
    }

    DoorPosition doorPosition;

    switch(selfTestData.doorMotionTest.state)
    {
    case DoorMotionTestState_InitHome:
        selfTestData.doorMotionTest.state = DoorMotionTestState_StartClose;
        break;

    case DoorMotionTestState_Closing:
        doorPosition = getDoorPosition();

        if(doorPosition == door_closed)
        {
            selfTestData.doorMotionTest.state = DoorMotionTestState_WaitingForLid;
        }
        else
        {
            sendInfoStatus(TestDevice_DoorMotion, err_doorCloseFailure, "Door not closed");
            selfTestData.doorMotionTest.state = DoorMotionTestState_Completed;
        }

        break;

    case DoorMotionTestState_Opening:
        doorPosition = getDoorPosition();

        if(doorPosition == door_opened)
        {
            sendInfoStatus(TestDevice_DoorMotion, err_noError, NULL);
        }
        else
        {
            sendInfoStatus(TestDevice_DoorMotion, err_doorCloseFailure, "Door not closed");
        }

        selfTestData.doorMotionTest.state = DoorMotionTestState_Completed;

        break;

    case DoorMotionTestState_StartClose:
    case DoorMotionTestState_WaitingForLid:
    case DoorMotionTestState_Idle:
    case DoorMotionTestState_Starting:
    case DoorMotionTestState_Completed:
    default:
        break;
    }
}




////   Illumination Self Test   /////////////////////

static bool illuminationSelfTestTask(void* unused)
{
    const uint32 settleTime_ms = 1000;
    const float  percentDelta  = 10.0;

    switch(selfTestData.illuminationTest.state)
    {
    case IlluminationTestState_Idle:
        break;

    case IlluminationTestState_Starting:
        turnOffIllumination(ALL_ILLUMINATION);
        selfTestData.illuminationTest.state = IlluminationTestState_WaitingOnCavity;
        return true;

    case IlluminationTestState_WaitingOnCavity:
        if(selfTestData.lidMotionTest.state == LidMotionTestState_WaitingOnIllumination)
        {
            selfTestData.illuminationTest.state = IlluminationTestState_TestBlueStart;
        }
        else if(selfTestData.lidMotionTest.state == LidMotionTestState_Completed)
        {
            const char* msg = "Lid motion test did not complete - Can't complete LED test";
            sendInfoStatus(TestDevice_IlluminationBlue, err_selfTestSkipped, msg);
            sendInfoStatus(TestDevice_IlluminationGreen, err_selfTestSkipped, msg);
            sendInfoStatus(TestDevice_IlluminationOrange, err_selfTestSkipped, msg);
            sendInfoStatus(TestDevice_IlluminationRed, err_selfTestSkipped, msg);
            sendInfoStatus(TestDevice_IlluminationCrimson, err_selfTestSkipped, msg);

            selfTestData.illuminationTest.state = IlluminationTestState_Completed;
        }

        return true;

    case IlluminationTestState_TestBlueStart:
        illuminationSelfTestTurnOnLED(BLUE_ILLUMINATION);
        startTimer(&selfTestData.illuminationTest.timer, MSEC_TO_TICKS(settleTime_ms));
        selfTestData.illuminationTest.state = IlluminationTestState_TestBlueCheck;

        return true;

    case IlluminationTestState_TestBlueCheck:
        if(timerExpired(&selfTestData.illuminationTest.timer))
        {
            selfTestData.illuminationTest.bluePassed =
                illuminationSelfTestVerifyLED(BLUE_ILLUMINATION, TestDevice_IlluminationBlue, percentDelta);
            selfTestData.illuminationTest.state = IlluminationTestState_TestGreenStart;
        }

        return true;

    case IlluminationTestState_TestGreenStart:
        illuminationSelfTestTurnOnLED(GREEN_ILLUMINATION);
        startTimer(&selfTestData.illuminationTest.timer, MSEC_TO_TICKS(settleTime_ms));
        selfTestData.illuminationTest.state = IlluminationTestState_TestGreenCheck;

        return true;

    case IlluminationTestState_TestGreenCheck:
        if(timerExpired(&selfTestData.illuminationTest.timer))
        {
            selfTestData.illuminationTest.greenPassed =
                illuminationSelfTestVerifyLED(GREEN_ILLUMINATION, TestDevice_IlluminationGreen, percentDelta);
            selfTestData.illuminationTest.state = IlluminationTestState_TestOrangeStart;
        }

        return true;

    case IlluminationTestState_TestOrangeStart:
        illuminationSelfTestTurnOnLED(ORANGE_ILLUMINATION);
        startTimer(&selfTestData.illuminationTest.timer, MSEC_TO_TICKS(settleTime_ms));
        selfTestData.illuminationTest.state = IlluminationTestState_TestOrangeCheck;

        return true;

    case IlluminationTestState_TestOrangeCheck:
        if(timerExpired(&selfTestData.illuminationTest.timer))
        {
            selfTestData.illuminationTest.orangePassed =
                illuminationSelfTestVerifyLED(ORANGE_ILLUMINATION, TestDevice_IlluminationOrange, percentDelta);
            selfTestData.illuminationTest.state = IlluminationTestState_TestRedStart;
        }

        return true;

    case IlluminationTestState_TestRedStart:
        illuminationSelfTestTurnOnLED(RED_ILLUMINATION);
        startTimer(&selfTestData.illuminationTest.timer, MSEC_TO_TICKS(settleTime_ms));
        selfTestData.illuminationTest.state = IlluminationTestState_TestRedCheck;

        return true;

    case IlluminationTestState_TestRedCheck:
        if(timerExpired(&selfTestData.illuminationTest.timer))
        {
            selfTestData.illuminationTest.redPassed =
                illuminationSelfTestVerifyLED(RED_ILLUMINATION, TestDevice_IlluminationRed, percentDelta);
            selfTestData.illuminationTest.state = IlluminationTestState_TestCrimsonStart;
        }

        return true;

    case IlluminationTestState_TestCrimsonStart:
        illuminationSelfTestTurnOnLED(CRIMSON_ILLUMINATION);
        startTimer(&selfTestData.illuminationTest.timer, MSEC_TO_TICKS(settleTime_ms));
        selfTestData.illuminationTest.state = IlluminationTestState_TestCrimsonCheck;

        return true;

    case IlluminationTestState_TestCrimsonCheck:
        if(timerExpired(&selfTestData.illuminationTest.timer))
        {
            selfTestData.illuminationTest.crimsonPassed =
                illuminationSelfTestVerifyLED(CRIMSON_ILLUMINATION, TestDevice_IlluminationCrimson, percentDelta);
            selfTestData.illuminationTest.state = IlluminationTestState_Completed;
        }

        return true;

    case IlluminationTestState_Completed:
        completeTest();
        break;

    default:
        break;
    }

    return false;
}


static void illuminationSelfTestTurnOnLED(IlluminationColor color)
{
    turnOffIllumination(ALL_ILLUMINATION);
    turnOnIllumination(color, false, NULL, 0);
}


static bool illuminationSelfTestVerifyLED(IlluminationColor color, TestDevices device, float deltaPercent)
{
    uint16 calibration;
    uint16 delta;
    uint16 primaryFeedback   = getIlluminationFeedback(true);
//    uint16 secondaryFeedback = getIlluminationFeedback(false);

    turnOffIllumination(ALL_ILLUMINATION);

    if(!getIlluminationCalibration(color, &calibration))
    {
        sendInfoStatus(device, err_ledNotCalibrated, NULL);
        return false;
    }

    delta = (uint16)(calibration * deltaPercent / 100.0);

    if(primaryFeedback < calibration - delta || primaryFeedback > calibration + delta)
    {
        char errorDesc[ERROR_DESC_SIZE];
        snprintf(errorDesc, ERROR_DESC_SIZE,
                 "%s LED Primary Feedback Out of range (+/- %.01f%%)"
                 " - Calibration 0x%04x, Primary Feedback 0x%04x",
                 getIlluminationName(color), deltaPercent, calibration, primaryFeedback);
        sendInfoStatus(device, err_ledControlFailure, errorDesc);
        return false;
    }
//TODO: Check secondary feedback sensor
//    else if(secondaryFeedback < calibration - delta || secondaryFeedback > calibration + delta)
//    {
//        char errorDesc[ERROR_DESC_SIZE];
//        snprintf(errorDesc, ERROR_DESC_SIZE,
//                 "%s LED Secondary Feedback Out of range (+/- %.01f%%)"
//                 " - Calibration 0x%04x, Secondary Feedback 0x%04x",
//                 getIlluminationName(color), deltaPercent, calibration, secondaryFeedback);
//        sendInfoStatus(device, err_ledActiveControlFailure, errorDesc);
//        return false;
//    }
    else
    {
        sendInfoStatus(device, err_noError, NULL);
        return true;
    }
}



// EOF
