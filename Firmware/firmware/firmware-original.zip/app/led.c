/////////////////////////////////////////////////////////////
//
//  led.c
//
//  Xilinx Spartan-3A FPGA Starter Kit LED Driver
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#include <led.h>
#include <xparameters.h>
#include <timer.h>
#include <processor.h>
#include <system.h>



///////////////////////////////////////////////////
// Constants

#define HEARTBEAT_PERIOD_ms    MSEC_TO_TICKS(2000)
#define COMM_ACTIVITY_ON_TIME  MSEC_TO_TICKS(100)

#define HEARTBEAT_LED_MASK     0x80
#define COMM_ACTIVITY_LED_MASK 0x01



///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    Timer         heartbeatTimer;
    Timer         commActivityTimer;
    volatile bool commLedOn;
} LedData;



///////////////////////////////////////////////////
// Local function prototypes



///////////////////////////////////////////////////
// Local data

static LedData ledData;



///////////////////////////////////////////////////
// Interface functions

void ledInit()
{
    SYSTEM.activityLED  = LED_OFF;
    SYSTEM.heartbeatLED = LED_OFF;

    ledData.commLedOn   = false;
    
    startTimer(&ledData.heartbeatTimer, 0);
    startTimer(&ledData.commActivityTimer, 0);
}



bool ledProcess(void* unused)
{
    if(timerExpired(&ledData.heartbeatTimer))
    {
        SYSTEM.heartbeatLED = ~SYSTEM.heartbeatLED;
        startTimer(&ledData.heartbeatTimer, HEARTBEAT_PERIOD_ms / 2);
    }

    if(ledData.commLedOn && timerExpired(&ledData.commActivityTimer))
    {
        ledData.commLedOn = false;
        SYSTEM.activityLED = LED_OFF;
    }

    return true;
}



void setCommActivityLed()
{
    ledData.commLedOn = true;
    SYSTEM.activityLED = LED_ON;
    startTimer(&ledData.commActivityTimer, COMM_ACTIVITY_ON_TIME);
}



///////////////////////////////////////////////////
// Local functions



// EOF



