/////////////////////////////////////////////////////////////
//
//  fan.h
//
//  Fan Driver
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#ifndef fan_h
#define fan_h

#include <types.h>

#define FAN_BLOCK 0

#define FAN_PWM_MIN_FREQUENCY   100
#define FAN_PWM_MAX_FREQUENCY   1000000
#define FAN_TACH_MIN_FREQUENCY  1
#define FAN_TACH_MAX_FREQUENCY  1000


void fanInit(void);
void fanAbort(void);
void fanReset(void);

void setFanDutyCycle(int fan, int percentDutyCycle);
int  getFanDutyCycle(int fan);

void setFanPWMFrequency(int fan, int frequency_hz);
int  getFanPWMFrequency(int fan);

void setFanTachFrequency(int fan, int frequency_hz);
int  getFanTachFrequency(int fan);
int  getFanTachCount(int fan);
int  getFanRPM(int fan);
bool fanIsControllable();

#endif
