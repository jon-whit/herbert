/////////////////////////////////////////////////////////////
//
//  control.h
//
//  Plate Cycler control loop
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#ifndef control_h
#define control_h

#include <types.h>
#include <pwm.h>
#include <comm.h>


#define MIN_RAMP_RATE_C_s            0.001
#define MAX_RAMP_RATE_C_s            6.000
#define MIN_LID_RAMP_RATE_C_s        0.100
#define MAX_LID_RAMP_RATE_C_s        2.000

#define BLOCK_CHANNEL_COUNT PWM_BLOCK_CHANNEL_COUNT
#define LID_CHANNEL_COUNT   PWM_LID_CHANNEL_COUNT

#define FIRST_CHANNEL       (0)

#define FIRST_BLOCK_CHANNEL FIRST_CHANNEL
#define LAST_BLOCK_CHANNEL  (FIRST_BLOCK_CHANNEL + BLOCK_CHANNEL_COUNT - 1)

#define FIRST_LID_CHANNEL   BLOCK_CHANNEL_COUNT
#define LAST_LID_CHANNEL    (FIRST_LID_CHANNEL + LID_CHANNEL_COUNT - 1)

#define LIDCENTER_CHANNEL   (FIRST_LID_CHANNEL + 0)
#define LIDRING_CHANNEL     (FIRST_LID_CHANNEL + 1)

#define AMBIENT_CHANNEL     (BLOCK_CHANNEL_COUNT + LID_CHANNEL_COUNT + 0)
#define HEAT_SINK_CHANNEL   (BLOCK_CHANNEL_COUNT + LID_CHANNEL_COUNT + 1)

#define CHANNEL_COUNT       (HEAT_SINK_CHANNEL + 1)

#define ALL_BLOCK_CHANNELS  (-2)
#define ALL_LID_CHANNELS    (-3)
#define ALL_CHANNELS        (-4)

#define INVALID_PWM_CHANNEL (PWM_BLOCK_CHANNEL_COUNT + PWM_LID_CHANNEL_COUNT)
#define INVALID_TEMP_SENSOR (TEMP_SENSOR_COUNT)

#define NUM_CUSTOM_RAMPS     2
#define MAX_RAMP_SIZE        40000

typedef enum
{
    CAL_TYPE_PCR_SAMPLE = 0,
    CAL_TYPE_PCR_BLOCK  = 1,
    CAL_TYPE_SDA_SAMPLE = 2,
    CAL_TYPE_SDA_BLOCK  = 3
} calibrationType;

typedef enum
{
    LINEAR_SAMPLE_MODEL,
    SMOOTH_SAMPLE_MODEL,
    HEATBLOCK,
    HEATED_LID_CENTER,
    HEATED_LID_RING
} gainType;

typedef enum { pwmCurrent, pwmMax, pwmMin } pwmType;



void   controlInit(void);
void   controlStart(void);
void   controlStop(void);

uint32 getBlockCycleCount(void);


bool   setTargetTemp(int channel, float targetTemp,
                     OfflineTaskCompleteCallback callbackFunc, int callbackRef);
float  getTargetTemp(int channel);
float  getCurrentTemp(int channel);
uint16 getRawReading(int channel);
int    getPwm(int channel, pwmType type);
void   setRampRate(int channel, float rampRate);
float  getRampRate(int channel);
void   resetRampRate(int channel);
void   setDefaultRampRate(float rampRate);
float  getDefaultRampRate();
void   resetDefaultRampRate();

void   resetTempControl(int channel);

void   enableChannel(int channel);
void   disableChannel(int channel);
void   enablePwmControl(int channel, int dutyCycle_tenthPercent);
bool   blockControlEnabled(void);
bool   lidControlEnabled(void);

void   setPGain(gainType type, float pGain);
void   setIGain(gainType type, float iGain);
void   setIMax(gainType type, float iMax);
void   setIMin(gainType type, float iMin);
void   setDGain(gainType type, float dGain);
void   setFGain(gainType type, float fGain);
float  getPGain(gainType type);
float  getIGain(gainType type);
float  getIMax(gainType type);
float  getIMin(gainType type);
float  getDGain(gainType type);
float  getFGain(gainType type);
void   setReportModelTemp( bool enable );

void   enableModel( bool enable );
void   setCalibrationType( calibrationType calType );
void   transitionCalibration( bool lidIsLowered );
calibrationType getCalibrationType( void );

void   setWatchRaw(int channel);
void   setWatchChannel(int channel);
void   setPidMonitorChannel(int channel);
void   setTemperatureStreaming( bool stream );
void   toggleVarianceCheck( bool enable );
void   toggleTemperatureRamping( bool enable );
void   toggleSmoothRamp( bool enable );
bool   getSmoothRampEnabled( void );

bool   setSampleVolume( int volume );
int    getSampleVolume( void );
bool   setModel( bool pcr, bool sample, int volume );

bool   customRamp(int ramp, int channel,
                  OfflineTaskCompleteCallback callbackFunc, int callbackRef);
bool   setCustomRampData(int ramp, int index, float value);
bool   getCustomRampData(int ramp, int index, float *value);

void   bypassChannel(int channel, bool bypass);
#endif
