//-----------------------------------------------------------------------------
//! \file
//!
//! \brief Temperature Model
//!
//! This file contains the temperature model module that converts a
//! measured sensor temperature to a modeled sample temperature.
//!
//! Our temperature model is the following second-order transfer function:
//!
//!   H(s) = (s+w1) / ((s+w2)*(s+w3)).
//!
//! We convert it to the discrete-time domain via the bilinear transformation:
//!
//!   s = (2/T)*(z-1)/(z+1).
//!
//! This gives us the following equation in the time-domain:
//!
//!   y[n] = (w2*w3/w1) * ( (A/D) * x[n] + (B/D) * x[n-1] + (C/D) * x[n-2] ) - 
//!          (E/D) * y[n-1] - (F/D) * y[n-2].
//!
//! Where the coefficients are given by:
//!
//!   A = 2/T + w1,
//!   B = 2*w1,
//!   C = w1 - 2/T,
//!   D = 4/(T^2) + (2/T)*(w2+w3) + w2*w3,
//!   E = 2*w2*w3 - 8/(T^2), and
//!   F = 4/(T^2) - (2/T)*(w2+w3) + w2*w3.
//!
//! To reduce the math performed during the control loop, we simplify the
//! equation to the following:
//!
//!   y[n] = a * x[n] + b * x[n-1] + c * x[n-2] - d * y[n-1] - e * y[n-2].
//!
//! Where:
//!
//!   a = w2*w3/w1 * A/D,
//!   b = w2*w3/w1 * B/D,
//!   c = w2*w3/w1 * C/D,
//!   d = E/D, and
//!   e = F/D.
//!
//! We can then calculate these coefficients a priori to simplify the
//! calculation required during the control loop.
//!
//! Copyright (c) 2009 Idaho Technology Inc.
//-----------------------------------------------------------------------------

#include <model.h>
#include <assert.h>
#include <control.h>
#include <sensors.h>
#include <string.h>
#include <stdio.h>
#include <comm.h>


///////////////////////////////////////////////////
// Constants

#define w1_50uLHeating 6.0
#define w2_50uLHeating 0.084
#define w3_50uLHeating 0.5

#define w1_50uLCooling 6.0
#define w2_50uLCooling 0.083
#define w3_50uLCooling 0.65

#define w1_25uLHeating 2.0
#define w2_25uLHeating 0.125
#define w3_25uLHeating 0.55

#define w1_25uLCooling 2.0
#define w2_25uLCooling 0.120
#define w3_25uLCooling 0.4


const float minTemp          = -20.0;
const float maxTemp          = 150.0;

enum { numParams = 3 };

///////////////////////////////////////////////////
// Local types and macros

typedef enum
{
    subHeating,
    subCooling,
    numSubModels
} ModelSubType;


///////////////////////////////////////////////////
// Local function prototypes

static void            calculateModelCoefficients( ModelParams_t * model );
static ModelParams_t * getModelParamsPtr( int channel, ModelType type, bool heating );
static float *         getModelParamPtr( ModelParams_t * model, int paramIndex );
static bool            getNonVolModelParam( int channel, ModelType type,
                                            ModelSubType subType, int param, float *value );
static void            setNonVolModelParam( int channel, ModelType type,
                                            ModelSubType subType, int param, float value );
static uint16          findNVOffset( int channel, ModelType type,
                                     ModelSubType subType, int param );


///////////////////////////////////////////////////
// Local data

static const float defaultModelParams[ numModels ][ numSubModels ][ numParams ] =
{
    {
        { w1_25uLHeating, w2_25uLHeating, w3_25uLHeating },
        { w1_25uLCooling, w2_25uLCooling, w3_25uLCooling }
    },
    {
        { w1_50uLHeating, w2_50uLHeating, w3_50uLHeating },
        { w1_50uLCooling, w2_50uLCooling, w3_50uLCooling }        
    }
};

static ModelParams_t modelParams[ BLOCK_CHANNEL_COUNT ][ numModels ][ numSubModels ];


///////////////////////////////////////////////////
// Interface functions

//-----------------------------------------------------------------------------
void modelInit( void )
{
    int          channel;
    ModelType    type;
    ModelSubType subType;
    bool         foundModelParam = sensorsNVValidateModelDataCRC();

    for( channel = 0; channel < BLOCK_CHANNEL_COUNT; ++channel )
    {
        for( type = ( ModelType )0;
             type != numModels;
             type = ( ModelType )( type + 1 ) )
        {
            for( subType = ( ModelSubType )0;
                 subType != numSubModels;
                 subType = ( ModelSubType )( subType + 1 ) )
            {
                ModelParams_t * model = &modelParams[ channel ][ type ][ subType ];

                if( foundModelParam )
                {
                    foundModelParam  = getNonVolModelParam( channel, type, subType, 0, &model->w1 );
                    foundModelParam |= getNonVolModelParam( channel, type, subType, 1, &model->w2 );
                    foundModelParam |= getNonVolModelParam( channel, type, subType, 2, &model->w3 );
                }
                else
                {
                    model->w1 = defaultModelParams[ type ][ subType ][ 0 ];
                    model->w2 = defaultModelParams[ type ][ subType ][ 1 ];
                    model->w3 = defaultModelParams[ type ][ subType ][ 2 ];
                }

                calculateModelCoefficients( model );
            }
        }
    }

    if( foundModelParam )
    {
        sendLogMsg( "Found model parameters on block - not using defaults" );
    }
}

//-----------------------------------------------------------------------------
void modelDataInit( Model_t * model, ModelType type,
                    int channel, float temperature )
{
    int i;

    ASSERT( model && ( type < numModels ) && ( channel < BLOCK_CHANNEL_COUNT ) );

    model->heatingParams = &modelParams[ channel ][ type ][ subHeating ];
    model->coolingParams = &modelParams[ channel ][ type ][ subCooling ];

    for( i = 0; i <= MODEL_ORDER; ++i )
    {
        model->data.x[ i ] = ( double )temperature;
        model->data.y[ i ] = ( double )temperature;
    }
}

//-----------------------------------------------------------------------------
float modelTemp( Model_t * model, float currentTemp )
{
    ModelParams_t * modelParams =
        model->data.y[0] > model->data.y[1] ? model->heatingParams :
                                              model->coolingParams;

    // age the data 
    model->data.y[2] = model->data.y[1];
    model->data.y[1] = model->data.y[0];
    model->data.x[2] = model->data.x[1];
    model->data.x[1] = model->data.x[0];
    model->data.x[0] = currentTemp;

    // apply 2nd order filter/model
    model->data.y[0] =
        modelParams->a * model->data.x[0] + 
        modelParams->b * model->data.x[1] + 
        modelParams->c * model->data.x[2] - 
        modelParams->d * model->data.y[1] - 
        modelParams->e * model->data.y[2];

    // sanity check on the new temperature value
    if ( model->data.y[0] <= minTemp )
        model->data.y[0] = minTemp;
    else if ( model->data.y[0] >= maxTemp )
        model->data.y[0] = maxTemp;

    return model->data.y[0];
}

//-----------------------------------------------------------------------------
void setModelParam( int channel, ModelType type, bool heating,
                    int paramIndex, float value, bool persist )
{
    ModelParams_t * model = getModelParamsPtr( channel, type, heating );

    *getModelParamPtr( model, paramIndex ) = value;

    calculateModelCoefficients( model );

    if( persist )
    {
        setNonVolModelParam( channel, type, heating ? subHeating : subCooling,
                             paramIndex, value );
    }
}

//-----------------------------------------------------------------------------
bool getModelParam( int channel, ModelType type,
                    bool heating, int paramIndex, float *value )
{
    return getNonVolModelParam( channel, type,
                                heating ? subHeating : subCooling,
                                paramIndex, value );
}

//-----------------------------------------------------------------------------
void clearModelParams( void )
{
    int          channel;
    ModelType    type;
    ModelSubType subType;

    for( channel = 0; channel < BLOCK_CHANNEL_COUNT; ++channel )
    {
        for( type = ( ModelType )0;
             type != numModels;
             type = ( ModelType )( type + 1 ) )
        {
            for( subType = ( ModelSubType )0;
                 subType != numSubModels;
                 subType = ( ModelSubType )( subType + 1 ) )
            {
                int paramIndex;
                ModelParams_t * model = &modelParams[ channel ][ type ][ subType ];

                model->w1 = defaultModelParams[ type ][ subType ][ 0 ];
                model->w2 = defaultModelParams[ type ][ subType ][ 1 ];
                model->w3 = defaultModelParams[ type ][ subType ][ 2 ];

                calculateModelCoefficients( model );

                for( paramIndex = 0; paramIndex < 3; ++paramIndex )
                {
                    setNonVolModelParam( channel, type, subType, paramIndex, 0 );
                }
            }
        }
    }
}


///////////////////////////////////////////////////
// Local functions

//-----------------------------------------------------------------------------
static void calculateModelCoefficients( ModelParams_t * model )
{
    const double T = 0.05; //!\todo: Use a global project-level definition.

    double A = 2/T + model->w1;
    double B = 2 * model->w1;
    double C = model->w1 - 2/T;
    double D = 4/(T*T) + (2/T) * (model->w2 + model->w3) + model->w2 * model->w3;
    double E = 2 * model->w2 * model->w3 - 8/T/T;
    double F = 4/T/T - 2/T * (model->w2 + model->w3) + model->w2 * model->w3;

    model->a = model->w2 * model->w3 / model->w1 * A / D;
    model->b = model->w2 * model->w3 / model->w1 * B / D;
    model->c = model->w2 * model->w3 / model->w1 * C / D;
    model->d = E / D;
    model->e = F / D;
}

//-----------------------------------------------------------------------------
static ModelParams_t * getModelParamsPtr( int channel, ModelType type, bool heating )
{
    ASSERT( channel < BLOCK_CHANNEL_COUNT );
    ASSERT( type < numModels );

    return heating ? &modelParams[ channel ][ type ][ subHeating ] :
                     &modelParams[ channel ][ type ][ subCooling ];
}

//-----------------------------------------------------------------------------
static float * getModelParamPtr( ModelParams_t * model, int paramIndex )
{
    float * returnValue;

    switch( paramIndex )
    {
    case 0:
        returnValue = &model->w1;
        break;
    case 1:
        returnValue = &model->w2;
        break;
    case 2:
        returnValue = &model->w3;
        break;
    default:
        ASSERT( 0 );
    }

    return returnValue;
}


//-----------------------------------------------------------------------------
static bool getNonVolModelParam( int channel, ModelType type,
                                 ModelSubType subType, int param, float *value )
{
    uint32 intValue = sensorsNVReadModelParam( findNVOffset( channel, type,
                                                             subType, param ) );

    if( intValue == 0xFFFFFFFF )
    {
        *value = defaultModelParams[ type ][ subType ][ param ];
    }
    else
    {
        memcpy( value, &intValue, 4 );

        if( *value >= 0.01 && *value <= 10.0 )
        {
            return true;
        }
        else
        {
            *value = defaultModelParams[ type ][ subType ][ param ];
        }
    }

    return false;
}


//-----------------------------------------------------------------------------
static void setNonVolModelParam( int channel, ModelType type,
                                 ModelSubType subType, int param, float value )
{
    uint32 uintValue;

    memcpy( &uintValue, &value, sizeof(uint32));

    sensorsNVWriteModelParam( findNVOffset( channel, type, subType, param ),
                              uintValue);

    sensorsNVWriteModelDataCRC();
}


//-----------------------------------------------------------------------------
static uint16 findNVOffset( int channel, ModelType type,
                            ModelSubType subType, int param )
{
    // The non-volatile address is given by the following formula:
    //
    //   channel * numModels * numSubModels * numParams * sizeof( uint32 ) +
    //   type    *             numSubModels * numParams * sizeof( uint32 ) +
    //   subType *                            numParams * sizeof( uint32 ) +
    //   param   *                                        sizeof( uint32 )
    //
    // To reduce run-time calculaton, we determine the address via the
    // following factorization:
    //
    //   sizeof( uint32 )  *
    //     ( numParams     *
    //       ( numSubModels *
    //         ( numModels * channel + type ) + subType ) + param );
    //

    return sizeof( uint32 )   *
             ( numParams      *
               ( numSubModels *
                 ( numModels  * channel + type ) + subType ) + param );
}
