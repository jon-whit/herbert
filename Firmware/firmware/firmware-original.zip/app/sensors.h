/////////////////////////////////////////////////////////////
//
//  sensors.h
//
//  Plate Cycler Temperature Sensor Controls
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#ifndef sensors_h
#define sensors_h

#include <types.h>
#include <pwm.h>


#define BLOCK_TEMP_SENSOR_COUNT     PWM_BLOCK_CHANNEL_COUNT
#define LID_TEMP_SENSOR_COUNT       PWM_LID_CHANNEL_COUNT
#define AMBIENT_TEMP_SENSOR_COUNT   1
#define HEAT_SINK_TEMP_SENSOR_COUNT 1

#define TEMP_SENSOR_COUNT             (BLOCK_TEMP_SENSOR_COUNT + LID_TEMP_SENSOR_COUNT + AMBIENT_TEMP_SENSOR_COUNT + HEAT_SINK_TEMP_SENSOR_COUNT)
#define TEMP_SENSOR_CALIBRATION_COUNT 4



#define BLOCK_TEMP_SENSOR0            0
#define BLOCK_TEMP_SENSOR1            1
#define BLOCK_TEMP_SENSOR2            2
#define BLOCK_TEMP_SENSOR3            3
#define BLOCK_TEMP_SENSOR4            4
#define BLOCK_TEMP_SENSOR5            5
#define BLOCK_TEMP_SENSOR6            6
#define BLOCK_TEMP_SENSOR7            7
#define BLOCK_TEMP_SENSOR8            8
#define BLOCK_TEMP_SENSOR9            9
#define BLOCK_TEMP_SENSOR10           10
#define BLOCK_TEMP_SENSOR11           11
#define BLOCK_TEMP_SENSOR12           12
#define BLOCK_TEMP_SENSOR13           13
#define BLOCK_TEMP_SENSOR14           14
#define BLOCK_TEMP_SENSOR15           15
#define BLOCK_TEMP_SENSOR16           16
#define BLOCK_TEMP_SENSOR17           17
#define BLOCK_TEMP_SENSOR18           18
#define BLOCK_TEMP_SENSOR19           19
#define BLOCK_TEMP_SENSOR20           20
#define BLOCK_TEMP_SENSOR21           21
#define BLOCK_TEMP_SENSOR22           22
#define BLOCK_TEMP_SENSOR23           23

#define FIRST_BLOCK_TEMP_SENSOR       BLOCK_TEMP_SENSOR0
#define LAST_BLOCK_TEMP_SENSOR        BLOCK_TEMP_SENSOR23

#define HEATED_LID_CENTER_TEMP_SENSOR 24
#define HEATED_LID_RING_TEMP_SENSOR   25

#define FIRST_HEATED_LID_TEMP_SENSOR  HEATED_LID_CENTER_TEMP_SENSOR
#define LAST_HEATED_LID_TEMP_SENSOR   HEATED_LID_RING_TEMP_SENSOR

#define AMBIENT_TEMP_SENSOR           26
#define HEAT_SINK_TEMP_SENSOR         27


#define MAX_SERIAL_NUM_LEN            33


#define SENSOR_MAX_CAL_POINT          120.0
#define SENSOR_MIN_CAL_POINT          0.0

#define SENSOR_MAX_CAL_VALUE          0xF000
#define SENSOR_MIN_CAL_VALUE          0x0FFF


const char* getSensorName(uint8 sensor);

void   sensorsInit();

void   configSensors();
void   resetSensors();

void   getBlockSerialNumber(char* serialNumber);
void   setBlockSerialNumber(char* serialNumber);

bool   getBlockType(uint8 *blockType);
void   setBlockType(uint8 type);

float  getSensorTemp(uint8 sensor, uint8 calIndex);  // Last read temp
uint16 getSensorRawReading(uint8 sensor);
void   readSensorTemp(uint8 sensor); // Current sensor reading
uint16 readRawSensorReading(uint8 sensor);

void   calibrateSensor(uint8 sensor, bool high, float calPoint, int calIndex);
void   calibrateBlock(bool high, float calPoint, int calIndex);
void   calibrateLid(bool high, float calPoint, int calIndex);
void   setCalibrationPoint(uint8 sensor, bool high, float calPoint, int calIndex);
bool   getCalibrationPoint(uint8 sensor, bool high, int calIndex,
                           bool validateCRC, float *calPoint);

void   setSensorCalibration(uint8 sensor, uint16 lowCalibration,
                            uint16 highCalibration, int calIndex);
bool   getSensorCalibration(uint8 sensor, bool high, int calIndex,
                            bool validateCRC, uint16 *calValue);
bool   validateSensorCalibrationCRCs( void );

uint32 sensorsNVReadModelParam( uint16 address );
void   sensorsNVWriteModelParam( uint16 address, uint32 value );
bool   sensorsNVValidateModelDataCRC( void );
void   sensorsNVWriteModelDataCRC( void );

uint32 sensorsNVReadPerfData( uint16 address );
void   sensorsNVWritePerfData( uint16 address, uint32 value );
bool   sensorsNVValidatePerfDataCRC( void );
void   sensorsNVWritePerfDataCRC( void );

void   sensorsNVWriteAllCRCs( void );

void writeFullScale( uint16 value );
void writeZeroScale( uint16 value );

uint32 sensorsNVReadBlockCycleCount( void );
void   sensorsNVUpdateBlockCycleCount( uint32 cycles );
void   sensorsNVWriteBlockCycleCount( uint32 cycles );

#endif
