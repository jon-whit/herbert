/////////////////////////////////////////////////////////////
//
//  fixedPoint.c
//
//  Fixed-Point Number Utility Functions
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef fixedPoint_h
#define fixedPoint_h



typedef struct
{
    int wholePart;
    int fractionalPart;
} FixedPointInt;



FixedPointInt separateFixedPoint(int fixedPointNumber, int decimalPlaces);



#endif
