/////////////////////////////////////////////////////////////
//
//  led.h
//
//  Xilinx Spartan-3A FPGA Starter Kit LED Driver
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#ifndef led_h
#define led_h

#include <types.h>


void ledInit();

bool ledProcess(void* unused);

void setCommActivityLed();



#endif
