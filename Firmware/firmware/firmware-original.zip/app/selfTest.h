/////////////////////////////////////////////////////////////
//
//  selfTest.h
//
//  Plate Cycler Hardware Self Test
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef selfTest_h
#define selfTest_h

#include <types.h>
#include <comm.h>


void selfTestInit();
bool startSelfTest(OfflineTaskCompleteCallback completedCallbackFunc, OfflineTaskInfoCallback infoCallbackFunc, int callbackRef);
void abortSelfTests();
void selfTestIgnoreErrors();


#endif
