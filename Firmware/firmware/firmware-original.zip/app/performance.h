/////////////////////////////////////////////////////////////
//
//  performance.h
//
//  Plate Cycler Hardware Performance Test
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#ifndef performance_h
#define performance_h

#include <types.h>
#include <comm.h>

typedef enum
{
    BAD_BASELINE,
    FAILED,
    MAJOR,
    MINOR,
    NONE
} PerformanceStatus;

typedef enum
{
    lid   = 0,
    block = 1,
    numThermalTypes
} ThermalType;

typedef enum
{
    cool = 0,
    heat = 1,
    numDirections
} ThermalDirection;

void performanceInit();
bool startPerformanceTest( OfflineTaskCompleteCallback completedCallbackFunc,
                           OfflineTaskInfoCallback     infoCallbackFunc,
                           int                         callbackRef,
                           bool                        baseline );
void abortPerformanceTest();

bool getThermalPerformanceTarget( ThermalType type,
                                  ThermalDirection direction,
                                  float *target );
bool getThermalBaselineEffort( int channel,
                               ThermalDirection direction,
                               int *effort );

#endif
