/////////////////////////////////////////////////////////////
//
//  nvramMap.h
//
//  Map of NVRAM Storage
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef nvramMap_h
#define nvramMap_h




enum NVRAM_MAP
{
    NVRAM_ADDR_DOOR_CLOSED_POSITION     = 0x0000,  //  4 bytes (0x0000-0x0003)
    NVRAM_ADDR_LID_COMPRESSED_POSITION  = 0x0004,  //  4 bytes (0x0004-0x0007)
    NVRAM_ADDR_FPGA_BOARD_SERIAL_NUMBER = 0x0008,  // 32 bytes (0x0008-0x0027)

    NVRAM_ADDR_DEFAULT_RAMP_RATE        = 0x0030,  //  4 bytes (0x0030-0x0033)
    // Reserve enough here for other ramp rates
};


#endif
