/////////////////////////////////////////////////////////////
//
//  comm.c
//
//  Communication Protocol Processor
//
//  Copyright 2008, 2009 Idaho Technology
//  Created by Brett Gilbert
//
//
//  Commands:
//    CMD <Alias> [params]                               - Description
//    --------------------------------------------------------------------------------------------------------
//    GetStatus                                          - Get System status
//    GetActiveState                                     - Get active state (off-line pending and active control)
//    SetPWM <SP> [ch] [H|C] [%PWM]                      - Set PWM channel duty cycle
//    GetPWM [ch]                                        - Get PWM channel duty cycle
//    EnableChannel <EC> [ch]                            - Enable channel temperature control
//    DisableChannel <DC> [ch]                           - Disable channel temperature control
//    SetTargetTemp <ST> [ch] [Temp]                     - Set channel target temperature
//    GetTargetTemp <GT> [ch]                            - Get channel target temperature
//    ReadCurrentTemp <RT> [ch]                          - Read channel current temperature
//    SetPwmFrequency                                    - Set PWM frequency
//    GetPwmFrequency                                    - Get PWM frequency
//    Abort <AB>                                         - Abort current PWM drive
//    GoToIdle                                           - Return instrument to idle state
//    Reset                                              - Reset all PWM settings
//    GetFirmwareVersion <RV>                            - Get firmware version
//    GetFPGAVersion                                     - Get FPGA version
//    GetIllumination                                    - Get current Illumination LEDs state
//    SetIllumination [B|G|O|R|C]...                     - Enable/Disable Illumination LEDs - listed values are on
//    SetIlluminationLowPower [B|G|O|R|C]...             - Enable/Disable Illumination LEDs in low power state
//    GetIlluminationCurrent [B|G|O|R|C]                 - Get the LED current feedback
//    GetIlluminationFeedback [0|1]                      - Get the primary or secondary photo-diode feedback
//    SetIlluminationCalibration [B|G|O|R|C] [cal]       - Set illumination calibration
//    CalibrateIllumination                              - Calibrate current illumination channel
//    GetIlluminationCalibration [B|G|O|R|C]             - Get illumination calibration value
//    InitIllumination                                   - Illumination subsystem
//    SetIlluminationPower [B|G|O|R|C] [power]           - Set the illumination power
//    GetIlluminationPower                               - Get the illumination power
//    SetIlluminationIntensity [B|G|O|R|C] [intensity]   - Set the illumination intensity
//    GetIlluminationIntensity                           - Get the illumination intensity
//    ToggleIlluminationControl [0|1]                    - Toggle closed loop illumination control
//    SetIlluminationGain [B|G|O|R|C] [p|i|d] [Gain]     - Set PID gain (changes are volatile)
//    GetIlluminationGain [B|G|O|R|C] [p|i|d]            - Get PID gain
//    SetIlluminationLowPowerCalibration [B|G|O|R|C] [cal] - Set low power illumination calibration
//    GetIlluminationLowPowerCalibration [B|G|O|R|C]     - Get low power illumination calibration value
//    GetMotorPositions                                  - Gets positions for all motors
//    GetFilterPosition                                  - Get filter position
//    SetFilter [CL|B|G|O|R|C]                           - Set filter position
//    GetDoorPosition                                    - Get current door position
//    OpenDoor                                           - Open Door
//    CloseDoor                                          - Close Door
//    DisableDoor                                        - Disables Door movement
//    GetLidPosition                                     - Get current lid position
//    RaiseLid                                           - Raise Lid
//    LowerLid                                           - Lower Lid
//    OpenCavity                                         - Raise Lid then open Door
//    CloseCavity                                        - Close Door then lower Lid
//    InitSystem                                         - Init All Hardware Systems
//    InitFilter                                         - Init Filter wheel
//    InitLid                                            - Init Heated Lid
//    InitDoor                                           - Init Door
//    FileSend [File Offset] [Data]                      - Upload firmware file portion
//    Upgrade  [File Size] [File CRC]                    - Upgrade firmware with uploaded image
//    UpgradeFPGA  [File Size] [File CRC]                - Upgrade FPGA with uploaded image
//    Calibrate [ch] [high|low] [Cal temp] [Index]       - Start auto high or low calibration at given temp
//    SetCalPoint [ch] [high|low] [Cal Temp] [Index]     - Set high or low calibration temperature
//    SetCal [ch] [Low Cal] [High Cal] [Index]           - Set channel low and high calibration
//    GetCal [ch] [Index]                                - Get channel low and high calibration
//    AdjustCal [ch] [high|low] [Adjustment] [Index]     - Adjust channel high or low gain by adjustment value
//    SetGain [type] [p|i|imax|imin|d|f] [Gain]          - Set PID gain (changes are volatile)
//    GetGain [type] [p|i|imax|imin|d|f]                 - Get PID gain
//    ReadRaw [ch]                                       - Get raw sensor reading
//    Monitor [ch|off]                                   - Monitor current temp and PWM (if channel is active) on LCD
//    MonitorRaw [ch|off]                                - Monitor raw sensor values on LCD
//    MonitorPid [ch|off]                                - Monitor PID values for channel
//    ResetSensors                                       - Reset sensors
//    ReadMem [Address] [Byte Count]                     - Read processor memory
//    GetMemSections                                     - Read memory sections
//    test ...                                           - Debugging test
//    ToggleModel [0|1]                                  - Enable or disable model control
//    SetModel [pcr|sda|pcr_open|pcr_closed|sda_open|sda_closed] (volume) - Set the temperature model and volume
//    GetModel                                           - Get the temperature model
//    SetModelParam [ch] [25h|25c|50h|50c] [w1|w2|w3] [value] - Set the temperature model parameter
//    GetModelParams [ch] [25h|25c|50h|50c]              - Get the temperature model parameters
//    ClearModelParams                                   - Clear all stored model parameters
//    SetSampleVolume                                    - Sets the sample volume
//    GetSampleVolume                                    - Gets the sample volume
//    GetPlateType                                       - Gets the type of plate present on the electroform
//    WriteFull [value]                                  - Write the full-scale register of the ADC's
//    WriteZero [value]                                  - Write the zero-scale register of the ADC's
//    ToggleStreaming [0|1]                              - Enable or disable temperature streaming
//    SetBlockSerialNumber [serial number]               - Sets block serial number
//    GetBlockSerialNumber                               - Gets block serial number
//    SetBlockType [0|1|2]                               - Sets block type (Zone mapping, sensor mapping, etc.)
//    GetBlockType                                       - Gets block type
//    MoveRelative <MR> [motor] [steps]                  - Move a stepper motor a relative number of steps
//    SetMotorCalibration [DOOR_CLOSED|LID_LOWERED](pos) - Sets Motor Position Calibration (current position or specified)
//    GetMotorCalibration [DOOR_CLOSED|LID_LOWERED]      - Gets Motor Position Calibration
//    GetMotorSensors                                    - Returns all the motor sensor states
//    ToggleVariance [0|1]                               - Enable or disable temperature variance check
//    SetRampRate [Rate]                                 - Set temperature ramp rate
//    GetRampRate                                        - Get temperature ramp rate
//    SetLidRampRate [Rate]                              - Set lid temperature ramp rate
//    GetLidRampRate                                     - Get lid temperature ramp rate
//    SetDefaultRampRate (Rate)                          - Override and set new default ramp rate (Hard coded or specified)
//    GetDefaultRampRate                                 - Get default ramp rate
//    SelfTest                                           - Runs Self Test
//    SelfTestIgnoreErrors                               - Ignore Selftest Failures (volatile setting)
//    PerformanceTest                                    - Runs Performance Test
//    PerformanceBaseline                                - Sets Performance Test baseline
//    GetPerformanceTarget [BLOCK|LID] [H|C]             - Gets the specified target for the performance test.
//    GetPerformanceBaseline [ch] [H|C]                  - Gets the specified performance baseline for the channel.
//    Reboot                                             - Reboot FPGA Firmware
//    RestoreDefaults                                    - Restore parameters to default values.
//    SendErrorMessage [Err Num] [Msg...]                - Sends an error message
//    SendLogMessage [Msg...]                            - Sends a log message
//    SetBlockFan [%PWM]                                 - Set block fan PWM duty cycle
//    GetBlockFan                                        - Get block fan PWM duty cycle
//    SetBlockFanFrequency                               - Set block fan PWM frequency
//    GetBlockFanFrequency                               - Get block fan PWM frequency
//    SetBlockFanTachFrequency                           - Set block fan tach frequency
//    GetBlockFanTachFrequency                           - Get block fan tach frequency
//    GetBlockFanRPM                                     - Get block fan RPM
//    SetSystemControlBoardSerialNumber [serial number]  - Sets board serial number
//    GetSystemControlBoardSerialNumber                  - Gets board serial number
//    WriteNonVolCRCs                                    - Writes CRC values for all non-volatile memory (one-time action when upgrading from old firmware)
//    DisableCommWatchdog                                - Disables the COMM timeout
//    ToggleSmoothRamp [0|1]                             - Enable or disable smooth ramping
//    GetSmoothRampEnabled                               - Get the enable status of smooth ramping
//    SetRampParam [type] [value]                        - Set a ramp parameter
//    GetRampParam [type]                                - Get a ramp parameter
//    SetBlockCycleCount [value]                         - Set the block cycle count
//    GetBlockCycleCount                                 - Get the block cycle count
//
// -------------------------- Test & Dianostic Commands --------------------------
//
//    BypassChannel [Block Zone]                         - Disable drive and ignore sensor for specific block channel (Setting is volatile)
//    GetDoorControlValues                               - Internal Door Control Values: StartPos CurrentPos HomePinFound AltPinFound
//                                                                                       HomePinFoundPos AltPinFoundPos
//    GetLidControlValues                                - Internal Lid Control Values: StartPos CurrentPos HomePinFound AltPinCount
//                                                                                      AltSpaceCount HomePinMakePos AltPinMake1Pos
//                                                                                      AltPinBreak1Pos AltPinMake2Pos AltPinBreak2Pos
//    GetStepperParam [DOOR|LID|FILTER] [FAST|SLOW|RAMP_STEPS]         - Get stepper parameter
//    SetStepperParam [DOOR|LID|FILTER] [FAST|SLOW|RAMP_STEPS] [value] - Set stepper parameter





#include <comm.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <crc16.h>
#include <timer.h>
#include <serial.h>
#include <lcd.h>
#include <led.h>
#include <pwm.h>
#include <update.h>
#include <control.h>
#include <version.h>
#include <sensors.h>
#include <fixedPoint.h>
#include <illumination.h>
#include <power.h>
#include <motion.h>
#include <errors.h>
#include <steppers.h>
#include <initialization.h>
#include <selfTest.h>
#include <performance.h>
#include <system.h>
#include <reboot.h>
#include <startup.h>
#include <model.h>
#include <fan.h>
#include <flash.h>
#include <nvrammap.h>
#include <ramp.h>


///////////////////////////////////////////////////
// Options

#define DISPLAY_CMD_PKTS     0
#define DISPLAY_RX_TX        0


//Define out the static keyword to stop the link errors
//we are getting.
#define static


///////////////////////////////////////////////////
// Constants

enum CommDelimiters
{
    paramDelimiter = ' ',
};


#define MIN_RSP_PARAM_COUNT           4

#define VAR_PARAM_COUNT               (-1)

#define HOST_INTERFACE_PORT           SBC_SERIAL_PORT

#define COMM_PROCESS_HOST_PERIOD_ms   10
#define COMM_PROCESS_SLAVE_PERIOD_ms  10
#define COMM_CONNECTION_TIMEOUT_s     60

#define COMM_BYTE_TIME_us             87

#define COMM_CMD_BUF_SIZE             MAX_RX_DATA_SIZE
#define COMM_RSP_BUF_SIZE             MAX_TX_DATA_SIZE
#define MAX_PARAMS_COUNT              30

#define TX_TIMEOUT_us                 10000

#define TO_MASTER_FROM_HOST_KEY       "MH"
#define TO_HOST_FROM_MASTER_KEY       "HM"

#define ALL_CHANNEL_KEY               "ALL"

#define BLOCK_CHANNEL_KEY             "BLOCK"

#define HEATED_LID_CHANNEL_KEY        "LID"
#define HEATED_LIDCENTER_CHANNEL_KEY  "LIDCENTER"
#define HEATED_LIDRING_CHANNEL_KEY    "LIDRING"

#define AMBIENT_CHANNEL_KEY           "AMBIENT"
#define HEAT_SINK_CHANNEL_KEY         "HEATSINK"

#define LOG_MSG_KEY                   "Log"
#define ERROR_MSG_KEY                 "Error"

#define LID_MOTOR_KEY                 "LID"
#define DOOR_MOTOR_KEY                "DOOR"
#define FILTER_MOTOR_KEY              "FILTER"

#define FAST_STEPPER_KEY              "FAST"
#define SLOW_STEPPER_KEY              "SLOW"
#define RAMP_STEPS_STEPPER_KEY        "RAMP_STEPS"

#define NULL_TEMP_STR                 "NULL"

#define RSP_OK                        "OK"
#define RSP_ERROR                     "ER"
#define RSP_PENDING                   "PE"
#define RSP_INFORMATION_PKT           "IP"

#define PCR_KEY                       "pcr"
#define SDA_KEY                       "sda"
#define PCR_CLOSED_KEY                "pcr_closed"
#define PCR_OPEN_KEY                  "pcr_open"
#define SDA_CLOSED_KEY                "sda_closed"
#define SDA_OPEN_KEY                  "sda_open"


#define MIN_HEATBLOCK_TEMPERATURE_C    -10.0
#define MAX_HEATBLOCK_TEMPERATURE_C    100.0
#define MIN_HEATED_LID_TEMPERATURE_C   0.0
#define MAX_HEATED_LID_TEMPERATURE_C   115.0

#define COLUMN_COUNT 6
#define ROW_COUNT    4

const int COLUMN_ROW_TO_CHANNEL_TABLE[ROW_COUNT][COLUMN_COUNT] =
{
    // 1   2   3   4   5   6
    {  0,  1,  2,  3,  4,  5  }, //A
    {  6,  7,  8,  9,  10, 11 }, //B
    {  12, 13, 14, 15, 16, 17 }, //C
    {  18, 19, 20, 21, 22, 23 }, //D
};

typedef enum
{
    RAMP_INVALID_PARAM,
    RAMP_INT_PARAM,
    RAMP_FLOAT_PARAM
} RampParamType;

#define MIN_RAMP_FLOAT_PARAM 1e-5
#define MAX_RAMP_FLOAT_PARAM 1e-0
#define MIN_RAMP_INT_PARAM   0
#define MAX_RAMP_INT_PARAM   400


#define OFFLINE_COMMAND_SEQ_NUM_BUF_SIZE 100
#define OFFLINE_COMMAND_CMD_BUF_SIZE     100

enum OfflineCommands
{
    OfflineCommand_SetBlockTargetTemp = 0,
    OfflineCommand_SetLidTargetTemp,
    OfflineCommand_SetFilter,
    OfflineCommand_SetIllumination,
    OfflineCommand_InitIllumination,
    OfflineCommand_OpenDoor,
    OfflineCommand_CloseDoor,
    OfflineCommand_RaiseLid,
    OfflineCommand_LowerLid,
    OfflineCommand_CloseCavity,
    OfflineCommand_OpenCavity,
    OfflineCommand_InitializeSystem,
    OfflineCommand_InitializeFilter,
    OfflineCommand_InitializeLid,
    OfflineCommand_InitializeDoor,
    OfflineCommand_Upgrade,
    OfflineCommand_Calibrate,
    OfflineCommand_SelfTest,
    OfflineCommand_PerformanceTest,

    OfflineCommand_count,
};


#define SET_ILLUMINATION_OFFLINE_CMD_MASK (1 << OfflineCommand_SetIllumination)

#define SET_BLOCK_TEMP_OFFLINE_CMD_MASK   (1 << OfflineCommand_SetBlockTargetTemp)

#define SET_LID_TEMP_OFFLINE_CMD_MASK     (1 << OfflineCommand_SetLidTargetTemp)

#define SET_TEMPERATURE_OFFLINE_CMD_MASK  (SET_BLOCK_TEMP_OFFLINE_CMD_MASK | SET_LID_TEMP_OFFLINE_CMD_MASK)

#define MOTION_OFFLINE_CMD_MASK           ((1 << OfflineCommand_SetFilter)   | \
                                           (1 << OfflineCommand_OpenDoor)    | \
                                           (1 << OfflineCommand_CloseDoor)   | \
                                           (1 << OfflineCommand_RaiseLid)    | \
                                           (1 << OfflineCommand_LowerLid)    | \
                                           (1 << OfflineCommand_CloseCavity) | \
                                           (1 << OfflineCommand_OpenCavity)  | \
                                           (1 << OfflineCommand_RaiseLid))

const char* OfflineCommandNames[] =
{
    "SettingBlockTemp",
    "SettingLidTemp",
    "SettingFilter",
    "SettingIllumination",
    "InitializingIllumination",
    "OpeningDoor",
    "ClosingDoor",
    "RaisingLid",
    "LoweringLid",
    "ClosingCavity",
    "OpeningCavity",
    "InitializingSystem",
    "InitializingFilter",
    "InitializingLid",
    "InitializingDoor",
    "Upgrading",
    "Calibrating",
    "SelfTest",
    "PerformanceTest",
    "PerformanceBaseline",
};



///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    unsigned bufByteCount;
    char     buf[COMM_CMD_BUF_SIZE];
    char*    dstSrc;
    char*    seqNum;
    char*    cmd;
    unsigned paramCount;
    char*    params[MAX_PARAMS_COUNT];
    char*    crc;
} CmdPkt;



typedef struct
{
    unsigned bufByteCount;
    unsigned paramCount;
    char*    bufPtr;
    char     buf[COMM_RSP_BUF_SIZE];
    char*    seqNum;
    char*    cmd;
    char*    status;
    char*    payload;
} RspPkt;



typedef struct
{
    char* cmd;
    int   paramCount;
    void  (*cmdHandler)(CmdPkt* cmdPkt);
} CommCommand;



typedef struct
{
    bool active;
    char seqNum[OFFLINE_COMMAND_SEQ_NUM_BUF_SIZE];
    char cmd[OFFLINE_COMMAND_CMD_BUF_SIZE];
} PendingCommand;



typedef struct
{
    Timer          serialInterfaceTimer;
    Signal         serialInterfaceRxSignal;

    bool           monitoringConnection;
    Timer          connectionTimer;

    PendingCommand pendingCommands[OfflineCommand_count];

    bool           commWatchdogDisabled;
} CommData;



///////////////////////////////////////////////////
// Local function prototypes

// Callback functions
static void signalOfflineTaskCompleteCallback(int offlineTask, ErrorCodes error, const char* errorDesc);
static void sendSelfTestStatus(int reference, ErrorCodes errorCode, const char* msg);
static void sendPerformanceTestStatus(int reference, ErrorCodes errorCode, const char* msg);


static bool parseCmdPkt(CmdPkt* cmdPkt);
static void processCmdPkt(CmdPkt* cmdPkt);

// Not static to prevent "brlid" bug in EDK 10.1 linker.
/*static*/ void addParamDelimiter(RspPkt* rspPkt);
/*static*/ void initRspPkt(RspPkt* rspPkt, CmdPkt* cmdPkt, const char* status);
/*static*/ void addParamToRspPkt(RspPkt* rspPkt, const char *format, ...);
/*static*/ void addFloat1ParamToRspPkt(RspPkt* rspPkt, float value);
/*static*/ void addFloat3ParamToRspPkt(RspPkt* rspPkt, float value);
/*static*/ void addStringParamToRspPkt(RspPkt* rspPkt, const char* str);
/*static*/ void sendRspPkt(RspPkt* rspPkt);

/*static*/ bool checkPendingCmds(CmdPkt* cmdPkt, uint32 offlineCmdIndex, uint32 ignoreMask);
static void registerPendingCmd(uint32 offlineCmdIndex, CmdPkt* cmdPkt);
static void sendOfflineRspOk(uint32 offlineCmdIndex, const char* extraParams);
static void sendOfflineRspError(uint32 offlineCmdIndex, ErrorCodes errorCode, const char* errorDesc);
static void sendOfflineRspAborted(uint32 offlineCmdIndex);

static void initErrorRspPkt(RspPkt* rspPkt, CmdPkt* cmdPkt, ErrorCodes errorCode);
static void initIpPkt(RspPkt* rspPkt, const char* cmd);
static bool initOfflineRsp(RspPkt* rspPkt, uint32 offlineCmdIndex, bool clear);
static void initIpErrorPkt(RspPkt* rspPkt, int errorCode);
static void initIpLogPkt(RspPkt* rspPkt);


// Status functions
/*static*/ void sendRspOk(CmdPkt* cmdPkt);
static void registerAndSendRspPending(uint32 offlineCmdIndex, CmdPkt* cmdPkt);
static void sendRspPending(CmdPkt* cmdPkt);
/*static*/ void sendRspError(CmdPkt* cmdPkt, ErrorCodes errorCode, const char* errorDesc);

static void sendRspStatusOutOfRange(CmdPkt* cmdPkt, const char* min, const char* max, const char* value);
static void sendRspStatusIntOutOfRange(CmdPkt* cmdPkt, int min, int max, int value);
static void sendRspStatusFloatOutOfRange(CmdPkt* cmdPkt, float min, float max, float value);
static void sendRspStatusHexOutOfRange(CmdPkt* cmdPkt, uint32 min, uint32 max, uint32 value);
static void sendRspStatusInvalidParameter(CmdPkt* cmdPkt);
static void sendRspStatusInvalidParameterCount(CmdPkt* cmdPkt, unsigned minExpectedParamCount, unsigned maxExpectedParamCount);
static void sendRspStatusUnknownCommand(CmdPkt* cmdPkt);
static void sendRspStatusSystemBusy(CmdPkt* cmdPkt, const char* errorDesc);
static void sendRspStatusInvalidImage(CmdPkt* cmdPkt, const char* errorDesc);
static void sendRspStatusMissingFileData(CmdPkt* cmdPkt);
static void sendRspStatusInvalidFileData(CmdPkt* cmdPkt);


// String parsing functions
static bool getIntValue(const char* str, int* value, int base);
static bool getUnsignedValue(const char* str, uint32* value, int base);
static bool getFloatValue(const char* str, float* value);

static bool validateIntValue(CmdPkt* cmdPkt, const char* str, int* value);
static bool validateUnsignedValue(CmdPkt* cmdPkt, const char* str, uint32* value);
static bool validateHexValue(CmdPkt* cmdPkt, const char* str, uint32* value);
static bool validateFloatValue(CmdPkt* cmdPkt, const char* str, float* value);

static bool validateIntParameterRange(CmdPkt* cmdPkt, int paramIndex, int minValue, int maxValue, int* value);
static bool validateFloatParameterRange(CmdPkt* cmdPkt, int paramIndex, float minValue, float maxValue, float* value);
static bool validateHexParameterRange(CmdPkt* cmdPkt, int paramIndex, uint32 minValue, uint32 maxValue, uint32* value);
static bool validateChannelParameter(CmdPkt* cmdPkt, int paramIndex, int* channel,
                                     bool allowAll, bool allowAllBlock, bool allowAllLid, bool allowSensors);
static bool validateMotorParameter(CmdPkt* cmdPkt, int paramIndex, stepper_t *motor);
static bool validateStepperParameter(CmdPkt* cmdPkt, int paramIndex, stepper_parameter_t *stepperParam);
static bool validateIlluminationChannel(CmdPkt* cmdPkt, int paramIndex, IlluminationColor *color);
static bool validateGainTypeParameter(CmdPkt* cmdPkt, int paramIndex, gainType *type);

static RampParamType validateRampParameter(CmdPkt* cmdPkt, int paramIndex, RampParam * param);



// Handler helpers
static void getChannelFloatData(CmdPkt* cmdPkt, float (*floatDataFunc)(int), bool allowAll);
static void addFilterPositionParameter(RspPkt* rspPkt);
static void addDoorPositionParameter(RspPkt* rspPkt);
static void addLidPositionParameter(RspPkt* rspPkt);
static void setIlluminationWithLowPowerFlag(CmdPkt* cmdPkt, bool lowPower);
static void systemAbort();

static ErrorCodes channelToCalibrationError(int channel);

// Command Handlers
static void chGetStatus(CmdPkt* cmdPkt);
static void chGetActiveState(CmdPkt* cmdPkt);

static void chSetPwm(CmdPkt* cmdPkt);
static void chGetPwm(CmdPkt* cmdPkt);

static void chEnableChannel(CmdPkt* cmdPkt);
static void chDisableChannel(CmdPkt* cmdPkt);

static void chSetTargetTemp(CmdPkt* cmdPkt);
static void chGetTargetTemp(CmdPkt* cmdPkt);

static void chReadCurrentTemp(CmdPkt* cmdPkt);

static void chSetFrequency(CmdPkt* cmdPkt);
static void chGetFrequency(CmdPkt* cmdPkt);

static void chAbort(CmdPkt* cmdPkt);
static void chGoToIdle(CmdPkt* cmdPkt);
static void chReset(CmdPkt* cmdPkt);

static void chGetIllumination(CmdPkt* cmdPkt);
static void chSetIllumination(CmdPkt* cmdPkt);
static void chSetIlluminationLowPower(CmdPkt* cmdPkt);
static void chGetIlluminationCurrent(CmdPkt* cmdPkt);
static void chGetIlluminationFeedback(CmdPkt* cmdPkt);
static void chSetIlluminationCalibration(CmdPkt* cmdPkt);
static void chCalibrateIllumination(CmdPkt* cmdPkt);
static void chGetIlluminationCalibration(CmdPkt* cmdPkt);
static void chSetIlluminationPower(CmdPkt* cmdPkt);
static void chGetIlluminationPower(CmdPkt* cmdPkt);
static void chSetIlluminationIntensity(CmdPkt* cmdPkt);
static void chGetIlluminationIntensity(CmdPkt* cmdPkt);
static void chToggleIlluminationControl(CmdPkt* cmdPkt);
static void chSetIlluminationGain(CmdPkt* cmdPkt);
static void chGetIlluminationGain(CmdPkt* cmdPkt);
static void chSetIlluminationLowPowerCalibration(CmdPkt* cmdPkt);
static void chGetIlluminationLowPowerCalibration(CmdPkt* cmdPkt);

static void chGetMotorPositions(CmdPkt* cmdPkt);

static void chGetFilter(CmdPkt* cmdPkt);
static void chSetFilter(CmdPkt* cmdPkt);

static void chGetDoorPosition(CmdPkt* cmdPkt);
static void chOpenDoor(CmdPkt* cmdPkt);
static void chCloseDoor(CmdPkt* cmdPkt);
static void chDisableDoor(CmdPkt* cmdPkt);

static void chGetLidPosition(CmdPkt* cmdPkt);
static void chRaiseLid(CmdPkt* cmdPkt);
static void chLowerLid(CmdPkt* cmdPkt);

static void chOpenCavity(CmdPkt* cmdPkt);
static void chCloseCavity(CmdPkt* cmdPkt);

static void chInitSystem(CmdPkt* cmdPkt);
static void chInitFilter(CmdPkt* cmdPkt);
static void chInitLid(CmdPkt* cmdPkt);
static void chInitDoor(CmdPkt* cmdPkt);

static void chFileSend(CmdPkt* cmdPkt);
static void chUpgradeFirmware(CmdPkt* cmdPkt);
static void chUpgradeFPGA(CmdPkt* cmdPkt);

static void chCalibrate(CmdPkt* cmdPkt);
static void chSetCalPoint(CmdPkt* cmdPkt);
static void chSetCalibration(CmdPkt* cmdPkt);
static void chGetCalibration(CmdPkt* cmdPkt);
static void chAdjustCalibration(CmdPkt* cmdPkt);

static void chSetGain(CmdPkt* cmdPkt);
static void chGetGain(CmdPkt* cmdPkt);

static void chFirmwareVersion(CmdPkt* cmdPkt);
static void chFPGAVersion(CmdPkt* cmdPkt);

static void chGetRaw(CmdPkt* cmdPkt);

static void chMonitorChannel(CmdPkt* cmdPkt);
static void chMonitorRaw(CmdPkt* cmdPkt);
static void chMonitorPid(CmdPkt* cmdPkt);

static void chResetSensors(CmdPkt* cmdPkt);

static void chReadMem(CmdPkt* cmdPkt);
static void chGetMemSections(CmdPkt* cmdPkt);
static void chTest(CmdPkt* cmdPkt);

static void chToggleModel(CmdPkt* cmdPkt);
static void chSetModel(CmdPkt* cmdPkt);
static void chGetModel(CmdPkt* cmdPkt);
static void chSetModelParam(CmdPkt* cmdPkt);
static void chGetModelParams(CmdPkt* cmdPkt);
static void chClearModelParams(CmdPkt* cmdPkt);
static void chSetSampleVolume(CmdPkt* cmdPkt);
static void chGetSampleVolume(CmdPkt* cmdPkt);
static void chGetPlateType(CmdPkt* cmdPkt);

static void chWriteFullScale(CmdPkt* cmdPkt);
static void chWriteZeroScale(CmdPkt* cmdPkt);
static void chToggleStreaming(CmdPkt* cmdPkt);
static void chToggleLedStreaming(CmdPkt* cmdPkt);

static void chSetBlockSerialNumber(CmdPkt* cmdPkt);
static void chGetBlockSerialNumber(CmdPkt* cmdPkt);
static void chSetBlockType(CmdPkt* cmdPkt);
static void chGetBlockType(CmdPkt* cmdPkt);

static void chMoveRelative(CmdPkt* cmdPkt);
static void chSetMotorCalibration(CmdPkt* cmdPkt);
static void chGetMotorCalibration(CmdPkt* cmdPkt);
static void chGetMotorSensors(CmdPkt* cmdPkt);

static void chToggleVarianceCheck(CmdPkt* cmdPkt);

static void chSetRampRate(CmdPkt* cmdPkt);
static void chGetRampRate(CmdPkt* cmdPkt);
static void chSetDefaultRampRate(CmdPkt* cmdPkt);
static void chGetDefaultRampRate(CmdPkt* cmdPkt);

static void chSetLidRampRate(CmdPkt* cmdPkt);
static void chGetLidRampRate(CmdPkt* cmdPkt);

static void chSelfTest(CmdPkt* cmdPkt);
static void chSelfTestIgnoreErrors(CmdPkt* cmdPkt);

static void chPerformanceTest(CmdPkt* cmdPkt);
static void chGetPerformanceTarget(CmdPkt* cmdPkt);
static void chGetPerformanceBaseline(CmdPkt* cmdPkt);

static void chReboot(CmdPkt* cmdPkt);
static void chRestoreDefaults(CmdPkt* cmdPkt);

static void chSetBlockFan(CmdPkt* cmdPkt);
static void chGetBlockFan(CmdPkt* cmdPkt);
static void chSetBlockFanFrequency(CmdPkt* cmdPkt);
static void chGetBlockFanFrequency(CmdPkt* cmdPkt);
static void chSetBlockFanTachFrequency(CmdPkt* cmdPkt);
static void chGetBlockFanTachFrequency(CmdPkt* cmdPkt);
static void chGetBlockFanRPM(CmdPkt* cmdPkt);

static void chSendErrorMessage(CmdPkt* cmdPkt);
static void chSendLogMessage(CmdPkt* cmdPkt);

static void chSetSystemControlBoardSerialNumber(CmdPkt* cmdPkt);
static void chGetSystemControlBoardSerialNumber(CmdPkt* cmdPkt);

static void chWriteNonVolCRCs(CmdPkt* cmdPkt);
static void chCustomRamp(CmdPkt* cmdPkt);
static void chSetCustomRampData(CmdPkt* cmdPkt);
static void chGetCustomRampData(CmdPkt* cmdPkt);

static void chDisableCommWatchdog(CmdPkt* cmdPkt);

static void chToggleSmoothRamp(CmdPkt* cmdPkt);
static void chGetSmoothRampEnabled(CmdPkt* cmdPkt);

static void chSetRampParam(CmdPkt* cmdPkt);
static void chGetRampParam(CmdPkt* cmdPkt);

static void chSetBlockCycleCount(CmdPkt* cmdPkt);
static void chGetBlockCycleCount(CmdPkt* cmdPkt);



// -------------------------- Test & Dianostic Commands --------------------------

static void chBypassChannel(CmdPkt* cmdPkt);
static void chGetDoorControlValues(CmdPkt* cmdPkt);
static void chGetLidControlValues(CmdPkt* cmdPkt);
static void chGetStepperParameter(CmdPkt* cmdPkt);
static void chSetStepperParameter(CmdPkt* cmdPkt);



///////////////////////////////////////////////////
// Local data

static const CommCommand commCommands[] =
{   // Cmd,                                 Param Count,     Cmd Handler,
    { "GetStatus",                          0,               chGetStatus,                          },
    { "GetActiveState",                     0,               chGetActiveState,                     },

    { "SetPWM",                             3,               chSetPwm,                             },
    { "SP",                                 3,               chSetPwm,                             },

    { "GetPWM",                             1,               chGetPwm,                             },

    { "EnableChannel",                      1,               chEnableChannel,                      },
    { "EC",                                 1,               chEnableChannel,                      },

    { "DisableChannel",                     1,               chDisableChannel,                     },
    { "DC",                                 1,               chDisableChannel,                     },

    { "SetTargetTemp",                      2,               chSetTargetTemp,                      },
    { "ST",                                 2,               chSetTargetTemp,                      },

    { "GetTargetTemp",                      1,               chGetTargetTemp,                      },
    { "GT",                                 1,               chGetTargetTemp,                      },

    { "ReadCurrentTemp",                    1,               chReadCurrentTemp,                    },
    { "RT",                                 1,               chReadCurrentTemp,                    },

    { "SetPwmFrequency",                    1,               chSetFrequency,                       },
    { "GetPwmFrequency",                    0,               chGetFrequency,                       },

    { "Abort",                              0,               chAbort,                              },
    { "AB",                                 0,               chAbort,                              },

    { "GoToIdle",                           0,               chGoToIdle,                           },

    { "Reset",                              0,               chReset,                              },

    { "GetFirmwareVersion",                 0,               chFirmwareVersion,                    },
    { "RV",                                 0,               chFirmwareVersion,                    },
    { "GetFPGAVersion",                     0,               chFPGAVersion,                        },

    { "GetIllumination",                    0,               chGetIllumination,                    },
    { "SetIllumination",                    VAR_PARAM_COUNT, chSetIllumination,                    },
    { "SetIlluminationLowPower",            VAR_PARAM_COUNT, chSetIlluminationLowPower,            },
    { "GetIlluminationCurrent",             1,               chGetIlluminationCurrent,             },
    { "GetIlluminationFeedback",            1,               chGetIlluminationFeedback,            },
    { "SetIlluminationCalibration",         2,               chSetIlluminationCalibration,         },
    { "CalibrateIllumination",              0,               chCalibrateIllumination,              },
    { "GetIlluminationCalibration",         1,               chGetIlluminationCalibration,         },
    { "SetIlluminationPower",               2,               chSetIlluminationPower,               },
    { "GetIlluminationPower",               1,               chGetIlluminationPower,               },
    { "SetIlluminationIntensity",           2,               chSetIlluminationIntensity,           },
    { "GetIlluminationIntensity",           1,               chGetIlluminationIntensity,           },
    { "ToggleIlluminationControl",          1,               chToggleIlluminationControl,          },
    { "SetIlluminationGain",                3,               chSetIlluminationGain,                },
    { "GetIlluminationGain",                2,               chGetIlluminationGain,                },
    { "SetIlluminationLowPowerCalibration", 2,               chSetIlluminationLowPowerCalibration, },
    { "GetIlluminationLowPowerCalibration", 1,               chGetIlluminationLowPowerCalibration, },

    { "GetMotorPositions",                  0,               chGetMotorPositions,                  },

    { "GetFilterPosition",                  0,               chGetFilter,                          },
    { "SetFilter",                          1,               chSetFilter,                          },

    { "GetDoorPosition",                    0,               chGetDoorPosition,                    },
    { "OpenDoor",                           0,               chOpenDoor,                           },
    { "CloseDoor",                          0,               chCloseDoor,                          },
    { "DisableDoor",                        0,               chDisableDoor,                        },

    { "GetLidPosition",                     0,               chGetLidPosition,                     },
    { "RaiseLid",                           0,               chRaiseLid,                           },
    { "LowerLid",                           0,               chLowerLid,                           },

    { "OpenCavity",                         0,               chOpenCavity,                         },
    { "CloseCavity",                        0,               chCloseCavity,                        },

    { "InitSystem",                         0,               chInitSystem,                         },
    { "InitFilter",                         0,               chInitFilter,                         },
    { "InitLid",                            0,               chInitLid,                            },
    { "InitDoor",                           0,               chInitDoor,                           },

    { "FileSend",                           2,               chFileSend,                           },
    { "Upgrade",                            2,               chUpgradeFirmware,                    },
    { "UpgradeFPGA",                        2,               chUpgradeFPGA,                        },

    { "Calibrate",                          4,               chCalibrate,                          },
    { "SetCalPoint",                        4,               chSetCalPoint,                        },
    { "SetCal",                             4,               chSetCalibration,                     },
    { "GetCal",                             2,               chGetCalibration,                     },
    { "AdjustCal",                          5,               chAdjustCalibration,                  },

    { "SetGain",                            3,               chSetGain,                            },
    { "GetGain",                            2,               chGetGain,                            },

    { "ReadRaw",                            1,               chGetRaw,                             },

    { "Monitor",                            1,               chMonitorChannel,                     },
    { "MonitorRaw",                         1,               chMonitorRaw,                         },
    { "MonitorPid",                         1,               chMonitorPid,                         },

    { "ResetSensors",                       0,               chResetSensors,                       },

    { "ReadMem",                            2,               chReadMem,                            },
    { "GetMemSections",                     0,               chGetMemSections,                     },
    { "test",                               VAR_PARAM_COUNT, chTest,                               },

    { "ToggleModel",                        1,               chToggleModel,                        },
    { "SetModel",                           VAR_PARAM_COUNT, chSetModel,                           },
    { "GetModel",                           0,               chGetModel ,                          },
    { "SetModelParam",                      VAR_PARAM_COUNT, chSetModelParam,                      },
    { "GetModelParams",                     2,               chGetModelParams,                     },
    { "ClearModelParams",                   0,               chClearModelParams,                   },
    { "SetSampleVolume",                    1,               chSetSampleVolume,                    },
    { "GetSampleVolume",                    0,               chGetSampleVolume,                    },
    { "GetPlateType",                       0,               chGetPlateType,                       },
    { "WriteFull",                          1,               chWriteFullScale,                     },
    { "WriteZero",                          1,               chWriteZeroScale,                     },
    { "ToggleStreaming",                    1,               chToggleStreaming,                    },
    { "ToggleLedStreaming",                 1,               chToggleLedStreaming,                 },

    { "SetBlockSerialNumber",               1,               chSetBlockSerialNumber,               },
    { "GetBlockSerialNumber",               0,               chGetBlockSerialNumber,               },
    { "SetBlockType",                       1,               chSetBlockType,                       },
    { "GetBlockType",                       0,               chGetBlockType,                       },

    { "MoveRelative",                       2,               chMoveRelative,                       },
    { "MR",                                 2,               chMoveRelative,                       },
    { "SetMotorCalibration",                VAR_PARAM_COUNT, chSetMotorCalibration,                },
    { "GetMotorCalibration",                1,               chGetMotorCalibration,                },
    { "GetMotorSensors",                    0,               chGetMotorSensors,                    },

    { "ToggleVariance",                     1,               chToggleVarianceCheck,                },

    { "SetRampRate",                        1,               chSetRampRate,                        },
    { "GetRampRate",                        0,               chGetRampRate,                        },
    { "SetDefaultRampRate",                 VAR_PARAM_COUNT, chSetDefaultRampRate                  },
    { "GetDefaultRampRate",                 0,               chGetDefaultRampRate                  },

    { "SetLidRampRate",                     1,               chSetLidRampRate,                     },
    { "GetLidRampRate",                     0,               chGetLidRampRate,                     },

    { "SelfTest",                           0,               chSelfTest,                           },
    { "SelfTestIgnoreErrors",               0,               chSelfTestIgnoreErrors,               },

    { "PerformanceTest",                    0,               chPerformanceTest,                    },
    { "PerformanceBaseline",                0,               chPerformanceTest,                    },
    { "GetPerformanceTarget",               2,               chGetPerformanceTarget,               },
    { "GetPerformanceBaseline",             2,               chGetPerformanceBaseline,             },

    { "Reboot",                             0,               chReboot,                             },
    { "RestoreDefaults",                    0,               chRestoreDefaults,                    },

    { "SetBlockFan",                        1,               chSetBlockFan,                        },
    { "GetBlockFan",                        0,               chGetBlockFan,                        },
    { "SetBlockFanFrequency",               1,               chSetBlockFanFrequency,               },
    { "GetBlockFanFrequency",               0,               chGetBlockFanFrequency,               },
    { "SetBlockFanTachFrequency",           1,               chSetBlockFanTachFrequency,           },
    { "GetBlockFanTachFrequency",           0,               chGetBlockFanTachFrequency,           },
    { "GetBlockFanRPM",                     0,               chGetBlockFanRPM,                     },

    { "SendErrorMessage",                   VAR_PARAM_COUNT, chSendErrorMessage,                   },
    { "SendLogMessage",                     VAR_PARAM_COUNT, chSendLogMessage,                     },

    { "SetSystemControlBoardSerialNumber",  1,               chSetSystemControlBoardSerialNumber,  },
    { "GetSystemControlBoardSerialNumber",  0,               chGetSystemControlBoardSerialNumber,  },

    { "WriteNonVolCRCs",                    0,               chWriteNonVolCRCs,                    },

    { "CustomRamp",                         2,               chCustomRamp,                         },
    { "SetCustomRampData",                  3,               chSetCustomRampData,                  },
    { "GetCustomRampData",                  2,               chGetCustomRampData,                  },
    { "DisableCommWatchdog",                0,               chDisableCommWatchdog,                },
    { "ToggleSmoothRamp",                   1,               chToggleSmoothRamp,                   },
    { "GetSmoothRampEnabled",               0,               chGetSmoothRampEnabled,               },

    { "SetRampParam",                       2,               chSetRampParam,                       },
    { "GetRampParam",                       1,               chGetRampParam,                       },

    { "SetBlockCycleCount",                 1,               chSetBlockCycleCount,                 },
    { "GetBlockCycleCount",                 0,               chGetBlockCycleCount,                 },


    // -------------------------- Test & Dianostic Commands --------------------------
    { "BypassChannel",                      2,               chBypassChannel,                      },

    { "GetDoorControlValues",               0,               chGetDoorControlValues,               },
    { "GetLidControlValues",                0,               chGetLidControlValues,                },

    { "GetStepperParam",                    2,               chGetStepperParameter,                },
    { "SetStepperParam",                    3,               chSetStepperParameter,                },

    // End of table marker
    { NULL, 0, NULL }
};



static CommData commData;



///////////////////////////////////////////////////
// Interface functions

void commInit()
{
    memset(&commData, 0, sizeof(commData));

    commData.monitoringConnection = false;
    commData.commWatchdogDisabled = false;

    initSignal(&commData.serialInterfaceRxSignal, 0, 1);
    setSerialPortRxSignal(HOST_INTERFACE_PORT, &commData.serialInterfaceRxSignal);
    startTimer(&commData.serialInterfaceTimer, MSEC_TO_TICKS(COMM_PROCESS_HOST_PERIOD_ms));
    startTimer(&commData.connectionTimer, SEC_TO_TICKS(COMM_CONNECTION_TIMEOUT_s));
}



bool commProcess(void* unused)
{
    CmdPkt cmdPkt;

    if(getSignal(&commData.serialInterfaceRxSignal) || timerExpired(&commData.serialInterfaceTimer))
    {
        if(!commData.commWatchdogDisabled && commData.monitoringConnection && timerExpired(&commData.connectionTimer))
        {
            systemAbort();
            sendErrorMsg(err_connectionTimeout, "FPGA did not receive communication from host for more than "
                                                STRINGIFY(COMM_CONNECTION_TIMEOUT_s)
                                                " seconds - All operations aborted");
        }

        cmdPkt.bufByteCount = serialGetPkt(HOST_INTERFACE_PORT, (uint8*)cmdPkt.buf, COMM_CMD_BUF_SIZE - 1);

        if(cmdPkt.bufByteCount)
        {
            cmdPkt.buf[cmdPkt.bufByteCount] = 0;

            #if DISPLAY_RX_TX
                printf("RX: %s\n", cmdPkt.buf);
            #endif

            if(parseCmdPkt(&cmdPkt))
            {
                commData.monitoringConnection = true;
                startTimer(&commData.connectionTimer, SEC_TO_TICKS(COMM_CONNECTION_TIMEOUT_s));
                setCommActivityLed();
                processCmdPkt(&cmdPkt);
            }
        }

        startTimer(&commData.serialInterfaceTimer, MSEC_TO_TICKS(COMM_PROCESS_HOST_PERIOD_ms));
    }

    return true;
}



void sendErrorMsg(ErrorCodes errorCode, const char* errorDesc)
{
    ASSERT(errorCode < num_errors);

    RspPkt rspPkt;

    initIpErrorPkt(&rspPkt, errorCode);

    if(errorDesc)
    {
        addStringParamToRspPkt(&rspPkt, "-");
        addStringParamToRspPkt(&rspPkt, errorDesc);
    }

    sendRspPkt(&rspPkt);
}



void sendLogMsg(const char* logMsg)
{
    ASSERT(logMsg);

    RspPkt rspPkt;

    initIpLogPkt(&rspPkt);
    addStringParamToRspPkt(&rspPkt, logMsg);
    printf("Log: %s\n", logMsg);

    sendRspPkt(&rspPkt);
}



///////////////////////////////////////////////////
// Local functions

static void signalOfflineTaskCompleteCallback(int offlineTask, ErrorCodes error, const char* errorDesc)
{
    ASSERT(offlineTask >= 0 && offlineTask < OfflineCommand_count);
    ASSERT(error >= 0 && error < num_errors);

    if(error == err_noError)
    {
        sendOfflineRspOk(offlineTask, errorDesc);
    }
    else
    {
        sendOfflineRspError(offlineTask, error, errorDesc);
    }
}



void sendSelfTestStatus(int reference, ErrorCodes errorCode, const char* msg)
{
    TestDevices device = (TestDevices)reference;

    printf("Self Test Status:\n");
    printf("  Device: %s (%d)\n", getTestDeviceName(device), device);
    printf("  Error:  %s (%d)\n", error_strings[errorCode], errorCode);
    printf("  Msg:    %s\n", msg ? msg : "(no msg)");

    ASSERT(errorCode < num_errors);

    RspPkt rspPkt;

    if(initOfflineRsp(&rspPkt, OfflineCommand_SelfTest, false))
    {
        addStringParamToRspPkt(&rspPkt, RSP_INFORMATION_PKT);
        addStringParamToRspPkt(&rspPkt, getTestDeviceName(device));
        addParamToRspPkt(&rspPkt, "%03d", errorCode);

        if(errorCode != err_noError)
        {
            addStringParamToRspPkt(&rspPkt, error_strings[errorCode]);

            if(msg && strlen(msg) > 0)
            {
                addStringParamToRspPkt(&rspPkt, "-");
                addStringParamToRspPkt(&rspPkt, msg);
            }
        }

        sendRspPkt(&rspPkt);
    }
}


void sendPerformanceTestStatus(int reference, ErrorCodes errorCode, const char* msg)
{
    TestDevices device = (TestDevices)reference;

    printf("Performance Test Status:\n");
    printf("  Device: %s (%d)\n", getTestDeviceName(device), device);
    printf("  Error:  %s (%d)\n", error_strings[errorCode], errorCode);
    printf("  Msg:    %s\n", msg ? msg : "(no msg)");

    ASSERT(errorCode < num_errors);

    RspPkt rspPkt;

    if(initOfflineRsp(&rspPkt, OfflineCommand_PerformanceTest, false))
    {
        addStringParamToRspPkt(&rspPkt, RSP_INFORMATION_PKT);
        addStringParamToRspPkt(&rspPkt, getTestDeviceName(device));
        addParamToRspPkt(&rspPkt, "%03d", errorCode);

        if(errorCode != err_noError)
        {
            addStringParamToRspPkt(&rspPkt, error_strings[errorCode]);
            addStringParamToRspPkt(&rspPkt, "-");
        }

        if(msg && strlen(msg) > 0)
        {
            addStringParamToRspPkt(&rspPkt, msg);
        }

        sendRspPkt(&rspPkt);
    }
}


static bool parseCmdPkt(CmdPkt* cmdPkt)
{
    ASSERT(cmdPkt);
    ASSERT(cmdPkt->bufByteCount < sizeof(cmdPkt->buf) - 1);

    cmdPkt->dstSrc     = NULL;
    cmdPkt->seqNum     = NULL;
    cmdPkt->cmd        = NULL;
    cmdPkt->crc        = NULL;
    cmdPkt->paramCount = 0;

    if(cmdPkt->buf[0] == paramDelimiter || !isprint(cmdPkt->buf[0]))
    {
        // First character is bad
        return false;
    }



    // Find and verify CRC
    char* crcParam = strrchr(cmdPkt->buf, paramDelimiter);

    if(!crcParam)
    {
        // No CRC parameter found
        return false;
    }

    *crcParam++ = 0;
    cmdPkt->crc = crcParam;

    uint32 calcCrc = calcCRC16(INITIAL_CRC16_VALUE, cmdPkt->buf, strlen(cmdPkt->buf));
    uint32 pktCrc;

    if(!getUnsignedValue(cmdPkt->crc, &pktCrc, 10) ||
       (pktCrc != 0 && calcCrc != pktCrc))
    {
        // CRC parameter not correct
        printf("Invalid Cmd Pkt CRC (%lu): '%s %s' \n", calcCrc, cmdPkt->buf, cmdPkt->crc);
        return false;
    }




    unsigned i;
    bool     startOfParam = true;
    char*    bufPtr;

    for(i = 0, bufPtr = cmdPkt->buf;
        *bufPtr && i < cmdPkt->bufByteCount;
        i++, bufPtr++)
    {
        if(!isprint(*bufPtr))
        {
            // Invalid character
            return false;
        }

        if(*bufPtr == paramDelimiter)
        {
            //Null terminate parameter
            *bufPtr = 0;

            startOfParam = true;
        }
        else
        {
            if(startOfParam)
            {
                startOfParam = false;

                if(!cmdPkt->dstSrc)
                {
                    cmdPkt->dstSrc = bufPtr;
                }
                else if(!cmdPkt->seqNum)
                {
                    cmdPkt->seqNum = bufPtr;
                }
                else if(!cmdPkt->cmd)
                {
                    cmdPkt->cmd = bufPtr;
                }
                else
                {
                    if(cmdPkt->paramCount >= MAX_PARAMS_COUNT)
                    {
                        // Too many parameters
                        return false;
                    }

                    cmdPkt->params[cmdPkt->paramCount++] = bufPtr;
                }
            }
        }
    }

    //Null terminate last parameter
    *bufPtr = 0;

    if(!cmdPkt->dstSrc || strcmp(cmdPkt->dstSrc, TO_MASTER_FROM_HOST_KEY) != 0 ||
       !cmdPkt->seqNum || !cmdPkt->cmd)
    {
        printf("Cmd Pkt header invalid\n");
        return false;
    }

    #if DISPLAY_CMD_PKTS
        printf("Cmd Pkt:\n");
        printf("  Dst/Src   = %s\n", cmdPkt->dstSrc);
        printf("  Seq Num   = %s\n", cmdPkt->seqNum);
        printf("  Cmd       = %s\n", cmdPkt->cmd);
        printf("  Param Cnt = %d\n", cmdPkt->paramCount);
        printf("  Params:\n");
        for(i = 0; i < cmdPkt->paramCount; i++)
        {
            printf("    Param %d = %s\n", i, cmdPkt->params[i]);
        }
        printf("  CRC       = %s\n", cmdPkt->crc);
    #endif

    return true;
}



static void processCmdPkt(CmdPkt* cmdPkt)
{
    const CommCommand* commCommandIterator = commCommands;

    while(commCommandIterator->cmd)
    {
        if(strcmp(cmdPkt->cmd, commCommandIterator->cmd) == 0)
        {
            if((int)cmdPkt->paramCount == commCommandIterator->paramCount ||
               commCommandIterator->paramCount == VAR_PARAM_COUNT)
            {
                commCommandIterator->cmdHandler(cmdPkt);
            }
            else
            {
                sendRspStatusInvalidParameterCount(cmdPkt, commCommandIterator->paramCount, commCommandIterator->paramCount);
            }

            return;
        }

        commCommandIterator++;
    }

    sendRspStatusUnknownCommand(cmdPkt);
}



void addParamDelimiter(RspPkt* rspPkt)
{
    if(rspPkt->paramCount > 0 && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        *rspPkt->bufPtr++ = paramDelimiter;
        rspPkt->bufByteCount++;
    }
}


void addParamToRspPkt(RspPkt* rspPkt, const char *format, ...)
{
    addParamDelimiter(rspPkt);

    int     count;
    va_list argp;

    va_start (argp, format);

    count = vsnprintf(rspPkt->bufPtr, COMM_RSP_BUF_SIZE - rspPkt->bufByteCount, format, argp);
    va_end (argp);

    rspPkt->bufPtr    += count;
    rspPkt->bufByteCount += count;

    ASSERT(rspPkt->bufByteCount <= COMM_RSP_BUF_SIZE);

    rspPkt->paramCount++;
}



void addFloat1ParamToRspPkt(RspPkt* rspPkt, float value)
{
    addParamDelimiter(rspPkt);

    if(value > 100000.0 || value < -100000.0)
    {
        // Value too bit to format with this function.  Use snprintf() instead.
        int count = snprintf(rspPkt->bufPtr, COMM_RSP_BUF_SIZE - rspPkt->bufByteCount,
                             "%0.1e", value);

        if(count >= COMM_RSP_BUF_SIZE - (int)rspPkt->bufByteCount)
        {
            // Write truncated
            count = COMM_RSP_BUF_SIZE - rspPkt->bufByteCount - 1;
        }

        rspPkt->bufByteCount += count;
        rspPkt->bufPtr       += count;

        return;
    }

    if(value < 5.0E-2 && value > -5.0E-2)
    {
        // Zero out number that is too small to format
        value = 0.0;
    }

    int intValue;

    // Handle negative numbers
    if(value < 0.0 && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        *rspPkt->bufPtr++ = '-';
        rspPkt->bufByteCount++;
        intValue = (int)(value * (-10.0) + 0.5);
    }
    else
    {
        intValue = (int)(value * 10.0 + 0.5);
    }

    int places = 2;
    int scale  = 100;

    while(intValue >= scale && scale)
    {
        ++places;
        scale *= 10;
    }

    while(places && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        --places;

        int digit = intValue % scale;

        scale /= 10;
        digit /= scale;

        *rspPkt->bufPtr++ = '0' + digit;
        rspPkt->bufByteCount++;

        if(places == 1 && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
        {
            *rspPkt->bufPtr++ = '.';
            rspPkt->bufByteCount++;
        }
    }

    *rspPkt->bufPtr = '\0';

    rspPkt->paramCount++;
}



void addFloat3ParamToRspPkt(RspPkt* rspPkt, float value)
{
    addParamDelimiter(rspPkt);

    if(value > 100000.0 || value < -100000.0)
    {
        // Value too bit to format with this function.  Use snprintf() instead.
        int count = snprintf(rspPkt->bufPtr, COMM_RSP_BUF_SIZE - rspPkt->bufByteCount,
                             "%0.3e", value);

        if(count >= COMM_RSP_BUF_SIZE - (int)rspPkt->bufByteCount)
        {
            // Write truncated
            count = COMM_RSP_BUF_SIZE - rspPkt->bufByteCount - 1;
        }

        rspPkt->bufByteCount += count;
        rspPkt->bufPtr       += count;

        return;
    }

    if(value < 5.0E-4 && value > -5.0E-4)
    {
        // Zero out number that is too small to format
        value = 0.0;
    }

    int intValue;

    // Handle negative numbers
    if(value < 0.0 && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        *rspPkt->bufPtr++ = '-';
        rspPkt->bufByteCount++;
        intValue = (int)(value * (-1000.0) + 0.5);
    }
    else
    {
        intValue = (int)(value * 1000.0 + 0.5);
    }

    int places = 4;
    int scale  = 10000;

    while(intValue >= scale && scale)
    {
        ++places;
        scale *= 10;
    }

    while(places && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        --places;

        int digit = intValue % scale;

        scale /= 10;
        digit /= scale;

        *rspPkt->bufPtr++ = '0' + digit;
        rspPkt->bufByteCount++;

        if(places == 3 && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
        {
            *rspPkt->bufPtr++ = '.';
            rspPkt->bufByteCount++;
        }
    }

    *rspPkt->bufPtr = '\0';

    rspPkt->paramCount++;
}



void addStringParamToRspPkt(RspPkt* rspPkt, const char* str)
{
    addParamDelimiter(rspPkt);

    while(*str && rspPkt->bufByteCount < COMM_RSP_BUF_SIZE - 1)
    {
        *rspPkt->bufPtr++ = *str++;
        rspPkt->bufByteCount++;
    }

    *rspPkt->bufPtr = '\0';

    rspPkt->paramCount++;
}



void sendRspPkt(RspPkt* rspPkt)
{
    uint16 crc = calcCRC16(INITIAL_CRC16_VALUE, rspPkt->buf, rspPkt->bufByteCount);

    addParamToRspPkt(rspPkt, "%u", crc);

    #if DISPLAY_RX_TX
        printf("TX: %s\n", rspPkt->buf);
    #endif

    if(!strncmp(rspPkt->status, RSP_ERROR, 2))
    {
        printf("Error: %s\n", rspPkt->cmd);
    }

    if(!serialSendPkt(HOST_INTERFACE_PORT, (uint8*)rspPkt->buf, rspPkt->bufByteCount, TX_TIMEOUT_us))
    {
        printf("TX packet send timeout: %s\n", rspPkt->buf);
    }
}



bool checkPendingCmds(CmdPkt* cmdPkt,  uint32 offlineCmdIndex, uint32 ignoreMask)
{
    ASSERT(offlineCmdIndex < OfflineCommand_count);


    // Check for matching offline cmd already pending
    if(commData.pendingCommands[offlineCmdIndex].active &&
       strcmp(commData.pendingCommands[offlineCmdIndex].seqNum, cmdPkt->seqNum) == 0)
    {
        // Resend pending rsp
        sendRspPending(cmdPkt);
        return false;
    }


    // Check for any pending cmds (except ignoreMask)
    int i;
    for(i = 0; i < OfflineCommand_count; i++)
    {
        if(commData.pendingCommands[i].active && (!(ignoreMask & (1 << i))))
        {
            sendRspStatusSystemBusy(cmdPkt, OfflineCommandNames[i]);
            return false;
        }
    }

    // Okay to continue
    return true;
}



static void registerPendingCmd(uint32 offlineCmdIndex, CmdPkt* cmdPkt)
{
    ASSERT(offlineCmdIndex < OfflineCommand_count);
    ASSERT(!commData.pendingCommands[offlineCmdIndex].active);
    ASSERT(cmdPkt);

    commData.pendingCommands[offlineCmdIndex].active = true;

    strncpy(commData.pendingCommands[offlineCmdIndex].seqNum,
            cmdPkt->seqNum, sizeof(commData.pendingCommands[offlineCmdIndex].seqNum));
    commData.pendingCommands[offlineCmdIndex].
        seqNum[sizeof(commData.pendingCommands[offlineCmdIndex].seqNum)-1] = '\0';

    strncpy(commData.pendingCommands[offlineCmdIndex].cmd,
            cmdPkt->cmd, sizeof(commData.pendingCommands[offlineCmdIndex].cmd));
    commData.pendingCommands[offlineCmdIndex].
        cmd[sizeof(commData.pendingCommands[offlineCmdIndex].cmd)-1] = '\0';
}



static void sendOfflineRspOk(uint32 offlineCmdIndex, const char* extraParams)
{
    RspPkt rspPkt;

    if(initOfflineRsp(&rspPkt, offlineCmdIndex, true))
    {
        addStringParamToRspPkt(&rspPkt, RSP_OK);
        if(extraParams)
        {
            addStringParamToRspPkt(&rspPkt, extraParams);
        }
        sendRspPkt(&rspPkt);
    }
}



static void sendOfflineRspError(uint32 offlineCmdIndex, ErrorCodes errorCode, const char* errorDesc)
{
    ASSERT(errorCode < num_errors);

    RspPkt rspPkt;

    if(initOfflineRsp(&rspPkt, offlineCmdIndex, true))
    {
        addStringParamToRspPkt(&rspPkt, RSP_ERROR);
        addParamToRspPkt(&rspPkt, "%03d", errorCode);
        addStringParamToRspPkt(&rspPkt, error_strings[errorCode]);

        if(errorDesc && strlen(errorDesc) > 0)
        {
            addStringParamToRspPkt(&rspPkt, "-");
            addStringParamToRspPkt(&rspPkt, errorDesc);
        }

        sendRspPkt(&rspPkt);
    }
}



static void sendOfflineRspAborted(uint32 offlineCmdIndex)
{
    ASSERT(offlineCmdIndex < OfflineCommand_count);

    RspPkt rspPkt;

    if(initOfflineRsp(&rspPkt, offlineCmdIndex, true))
    {
        addStringParamToRspPkt(&rspPkt, RSP_ERROR);
        addParamToRspPkt(&rspPkt, "%03d", err_operationAborted);
        addStringParamToRspPkt(&rspPkt, error_strings[err_operationAborted]);
        sendRspPkt(&rspPkt);
    }
}



void initRspPkt(RspPkt* rspPkt, CmdPkt* cmdPkt, const char* status)
{
    ASSERT(rspPkt);
    ASSERT(cmdPkt);
    ASSERT(status);

    rspPkt->bufByteCount = 0;
    rspPkt->paramCount   = 0;
    rspPkt->bufPtr       = rspPkt->buf;

    addStringParamToRspPkt(rspPkt, TO_HOST_FROM_MASTER_KEY);
    rspPkt->seqNum = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, cmdPkt->seqNum);
    rspPkt->cmd = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, cmdPkt->cmd);
    rspPkt->status = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, status);
    rspPkt->payload = rspPkt->bufPtr + 1;
}



static void initErrorRspPkt(RspPkt* rspPkt, CmdPkt* cmdPkt, ErrorCodes errorCode)
{
    ASSERT(rspPkt);
    ASSERT(cmdPkt);
    ASSERT(errorCode < num_errors);

    initRspPkt(rspPkt, cmdPkt, RSP_ERROR);
    addParamToRspPkt(rspPkt, "%03d", errorCode);
    addStringParamToRspPkt(rspPkt, error_strings[errorCode]);
}



static bool initOfflineRsp(RspPkt* rspPkt, uint32 offlineCmdIndex, bool clear)
{
    ASSERT(offlineCmdIndex < OfflineCommand_count);
    ASSERT(rspPkt);

    if(commData.pendingCommands[offlineCmdIndex].active)
    {
        if(clear)
        {
            commData.pendingCommands[offlineCmdIndex].active = false;
        }

        rspPkt->bufByteCount = 0;
        rspPkt->paramCount   = 0;
        rspPkt->bufPtr       = rspPkt->buf;

        addStringParamToRspPkt(rspPkt, TO_HOST_FROM_MASTER_KEY);
        rspPkt->seqNum = rspPkt->bufPtr + 1;
        addStringParamToRspPkt(rspPkt, commData.pendingCommands[offlineCmdIndex].seqNum);
        rspPkt->cmd = rspPkt->bufPtr + 1;
        addStringParamToRspPkt(rspPkt, commData.pendingCommands[offlineCmdIndex].cmd);
        rspPkt->status = rspPkt->bufPtr + 1;

        return true;
    }

    return false;
}



static void initIpPkt(RspPkt* rspPkt, const char* cmd)
{
    ASSERT(rspPkt);
    ASSERT(cmd);

    rspPkt->bufByteCount = 0;
    rspPkt->paramCount   = 0;
    rspPkt->bufPtr       = rspPkt->buf;

    addStringParamToRspPkt(rspPkt, TO_HOST_FROM_MASTER_KEY);
    rspPkt->seqNum = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, "00");
    rspPkt->cmd = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, cmd);
    rspPkt->status = rspPkt->bufPtr + 1;
    addStringParamToRspPkt(rspPkt, RSP_INFORMATION_PKT);
    rspPkt->payload = rspPkt->bufPtr + 1;
}



static void initIpErrorPkt(RspPkt* rspPkt, int errorCode)
{
    initIpPkt(rspPkt, ERROR_MSG_KEY);
    addParamToRspPkt(rspPkt, "%03d", errorCode);
    addStringParamToRspPkt(rspPkt, error_strings[errorCode]);
}



static void initIpLogPkt(RspPkt* rspPkt)
{
    initIpPkt(rspPkt, LOG_MSG_KEY);
}



void sendRspOk(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    sendRspPkt(&rspPkt);
}



static void registerAndSendRspPending(uint32 offlineCmdIndex, CmdPkt* cmdPkt)
{
    registerPendingCmd(offlineCmdIndex, cmdPkt);
    sendRspPending(cmdPkt);
}



static void sendRspPending(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_PENDING);
    sendRspPkt(&rspPkt);
}



void sendRspError(CmdPkt* cmdPkt, ErrorCodes errorCode, const char* errorDesc)
{
    ASSERT(errorCode < num_errors);

    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, errorCode);

    if(errorDesc)
    {
        addStringParamToRspPkt(&rspPkt, "-");
        addStringParamToRspPkt(&rspPkt, errorDesc);
    }

    sendRspPkt(&rspPkt);
}



static void sendRspStatusOutOfRange(CmdPkt* cmdPkt, const char* min, const char* max, const char* value)
{
    ASSERT(min);
    ASSERT(max);
    ASSERT(value);

    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, err_parameterOutOfRange);

    addParamToRspPkt(&rspPkt, "%s to %s, value %s", min, max, value);

    sendRspPkt(&rspPkt);
}



static void sendRspStatusIntOutOfRange(CmdPkt* cmdPkt, int min, int max, int value)
{
    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, err_parameterOutOfRange);

    addParamToRspPkt(&rspPkt, "%d to %d, value %d", min, max, value);

    sendRspPkt(&rspPkt);
}



static void sendRspStatusFloatOutOfRange(CmdPkt* cmdPkt, float min, float max, float value)
{
    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, err_parameterOutOfRange);

    addParamToRspPkt(&rspPkt, "%.03f to %.03f, value %.03f", min, max, value);

    sendRspPkt(&rspPkt);
}



static void sendRspStatusHexOutOfRange(CmdPkt* cmdPkt, uint32 min, uint32 max, uint32 value)
{
    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, err_parameterOutOfRange);

    addParamToRspPkt(&rspPkt, "0x%X to 0x%X, value 0x%X", min, max, value);

    sendRspPkt(&rspPkt);
}



static void sendRspStatusInvalidParameter(CmdPkt* cmdPkt)
{
    sendRspError(cmdPkt, err_invalidParameter, NULL);
}



static void sendRspStatusInvalidParameterCount(CmdPkt* cmdPkt, unsigned minExpectedParamCount, unsigned maxExpectedParamCount)
{
    RspPkt rspPkt;

    initErrorRspPkt(&rspPkt, cmdPkt, err_invalidParameterCount);

    if(minExpectedParamCount == maxExpectedParamCount)
    {
        addParamToRspPkt(&rspPkt, "- Expected %d parameter%s, received %d",
                         maxExpectedParamCount, maxExpectedParamCount == 1 ? "" : "s", cmdPkt->paramCount);
    }
    else
    {
        addParamToRspPkt(&rspPkt, "- Expected %d to %d parameter%s, received %d",
                         minExpectedParamCount, maxExpectedParamCount,
                         maxExpectedParamCount == 1 ? "" : "s", cmdPkt->paramCount);
    }

    if(cmdPkt->paramCount > 0)
    {
        addStringParamToRspPkt(&rspPkt, "-");
    }

    int paramIndex;
    for(paramIndex = 0; paramIndex < (int)cmdPkt->paramCount; ++paramIndex)
    {
        addStringParamToRspPkt(&rspPkt, cmdPkt->params[paramIndex]);
    }

    sendRspPkt(&rspPkt);
}



static void sendRspStatusUnknownCommand(CmdPkt* cmdPkt)
{
    sendRspError(cmdPkt, err_unknownCommand, NULL);
}



static void sendRspStatusSystemBusy(CmdPkt* cmdPkt, const char* errorDesc)
{
    sendRspError(cmdPkt, err_systemBusy, errorDesc);
}



static void sendRspStatusInvalidImage(CmdPkt* cmdPkt, const char* errorDesc)
{
    sendRspError(cmdPkt, err_invalidUpgradeImage, errorDesc);
}



static void sendRspStatusMissingFileData(CmdPkt* cmdPkt)
{
    sendRspError(cmdPkt, err_missingFileData, NULL);
}



static void sendRspStatusInvalidFileData(CmdPkt* cmdPkt)
{
    sendRspError(cmdPkt, err_invalidFileData, NULL);
}



static bool getIntValue(const char* str, int* value, int base)
{
    char* endPtr;

    *value = strtol(str, &endPtr, base);

    return !(*endPtr);
}



static bool getUnsignedValue(const char* str, uint32* value, int base)
{
    char* endPtr;

    *value = strtoul(str, &endPtr, base);

    return !(*endPtr);
}



static bool getFloatValue(const char* str, float* value)
{
    char* endPtr;

    *value = strtof(str, &endPtr);

    return !(*endPtr);
}



static bool validateIntValue(CmdPkt* cmdPkt, const char* str, int* value)
{
    if(!getIntValue(str, value, 10))
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}



static bool validateUnsignedValue(CmdPkt* cmdPkt, const char* str, uint32* value)
{
    if(!getUnsignedValue(str, value, 10))
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}



static bool validateHexValue(CmdPkt* cmdPkt, const char* str, uint32* value)
{
    if(!getUnsignedValue(str, value, 16))
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}



static bool validateFloatValue(CmdPkt* cmdPkt, const char* str, float* value)
{
    if(!getFloatValue(str, value))
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}



static bool validateIntParameterRange(CmdPkt* cmdPkt, int paramIndex, int minValue, int maxValue, int* value)
{
    ASSERT(cmdPkt);
    ASSERT(value);
    ASSERT(paramIndex < (int)cmdPkt->paramCount && paramIndex >= 0);

    if(!(validateIntValue(cmdPkt, cmdPkt->params[paramIndex], value)))
    {
        return false;
    }

    if(*value < minValue || *value > maxValue)
    {
        sendRspStatusIntOutOfRange(cmdPkt, minValue, maxValue, *value);
        return false;
    }

    return true;
}



static bool validateFloatParameterRange(CmdPkt* cmdPkt, int paramIndex, float minValue, float maxValue, float* value)
{
    ASSERT(cmdPkt);
    ASSERT(value);
    ASSERT(paramIndex < (int)cmdPkt->paramCount && paramIndex >= 0);

    if(!(validateFloatValue(cmdPkt, cmdPkt->params[paramIndex], value)))
    {
        return false;
    }

    if(*value < minValue || *value > maxValue)
    {
        sendRspStatusFloatOutOfRange(cmdPkt, minValue, maxValue, *value);
        return false;
    }

    return true;
}



static bool validateHexParameterRange(CmdPkt* cmdPkt, int paramIndex, uint32 minValue, uint32 maxValue, uint32* value)
{
    ASSERT(cmdPkt);
    ASSERT(value);
    ASSERT(paramIndex < (int)cmdPkt->paramCount && paramIndex >= 0);

    if(!(validateHexValue(cmdPkt, cmdPkt->params[paramIndex], value)))
    {
        return false;
    }

    if(*value < minValue || *value > maxValue)
    {
        sendRspStatusHexOutOfRange(cmdPkt, minValue, maxValue, *value);
        return false;
    }

    return true;
}




static bool validateChannelParameter(CmdPkt* cmdPkt, int paramIndex, int* channel,
                                     bool allowAll, bool allowAllBlock, bool allowAllLid, bool allowSensors)
{
    ASSERT(cmdPkt);
    ASSERT(channel);



    // Check for 'ALL'
    if(strcmp(ALL_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        if(!allowAll)
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return false;
        }

        *channel = ALL_CHANNELS;
        return true;
    }


    // Check for 'BLOCK'
    if(strcmp(BLOCK_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        if(!allowAllBlock)
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return false;
        }

        *channel = ALL_BLOCK_CHANNELS;
        return true;
    }


    // Check for heated lid
    if(strcmp(HEATED_LID_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        if(!allowAllLid)
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return false;
        }

        *channel = ALL_LID_CHANNELS;
        return true;
    }

    if(strcmp(HEATED_LIDCENTER_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *channel = LIDCENTER_CHANNEL;
        return true;
    }

    if(strcmp(HEATED_LIDRING_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *channel = LIDRING_CHANNEL;
        return true;
    }


    // Check for sensor-only channels
    if(allowSensors)
    {
        if(strcmp(AMBIENT_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
        {
            *channel = AMBIENT_CHANNEL;
            return true;
        }
        else if(strcmp(HEAT_SINK_CHANNEL_KEY, cmdPkt->params[paramIndex]) == 0)
        {
            *channel = HEAT_SINK_CHANNEL;
            return true;
        }
    }


    // Check for Row/Column or Index
    if(cmdPkt->params[paramIndex][0] >= 'A' && cmdPkt->params[paramIndex][0] <= 'D')
    {
        int row = cmdPkt->params[paramIndex][0] - 'A';
        int column;

        if(!validateIntValue(cmdPkt, &cmdPkt->params[paramIndex][1], &column)) return false;

        if(column < 1 || column > 6)
        {
            sendRspStatusOutOfRange(cmdPkt, "A1", "D6", cmdPkt->params[paramIndex]);
            return false;
        }

        *channel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column - 1];
        return true;
    }
    else if(!validateIntParameterRange(cmdPkt, paramIndex, 0, PWM_BLOCK_CHANNEL_COUNT * 2 - 1, channel))
    {
        return false;
    }


    if(*channel >= PWM_BLOCK_CHANNEL_COUNT)
    {
        sendRspStatusIntOutOfRange(cmdPkt, 0, PWM_BLOCK_CHANNEL_COUNT - 1, *channel);
        return false;
    }

    return true;
}


static bool validateMotorParameter(CmdPkt* cmdPkt, int paramIndex, stepper_t *motor)
{
    if(strcmp(LID_MOTOR_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *motor = stepper_lid;
    }
    else if(strcmp(DOOR_MOTOR_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *motor = stepper_door;
    }
    else if(strcmp(FILTER_MOTOR_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *motor = stepper_filter;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }
    return true;
}


static bool validateStepperParameter(CmdPkt* cmdPkt, int paramIndex, stepper_parameter_t *stepperParam)
{
    if(strcmp(FAST_STEPPER_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *stepperParam = stepper_fast_frequency;
    }
    else if(strcmp(SLOW_STEPPER_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *stepperParam = stepper_slow_frequency;
    }
    else if(strcmp(RAMP_STEPS_STEPPER_KEY, cmdPkt->params[paramIndex]) == 0)
    {
        *stepperParam = stepper_ramp_steps;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }
    return true;
}


static bool validateIlluminationChannel(CmdPkt* cmdPkt, int paramIndex,
                                        IlluminationColor *color)
{
    if(strcmp("B", cmdPkt->params[paramIndex]) == 0)
    {
        *color = BLUE_ILLUMINATION;
    }
    else if(strcmp("G", cmdPkt->params[paramIndex]) == 0)
    {
        *color = GREEN_ILLUMINATION;
    }
    else if(strcmp("O", cmdPkt->params[paramIndex]) == 0)
    {
        *color = ORANGE_ILLUMINATION;
    }
    else if(strcmp("R", cmdPkt->params[paramIndex]) == 0)
    {
        *color = RED_ILLUMINATION;
    }
    else if(strcmp("C", cmdPkt->params[paramIndex]) == 0)
    {
        *color = CRIMSON_ILLUMINATION;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}


static bool validateGainTypeParameter(CmdPkt* cmdPkt, int paramIndex, gainType *type)
{
    if(strcmp("LINEAR", cmdPkt->params[paramIndex]) == 0)
    {
        *type = LINEAR_SAMPLE_MODEL;
    }
    else if(strcmp("SMOOTH", cmdPkt->params[0]) == 0)
    {
        *type = SMOOTH_SAMPLE_MODEL;
    }
    else if(strcmp("BLOCK", cmdPkt->params[0]) == 0)
    {
        *type = HEATBLOCK;
    }
    else if(strcmp("LID_CENTER", cmdPkt->params[0]) == 0)
    {
        *type = HEATED_LID_CENTER;
    }
    else if(strcmp("LID_RING", cmdPkt->params[0]) == 0)
    {
        *type = HEATED_LID_RING;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return false;
    }

    return true;
}


static RampParamType validateRampParameter(CmdPkt* cmdPkt, int paramIndex, RampParam * param)
{
    RampParamType retVal = RAMP_INT_PARAM;

    if(strcmp("COOLING_TAKE_OFF", cmdPkt->params[paramIndex]) == 0)
    {
        *param = RAMP_COOLING_TAKE_OFF_ITERATIONS;
    }
    else if(strcmp("HEATING_TAKE_OFF", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_HEATING_TAKE_OFF_ITERATIONS;
    }
    else if(strcmp("COOLING_SETTLE", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_COOLING_SETTLE_ITERATIONS;
    }
    else if(strcmp("HEATING_SETTLE", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_HEATING_SETTLE_ITERATIONS;
    }
    else if(strcmp("FINAL", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_FINAL_SMOOTHING_ITERATIONS;
    }
    else if(strcmp("COOLING_TAKE_OFF_TRIM", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_COOLING_TAKE_OFF_TRIM;
        retVal = RAMP_FLOAT_PARAM;
    }
    else if(strcmp("HEATING_TAKE_OFF_TRIM", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_HEATING_TAKE_OFF_TRIM;
        retVal = RAMP_FLOAT_PARAM;
    }
    else if(strcmp("COOLING_SETTLE_TRIM", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_COOLING_SETTLE_TRIM;
        retVal = RAMP_FLOAT_PARAM;
    }
    else if(strcmp("HEATING_SETTLE_TRIM", cmdPkt->params[0]) == 0)
    {
        *param = RAMP_HEATING_SETTLE_TRIM;
        retVal = RAMP_FLOAT_PARAM;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        retVal = RAMP_INVALID_PARAM;
    }

    return retVal;
}


///////////////////////////////////////////////////
// Command handler helper functions

static void getChannelFloatData(CmdPkt* cmdPkt, float (*floatDataFunc)(int), bool allowAll)
{
    ASSERT(cmdPkt);
    ASSERT(floatDataFunc);

    int channel;


    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, allowAll, true, true, true)) return;


    // Populate response data
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addStringParamToRspPkt(&rspPkt, cmdPkt->params[0]);

    if(channel == ALL_CHANNELS)
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                channel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column];
                addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(channel));
            }
        }

        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(LIDCENTER_CHANNEL));
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(LIDRING_CHANNEL));
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(AMBIENT_CHANNEL));
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(HEAT_SINK_CHANNEL));
    }
    else if(channel == ALL_BLOCK_CHANNELS)
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                channel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column];
                addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(channel));
            }
        }
    }
    else if(channel == ALL_LID_CHANNELS)
    {
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(LIDCENTER_CHANNEL));
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(LIDRING_CHANNEL));
    }
    else
    {
        addFloat3ParamToRspPkt(&rspPkt, floatDataFunc(channel));
    }

    sendRspPkt(&rspPkt);
}



static void addFilterPositionParameter(RspPkt* rspPkt)
{
    ASSERT(rspPkt);

    switch(getFilterPosition())
    {
        case filter_clear:
            addStringParamToRspPkt(rspPkt, "CL");
            break;

        case filter_blue:
            addStringParamToRspPkt(rspPkt, "B");
            break;

        case filter_green:
            addStringParamToRspPkt(rspPkt, "G");
            break;

        case filter_orange:
            addStringParamToRspPkt(rspPkt, "O");
            break;

        case filter_red:
            addStringParamToRspPkt(rspPkt, "R");
            break;

        case filter_crimson:
            addStringParamToRspPkt(rspPkt, "C");
            break;

        case filter_moving:
            addStringParamToRspPkt(rspPkt, "Moving");
            break;

        case filter_unknownPosition:
            addStringParamToRspPkt(rspPkt, "Unknown");
            break;

        default:
            ASSERT(false);
    }
}



static void addDoorPositionParameter(RspPkt* rspPkt)
{
    ASSERT(rspPkt);

    switch(getDoorPosition())
    {
        case door_opened:
            addStringParamToRspPkt(rspPkt, "Opened");
            break;

        case door_closed:
            addStringParamToRspPkt(rspPkt, "Closed");
            break;

        case door_opening:
            addStringParamToRspPkt(rspPkt, "Opening");
            break;

        case door_closing:
            addStringParamToRspPkt(rspPkt, "Closing");
            break;

        case door_unknownPosition:
            addStringParamToRspPkt(rspPkt, "Unknown");
            break;

        default:
            ASSERT(false);
    }
}



static void addLidPositionParameter(RspPkt* rspPkt)
{
    ASSERT(rspPkt);

    switch(getLidPosition())
    {
        case lid_raised:
            addStringParamToRspPkt(rspPkt, "Raised");
            break;

        case lid_lowered:
            addStringParamToRspPkt(rspPkt, "Lowered");
            break;

        case lid_raising:
            addStringParamToRspPkt(rspPkt, "Raising");
            break;

        case lid_lowering:
            addStringParamToRspPkt(rspPkt, "Lowering");
            break;

        case lid_unknownPosition:
            addStringParamToRspPkt(rspPkt, "Unknown");
            break;

        default:
            ASSERT(false);
    }
}



static void setIlluminationWithLowPowerFlag(CmdPkt* cmdPkt, bool lowPower)
{
    if(cmdPkt->paramCount > 5)
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 0, 5);
        return;
    }

    int colorMask = NO_ILLUMINATION;

    int i;

    for(i = 0; i < (int)cmdPkt->paramCount; i++)
    {
        IlluminationColor color;

        if(!validateIlluminationChannel(cmdPkt, i, &color)) return;
        colorMask |= color;
    }

    if(!checkPendingCmds(cmdPkt, OfflineCommand_SetIllumination,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         MOTION_OFFLINE_CMD_MASK)) return;


    // Send response
    registerAndSendRspPending(OfflineCommand_SetIllumination, cmdPkt);

    // Execute LED changes
    turnOffIllumination((IlluminationColor)((~colorMask) & ALL_ILLUMINATION));
    turnOnIllumination((IlluminationColor)colorMask, lowPower,
                       signalOfflineTaskCompleteCallback,
                       OfflineCommand_SetIllumination );
}



static void systemAbort()
{
    commData.monitoringConnection = false;

    abortSelfTests();
    abortPerformanceTest();
    pwmAbort();
    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
    initializationAbort();
    motionAbort();
    illuminationAbort();
    fanAbort();

    int i;
    for(i = 0; i < OfflineCommand_count; i++)
    {
        sendOfflineRspAborted(i);
    }

    printf("System Abort\n");
}


static ErrorCodes channelToCalibrationError(int channel)
{
    if(channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL)
    {
        return err_blockNotCalibrated;
    }

    if(channel >= FIRST_LID_CHANNEL && channel <= LAST_LID_CHANNEL)
    {
        return err_lidThermalNotCalibrated;
    }

    if(channel == AMBIENT_CHANNEL)
    {
        return err_ambientSensorNotCalibrated;
    }

    if(channel == HEAT_SINK_CHANNEL)
    {
        return err_blockHeatSinkSensorNotCalibrated;
    }

    ASSERT(0);
    return err_noError;
}



///////////////////////////////////////////////////
// Command handler functions

static void chGetStatus(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);


    int i;

    for(i = 0; i < OfflineCommand_count; i++)
    {
        if(commData.pendingCommands[i].active)
        {
            addStringParamToRspPkt(&rspPkt, OfflineCommandNames[i]);
        }
    }

    if(rspPkt.paramCount == MIN_RSP_PARAM_COUNT)
    {
        addStringParamToRspPkt(&rspPkt, "Idle");
    }

    sendRspPkt(&rspPkt);
}


static void chGetActiveState(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    int i;

    for(i = 0; i < OfflineCommand_count; i++)
    {
        if(commData.pendingCommands[i].active)
        {
            addStringParamToRspPkt(&rspPkt, OfflineCommandNames[i]);
        }
    }
    
    if(!commData.pendingCommands[OfflineCommand_SetBlockTargetTemp].active &&
       blockControlEnabled())
    {
        addStringParamToRspPkt(&rspPkt, "BlockControl");
    }
    
    if(!commData.pendingCommands[OfflineCommand_SetLidTargetTemp].active &&
       lidControlEnabled())
    {
        addStringParamToRspPkt(&rspPkt, "LidControl");
    }
    
    if(!commData.pendingCommands[OfflineCommand_SetIllumination].active &&
       getIllumination((IlluminationColor)(BLUE_ILLUMINATION | GREEN_ILLUMINATION |
                                           ORANGE_ILLUMINATION | RED_ILLUMINATION |
                                           CRIMSON_ILLUMINATION)))
    {
        addStringParamToRspPkt(&rspPkt, "IlluminationControl");
    }

    if(rspPkt.paramCount == MIN_RSP_PARAM_COUNT)
    {
        addStringParamToRspPkt(&rspPkt, "Idle");
    }

    sendRspPkt(&rspPkt);
}


static void chSetPwm(CmdPkt* cmdPkt)
{
    int   channel;
    float dutyCycle_percent;


    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, true, true, false)) return;


    // Check duty cycle parameter
    if(!validateFloatParameterRange(cmdPkt, 2, 0, 100, &dutyCycle_percent)) return;


    // Check Direction Parameter
    if(strcmp("H", cmdPkt->params[1]) == 0)
    {
        //Duty Cycle is positive - no change needed
    }
    else if(strcmp("C", cmdPkt->params[1]) == 0)
    {
        //Duty Cycle is negative
        if(channel == ALL_LID_CHANNELS || channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL)
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return;
        }

        dutyCycle_percent *= -1;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }



    // Set PWM Values
    enablePwmControl(channel, (int)(dutyCycle_percent * 10.0 + 0.5));

    sendRspOk(cmdPkt);
}



static void chGetPwm(CmdPkt* cmdPkt)
{
    ASSERT(cmdPkt);

    int channel;


    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, true, true, true, false)) return;


    // Populate response data
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addParamToRspPkt(&rspPkt, cmdPkt->params[0]);

    if(channel == ALL_BLOCK_CHANNELS || channel == ALL_CHANNELS)
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                int blockChannel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column];
                addFloat1ParamToRspPkt(&rspPkt, ((float)getPwm(blockChannel, pwmCurrent))/10.0);
            }
        }
    }

    if(channel == ALL_LID_CHANNELS || channel == ALL_CHANNELS)
    {
        addFloat1ParamToRspPkt(&rspPkt, ((float)getPwm(LIDCENTER_CHANNEL, pwmCurrent))/10.0);
        addFloat1ParamToRspPkt(&rspPkt, ((float)getPwm(LIDRING_CHANNEL, pwmCurrent))/10.0);
    }
    
    if((channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL) ||
       (channel >= FIRST_LID_CHANNEL && channel <= LAST_LID_CHANNEL))
    {
        addFloat1ParamToRspPkt(&rspPkt, ((float)getPwm(channel, pwmCurrent))/10.0);
    }

    sendRspPkt(&rspPkt);
}




static void chEnableChannel(CmdPkt* cmdPkt)
{
    int channel;

    if(!validateChannelParameter(cmdPkt, 0, &channel, false, true, true, false)) return;

    // Remove functionality: enableChannel(channel);
    // Just respond OK.
    // TBD: Remove or deprecate command?

    sendRspOk(cmdPkt);
}



static void chDisableChannel(CmdPkt* cmdPkt)
{
    int channel;

    if(!validateChannelParameter(cmdPkt, 0, &channel, false, true, true, false)) return;

    disableChannel(channel);
    sendRspOk(cmdPkt);

    if(channel == ALL_BLOCK_CHANNELS)
    {
        sendOfflineRspAborted(OfflineCommand_SetBlockTargetTemp);
    }

    if(channel == ALL_LID_CHANNELS)
    {
        sendOfflineRspAborted(OfflineCommand_SetLidTargetTemp);
    }
}



static void chSetTargetTemp(CmdPkt* cmdPkt)
{
    int   channel;
    int   offlineCmd;
    float temperature_C;


    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, true, true, false)) return;


    // Check temperature parameter
    if(channel == ALL_LID_CHANNELS || channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL)
    {
        if(!validateFloatParameterRange(cmdPkt, 1, MIN_HEATED_LID_TEMPERATURE_C, MAX_HEATED_LID_TEMPERATURE_C, &temperature_C)) return;
        offlineCmd = OfflineCommand_SetLidTargetTemp;

        if(!checkPendingCmds(cmdPkt, offlineCmd,
                             SET_BLOCK_TEMP_OFFLINE_CMD_MASK |
                             MOTION_OFFLINE_CMD_MASK         |
                             SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;
    }
    else
    {
        if(!validateFloatParameterRange(cmdPkt, 1, MIN_HEATBLOCK_TEMPERATURE_C, MAX_HEATBLOCK_TEMPERATURE_C, &temperature_C)) return;
        offlineCmd = OfflineCommand_SetBlockTargetTemp;

        if(!checkPendingCmds(cmdPkt, offlineCmd,
                             SET_LID_TEMP_OFFLINE_CMD_MASK   |
                             MOTION_OFFLINE_CMD_MASK         |
                             SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;
    }


    // Set Temp Values

    // Send the pending response first so "setTargetTemp()" can send the
    // completed response, if necessary.
    registerAndSendRspPending(offlineCmd, cmdPkt);

    setTargetTemp(channel, temperature_C,
                  signalOfflineTaskCompleteCallback, offlineCmd );
}



static void chGetTargetTemp(CmdPkt* cmdPkt)
{
    getChannelFloatData(cmdPkt, getTargetTemp, false);
}



static void chReadCurrentTemp(CmdPkt* cmdPkt)
{
    getChannelFloatData(cmdPkt, getCurrentTemp, true);
}



static void chSetFrequency(CmdPkt* cmdPkt)
{
    int frequency;

    // Check duty cycle parameter
    if(!validateIntParameterRange(cmdPkt, 0, PWM_MIN_FREQUENCY, PWM_MAX_FREQUENCY, &frequency)) return;

    setPwmFrequency(frequency);

    sendRspOk(cmdPkt);
}



static void chGetFrequency(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getPwmFrequency());
    sendRspPkt(&rspPkt);
}



static void chAbort(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);
    systemAbort();
}



static void chGoToIdle(CmdPkt* cmdPkt)
{
    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
    illuminationAbort();

    sendRspOk(cmdPkt);

    sendOfflineRspAborted(OfflineCommand_SetBlockTargetTemp);
    sendOfflineRspAborted(OfflineCommand_SetLidTargetTemp);
    sendOfflineRspAborted(OfflineCommand_SetIllumination);
}



static void chReset(CmdPkt* cmdPkt)
{
    //TODO: need to reset the processor, not just PWM

    pwmReset();
    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);

    sendRspOk(cmdPkt);
}



static void chGetIllumination(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    if(getIllumination(BLUE_ILLUMINATION))
    {
        addStringParamToRspPkt(&rspPkt, "B");
    }

    if(getIllumination(GREEN_ILLUMINATION))
    {
        addStringParamToRspPkt(&rspPkt, "G");
    }

    if(getIllumination(ORANGE_ILLUMINATION))
    {
        addStringParamToRspPkt(&rspPkt, "O");
    }

    if(getIllumination(RED_ILLUMINATION))
    {
        addStringParamToRspPkt(&rspPkt, "R");
    }

    if(getIllumination(CRIMSON_ILLUMINATION))
    {
        addStringParamToRspPkt(&rspPkt, "C");
    }

    sendRspPkt(&rspPkt);
}



static void chGetIlluminationCurrent(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    IlluminationColor color;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", ( uint32 )getIlluminationCurrent( color ));
    sendRspPkt(&rspPkt);
}



static void chGetIlluminationFeedback(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    int    primary;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &primary)) return;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", ( uint32 )getIlluminationFeedback( primary ));
    sendRspPkt(&rspPkt);
}



static void chSetIllumination(CmdPkt* cmdPkt)
{
    setIlluminationWithLowPowerFlag( cmdPkt, false );
}


static void chSetIlluminationLowPower(CmdPkt* cmdPkt)
{
    setIlluminationWithLowPowerFlag( cmdPkt, true );
}


static void chSetIlluminationCalibration(CmdPkt* cmdPkt)
{
    IlluminationColor color;
    uint32 calibration;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &calibration)) return;

    if( calibration > 0xFFFF )
    {
        sendRspStatusInvalidParameter(cmdPkt);
    }
    else if( !setIlluminationCalibration( color, ( uint16 )calibration ) )
    {
        sendRspError(cmdPkt, err_ledNotCalibrated, "Error writing LED calibration!" );
    }
    else
    {
        sendRspOk(cmdPkt);
    }
}



static void chCalibrateIllumination(CmdPkt* cmdPkt)
{
    if( calibrateIllumination() )
    {
        sendRspOk(cmdPkt);
    }
    else
    {
        //\todo: Explain that exactly one LED must be on.
        sendRspStatusInvalidParameter( cmdPkt );
    }
}



static void chGetIlluminationCalibration(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    IlluminationColor color;
    uint16 calibration;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(getIlluminationCalibration( color, &calibration ))
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, err_ledNotCalibrated);
        addStringParamToRspPkt(&rspPkt, "- using default:");
    }

    addParamToRspPkt(&rspPkt, "%d", calibration);
    sendRspPkt(&rspPkt);
}



static void chSetIlluminationPower(CmdPkt* cmdPkt)
{
    IlluminationColor color;
    uint32 power;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &power)) return;

    if( power > 0xFFFF )
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    setCalibratedPower( color, ( uint16 )power );

    sendRspOk(cmdPkt);
}


static void chGetIlluminationPower(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    IlluminationColor color;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getCalibratedPower( color ));
    sendRspPkt(&rspPkt);
}


static void chSetIlluminationIntensity(CmdPkt* cmdPkt)
{
    IlluminationColor color;
    uint32 intensity;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &intensity)) return;

    if( intensity > 100 )
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    setIlluminationIntensity( color, ( float )intensity / 100.0 );

    sendRspOk(cmdPkt);
}


static void chGetIlluminationIntensity(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    IlluminationColor color;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d",
                     ( uint32 )( getIlluminationIntensity( color ) * 100.0 ) );
    sendRspPkt(&rspPkt);
}


static void chToggleIlluminationControl(CmdPkt* cmdPkt)
{
    int closedLoop;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &closedLoop)) return;

    toggleIlluminationControl( closedLoop ? true : false );

    sendRspOk(cmdPkt);
}


static void chSetIlluminationGain(CmdPkt* cmdPkt)
{
    pid_gain_type which_gain;
    float gain;
    IlluminationColor color;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(!validateFloatValue(cmdPkt, cmdPkt->params[2], &gain)) return;

    if(strcmp("p", cmdPkt->params[1]) == 0)
    {
        which_gain = proportional_gain;
    }
    else if(strcmp("i", cmdPkt->params[1]) == 0)
    {
        which_gain = integral_gain;
    }
    else if(strcmp("d", cmdPkt->params[1]) == 0)
    {
        which_gain = derivative_gain;
    }
    else if(strcmp("s", cmdPkt->params[1]) == 0)
    {
        which_gain = feed_forward_scale;
    }
    else if(strcmp("o", cmdPkt->params[1]) == 0)
    {
        which_gain = feed_forward_offset;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    setIlluminationPidGain(color, which_gain, gain);
    sendRspOk(cmdPkt);
}



static void chGetIlluminationGain(CmdPkt* cmdPkt)
{
    pid_gain_type which_gain;
    IlluminationColor color;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(strcmp("p", cmdPkt->params[1]) == 0)
    {
        which_gain = proportional_gain;
    }
    else if(strcmp("i", cmdPkt->params[1]) == 0)
    {
        which_gain = integral_gain;
    }
    else if(strcmp("d", cmdPkt->params[1]) == 0)
    {
        which_gain = derivative_gain;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%f", getIlluminationPidGain(color, which_gain));

    sendRspPkt(&rspPkt);
}



static void chSetIlluminationLowPowerCalibration(CmdPkt* cmdPkt)
{
    IlluminationColor color;
    uint32 calibration;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &calibration)) return;

    if( calibration > 0xFFFF )
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    if( !setOneAmpIlluminationCalibration( color, ( uint16 )calibration ) )
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    sendRspOk(cmdPkt);
}



static void chGetIlluminationLowPowerCalibration(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    IlluminationColor color;
    uint16 calibration;

    if(!validateIlluminationChannel(cmdPkt, 0, &color)) return;

    if(getOneAmpIlluminationCalibration( color, &calibration ))
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, err_ledNotCalibrated);
        addStringParamToRspPkt(&rspPkt, "- using default:");
    }

    addParamToRspPkt(&rspPkt, "%d", calibration);
    sendRspPkt(&rspPkt);
}



static void chGetMotorPositions(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addDoorPositionParameter(&rspPkt);
    addLidPositionParameter(&rspPkt);
    addFilterPositionParameter(&rspPkt);

    sendRspPkt(&rspPkt);
}



static void chGetFilter(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addFilterPositionParameter(&rspPkt);

    sendRspPkt(&rspPkt);
}



static void chSetFilter(CmdPkt* cmdPkt)
{
    Filters filter;

    if(strcmp("CL", cmdPkt->params[0]) == 0)
    {
        filter = filter_clear;
    }
    else if(strcmp("B", cmdPkt->params[0]) == 0)
    {
        filter = filter_blue;
    }
    else if(strcmp("G", cmdPkt->params[0]) == 0)
    {
        filter = filter_green;
    }
    else if(strcmp("O", cmdPkt->params[0]) == 0)
    {
        filter = filter_orange;
    }
    else if(strcmp("R", cmdPkt->params[0]) == 0)
    {
        filter = filter_red;
    }
    else if(strcmp("C", cmdPkt->params[0]) == 0)
    {
        filter = filter_crimson;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }


    if(!checkPendingCmds(cmdPkt, OfflineCommand_SetFilter,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_SetFilter, cmdPkt);
    setFilter(filter, signalOfflineTaskCompleteCallback, OfflineCommand_SetFilter);
}



static void chGetDoorPosition(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addDoorPositionParameter(&rspPkt);

    sendRspPkt(&rspPkt);
}



static void chOpenDoor(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_OpenDoor,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_OpenDoor, cmdPkt);
    openDoor(signalOfflineTaskCompleteCallback, OfflineCommand_OpenDoor);
}



static void chCloseDoor(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_CloseDoor,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_CloseDoor, cmdPkt);
    closeDoor(signalOfflineTaskCompleteCallback, OfflineCommand_CloseDoor);
}



static void chDisableDoor(CmdPkt* cmdPkt)
{
    disableDoor();
    sendRspOk(cmdPkt);
}



static void chGetLidPosition(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addLidPositionParameter(&rspPkt);

    sendRspPkt(&rspPkt);
}



static void chRaiseLid(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_RaiseLid,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_RaiseLid, cmdPkt);
    raiseLid(signalOfflineTaskCompleteCallback, OfflineCommand_RaiseLid);
}



static void chLowerLid(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_LowerLid,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_LowerLid, cmdPkt);
    lowerLid(signalOfflineTaskCompleteCallback, OfflineCommand_LowerLid);
}



static void chOpenCavity(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_OpenCavity,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_OpenCavity, cmdPkt);
    openCavity(signalOfflineTaskCompleteCallback, OfflineCommand_OpenCavity);
}



static void chCloseCavity(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_CloseCavity,
                         SET_TEMPERATURE_OFFLINE_CMD_MASK   |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_CloseCavity, cmdPkt);
    closeCavity(signalOfflineTaskCompleteCallback, OfflineCommand_CloseCavity);
}



static void chInitSystem(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_InitializeSystem, 0)) return;

    registerAndSendRspPending(OfflineCommand_InitializeSystem, cmdPkt);
    startSystemInitialization(signalOfflineTaskCompleteCallback, NULL, OfflineCommand_InitializeSystem, true);
}



static void chInitFilter(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_InitializeFilter, 0)) return;

    registerAndSendRspPending(OfflineCommand_InitializeFilter, cmdPkt);
    startFilterInitialization(signalOfflineTaskCompleteCallback, OfflineCommand_InitializeFilter);
}



static void chInitLid(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_InitializeLid, 0)) return;

    registerAndSendRspPending(OfflineCommand_InitializeLid, cmdPkt);
    startLidInitialization(signalOfflineTaskCompleteCallback, OfflineCommand_InitializeLid);
}



static void chInitDoor(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_InitializeDoor, 0)) return;

    registerAndSendRspPending(OfflineCommand_InitializeDoor, cmdPkt);
    startDoorInitialization(signalOfflineTaskCompleteCallback, OfflineCommand_InitializeDoor);
}



static void chFileSend(CmdPkt* cmdPkt)
{
    int fileOffset;

    if(!validateIntParameterRange(cmdPkt, 0, 0, MAX_FILE_SIZE, &fileOffset)) return;


    char* fileData = cmdPkt->params[1];

    ASSERT(fileData);

    while(*fileData)
    {
        int   i;
        uint8 byte = 0;

        for(i = 0; i < 2; i++)
        {
            if(!*fileData)
            {
                sendRspStatusMissingFileData(cmdPkt);
                return;
            }

            if((*fileData < '0' || *fileData > '9') &&
               (*fileData < 'A' || *fileData > 'F'))
            {
                sendRspStatusInvalidFileData(cmdPkt);
                return;
            }

            byte <<= 4;
            byte += (*fileData >= 'A') ? (*fileData - 'A' + 10) : (*fileData - '0');

            fileData++;
        }


        if(!storeFileData(fileOffset, byte))
        {
            sendRspStatusMissingFileData(cmdPkt);
            return;
        }

        fileOffset++;
    }

    sendRspOk(cmdPkt);
}



static void chUpgradeFirmware(CmdPkt* cmdPkt)
{
    uint32 fileSize;
    uint32 fileCRC;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[0], &fileSize))
    {
        return;
    }

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &fileCRC))
    {
        return;
    }


    // Stop system Processing
    systemStop();


    // Verify image and upgrade
    if(verifyFirmwareImage(fileSize, fileCRC))
    {
        sendRspOk(cmdPkt);
        mdelay(1000);
        updateFirmware(fileSize, fileCRC);
    }
    else
    {
        sendRspStatusInvalidImage(cmdPkt, NULL);
    }


    // Restart system processing - if upgrade failed
    systemStart();
}



static void chUpgradeFPGA(CmdPkt* cmdPkt)
{
    uint32 fileSize;
    uint32 fileCRC;

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[0], &fileSize))
    {
        return;
    }

    if(!validateUnsignedValue(cmdPkt, cmdPkt->params[1], &fileCRC))
    {
        return;
    }


    // Stop system Processing
    systemStop();


    // Verify image and upgrade
    if(verifyFPGAImage(fileSize, fileCRC))
    {
        sendRspOk(cmdPkt);
        mdelay(1000);
        updateFPGA(fileSize, fileCRC);
    }
    else
    {
        sendRspStatusInvalidImage(cmdPkt, NULL);
    }


    // Restart system processing - if upgrade failed
    systemStart();
}



static void chCalibrate(CmdPkt* cmdPkt)
{
    int channel;
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, true, true, true)) return;

    float calPoint;
    if(!validateFloatParameterRange(cmdPkt, 2, SENSOR_MIN_CAL_POINT, SENSOR_MAX_CAL_POINT, &calPoint)) return;

    bool high;
    if(strcmp("high", cmdPkt->params[1]) == 0)
    {
        high = true;
    }
    else if(strcmp("low", cmdPkt->params[1]) == 0)
    {
        high = false;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    int calIndex;
    if(!validateIntParameterRange(cmdPkt, 3, 0, TEMP_SENSOR_CALIBRATION_COUNT - 1, &calIndex)) return;

    registerAndSendRspPending(OfflineCommand_Calibrate, cmdPkt);

    if(channel == ALL_BLOCK_CHANNELS)
    {
        calibrateBlock(high, calPoint, calIndex);
    }
    else if(channel == ALL_LID_CHANNELS)
    {
        calibrateLid(high, calPoint, calIndex);
    }
    else
    {
        calibrateSensor(channel, high, calPoint, calIndex);
    }

    signalOfflineTaskCompleteCallback(OfflineCommand_Calibrate, err_noError, NULL);
}



static void chSetCalPoint(CmdPkt* cmdPkt)
{
    int channel;
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;

    float calPoint;
    if(!validateFloatParameterRange(cmdPkt, 2, SENSOR_MIN_CAL_POINT, SENSOR_MAX_CAL_POINT, &calPoint)) return;

    int calIndex;
    if(!validateIntParameterRange(cmdPkt, 3, 0, TEMP_SENSOR_CALIBRATION_COUNT - 1, &calIndex)) return;

    bool high;
    if(strcmp("high", cmdPkt->params[1]) == 0)
    {
        high = true;
    }
    else if(strcmp("low", cmdPkt->params[1]) == 0)
    {
        high = false;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    sendRspOk(cmdPkt);
    setCalibrationPoint(channel, high, calPoint, calIndex);
}



static void chSetCalibration(CmdPkt* cmdPkt)
{
    int    channel;
    uint32 lowCalibration;
    uint32 highCalibration;
    int    calIndex;

    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;
    if(!validateHexParameterRange(cmdPkt, 1, SENSOR_MIN_CAL_VALUE, SENSOR_MAX_CAL_VALUE, &lowCalibration)) return;
    if(!validateHexParameterRange(cmdPkt, 2, SENSOR_MIN_CAL_VALUE, SENSOR_MAX_CAL_VALUE, &highCalibration)) return;
    if(!validateIntParameterRange(cmdPkt, 3, 0, TEMP_SENSOR_CALIBRATION_COUNT - 1, &calIndex)) return;

    sendRspOk(cmdPkt);

    setSensorCalibration(channel, lowCalibration, highCalibration, calIndex);
}



static void chGetCalibration(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    int    channel;
    int    calIndex;
    float  lowCalPoint;
    uint16 lowCalValue;
    float  highCalPoint;
    uint16 highCalValue;
    bool   error = false;

    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;
    if(!validateIntParameterRange(cmdPkt, 1, 0, TEMP_SENSOR_CALIBRATION_COUNT - 1, &calIndex)) return;

    error |= !getCalibrationPoint( channel, false, calIndex, true, &lowCalPoint);
    error |= !getSensorCalibration(channel, false, calIndex, true, &lowCalValue);
    error |= !getCalibrationPoint( channel, true,  calIndex, true, &highCalPoint);
    error |= !getSensorCalibration(channel, true,  calIndex, true, &highCalValue);

    if(!error)
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, channelToCalibrationError(channel));
        addStringParamToRspPkt(&rspPkt, "- using defaults:");
    }

    addFloat3ParamToRspPkt(&rspPkt,           lowCalPoint);
    addParamToRspPkt(      &rspPkt, "0x%04X", lowCalValue);
    addFloat3ParamToRspPkt(&rspPkt,           highCalPoint);
    addParamToRspPkt(      &rspPkt, "0x%04X", highCalValue);
    sendRspPkt(&rspPkt);
}



static void chAdjustCalibration(CmdPkt* cmdPkt)
{
    int    channel;
    int    adjustment;
    bool   adjustHigh;
    int    calIndex;
    uint16 lowCalibration;
    uint16 highCalibration;


    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;

    if(strcmp(cmdPkt->params[1], "high") == 0)
    {
        adjustHigh = true;
    }
    else if(strcmp(cmdPkt->params[1], "low") == 0)
    {
        adjustHigh = false;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    if(!validateIntValue(cmdPkt, cmdPkt->params[2], &adjustment)) return;
    if(!validateIntParameterRange(cmdPkt, 3, 0, TEMP_SENSOR_CALIBRATION_COUNT - 1, &calIndex)) return;

    if(!getSensorCalibration(channel, false, calIndex, true, &lowCalibration) ||
       !getSensorCalibration(channel, true,  calIndex, true, &highCalibration))
    {
        sendRspError(cmdPkt, channelToCalibrationError(channel), NULL);
    }

    if(adjustHigh)
    {
        highCalibration += adjustment;
        if(highCalibration < SENSOR_MIN_CAL_VALUE || highCalibration > SENSOR_MAX_CAL_VALUE)
        {
            sendRspStatusHexOutOfRange(cmdPkt, SENSOR_MIN_CAL_VALUE, SENSOR_MAX_CAL_VALUE, highCalibration);
            return;
        }
    }
    else
    {
        lowCalibration += adjustment;
        if(lowCalibration < SENSOR_MIN_CAL_VALUE || lowCalibration > SENSOR_MAX_CAL_VALUE)
        {
            sendRspStatusHexOutOfRange(cmdPkt, SENSOR_MIN_CAL_VALUE, SENSOR_MAX_CAL_VALUE, lowCalibration);
            return;
        }
    }

    sendRspOk(cmdPkt);
    setSensorCalibration(channel, lowCalibration, highCalibration, calIndex);
}



static void chSetGain(CmdPkt* cmdPkt)
{
    gainType type;
    float gain;

    if(!validateGainTypeParameter(cmdPkt, 0, &type)) return;
    if(!validateFloatValue(cmdPkt, cmdPkt->params[2], &gain)) return;

    if(strcmp("p", cmdPkt->params[1]) == 0)
    {
        setPGain(type, gain);
    }
    else if(strcmp("i", cmdPkt->params[1]) == 0)
    {
        setIGain(type, gain);
    }
    else if(strcmp("imax", cmdPkt->params[1]) == 0)
    {
        setIMax(type, gain);
    }
    else if(strcmp("imin", cmdPkt->params[1]) == 0)
    {
        setIMin(type, gain);
    }
    else if(strcmp("d", cmdPkt->params[1]) == 0)
    {
        setDGain(type, gain);
    }
    else if(strcmp("f", cmdPkt->params[1]) == 0)
    {
        setFGain(type, gain);
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    sendRspOk(cmdPkt);
}



static void chGetGain(CmdPkt* cmdPkt)
{
    gainType type;
    float gain;

    if(!validateGainTypeParameter(cmdPkt, 0, &type)) return;

    if(strcmp("p", cmdPkt->params[1]) == 0)
    {
        gain = getPGain(type);
    }
    else if(strcmp("i", cmdPkt->params[1]) == 0)
    {
        gain = getIGain(type);
    }
    else if(strcmp("imax", cmdPkt->params[1]) == 0)
    {
        gain = getIMax(type);
    }
    else if(strcmp("imin", cmdPkt->params[1]) == 0)
    {
        gain = getIMin(type);
    }
    else if(strcmp("d", cmdPkt->params[1]) == 0)
    {
        gain = getDGain(type);
    }
    else if(strcmp("f", cmdPkt->params[1]) == 0)
    {
        gain = getFGain(type);
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%f", gain);

    sendRspPkt(&rspPkt);
}



static void chFirmwareVersion(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%s", FW_VER);
    addParamToRspPkt(&rspPkt, "%s", __DATE__);
    addParamToRspPkt(&rspPkt, "%s", __TIME__);
    sendRspPkt(&rspPkt);
}



static void chFPGAVersion(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%lu.%lu", FPGA_MAJOR_VER(), FPGA_MINOR_VER());
    sendRspPkt(&rspPkt);
}



static void chGetRaw(CmdPkt* cmdPkt)
{
    int  channel;

    if(!validateChannelParameter(cmdPkt, 0, &channel, true, true, true, true)) return;

    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    if(channel == ALL_CHANNELS)
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                channel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column];
                addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(channel));
            }
        }

        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(LIDCENTER_CHANNEL));
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(LIDRING_CHANNEL));
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(AMBIENT_CHANNEL));
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(HEAT_SINK_CHANNEL));
    }
    else if(channel == ALL_BLOCK_CHANNELS)
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                channel = COLUMN_ROW_TO_CHANNEL_TABLE[row][column];
                addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(channel));
            }
        }
    }
    else if(channel == ALL_LID_CHANNELS)
    {
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(LIDCENTER_CHANNEL));
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(LIDRING_CHANNEL));
    }
    else
    {
        addParamToRspPkt(&rspPkt, "0x%04X", getRawReading(channel));
    }

    sendRspPkt(&rspPkt);
    return;
}



static void chMonitorChannel(CmdPkt* cmdPkt)
{
    if(strcmp("off", cmdPkt->params[0]) == 0)
    {
        setWatchChannel(-1);
    }
    else
    {
        int channel;

        if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;

        setWatchChannel(channel);
    }

    sendRspOk(cmdPkt);
    return;
}



static void chMonitorRaw(CmdPkt* cmdPkt)
{
    if(strcmp("off", cmdPkt->params[0]) == 0)
    {
        setWatchRaw(-1);
    }
    else
    {
        int channel;

        if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, true)) return;

        setWatchRaw(channel);
    }

    sendRspOk(cmdPkt);
    return;
}



static void chMonitorPid(CmdPkt* cmdPkt)
{
    if(strcmp("off", cmdPkt->params[0]) == 0)
    {
        setPidMonitorChannel(-1);
    }
    else
    {
        int channel;

        if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, false)) return;

        setPidMonitorChannel(channel);
    }

    sendRspOk(cmdPkt);
}



static void chResetSensors(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);
    configSensors();
}



static void chReadMem(CmdPkt* cmdPkt)
{
    uint32 addr;
    int byteCount;

    if(!validateHexValue(cmdPkt, cmdPkt->params[0], &addr)) return;
    if(!validateIntParameterRange(cmdPkt, 1, 1, 256, &byteCount)) return;

    char* p = (char*)addr;

    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    

    addParamDelimiter(&rspPkt);

    int i;
    for(i = 0; i < byteCount && rspPkt.bufByteCount < COMM_RSP_BUF_SIZE - 2; ++i)
    {
        unsigned nibble;
        
        nibble = ((*p) >> 4) & 0x0f;
        *rspPkt.bufPtr++ = (nibble > 9 ? 'A' - 0xA : '0') + nibble;
        nibble = (*p) & 0x0f;
        *rspPkt.bufPtr++ = (nibble > 9 ? 'A' - 0xA : '0') + nibble;
        
        rspPkt.bufByteCount += 2;
        
        ++p;
    }
    
    ++rspPkt.paramCount;

    sendRspPkt(&rspPkt);
}



static void chGetMemSections(CmdPkt* cmdPkt)
{
    extern void* _start1;
    extern void* __init;
    extern void* __fini;
    extern void* __rodata_start;
    extern void* __data_start;
    extern void* __bss_start;
    extern void* _heap_start;
    extern void* _stack_end;   // Stack grows backwards - _stack_end is the lowest addr
    extern void* __scratch_start;

    static uint8* const  text    = (uint8*)&_start1;
    static uint8* const  init    = (uint8*)&__init;
    static uint8* const  fini    = (uint8*)&__fini;
    static uint8* const  rodata  = (uint8*)&__rodata_start;
    static uint8* const  data    = (uint8*)&__data_start;
    static uint8* const  bss     = (uint8*)&__bss_start;
    static uint8* const  heap    = (uint8*)&_heap_start;
    static uint8* const  stack   = (uint8*)&_stack_end;
    static uint8* const  scratch = (uint8*)&__scratch_start;

    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addParamToRspPkt(&rspPkt, ".text 0x%08lx", (uint32)text);
    addParamToRspPkt(&rspPkt, ".init 0x%08lx", (uint32)init);
    addParamToRspPkt(&rspPkt, ".fini 0x%08lx", (uint32)fini);
    addParamToRspPkt(&rspPkt, ".rodata 0x%08lx", (uint32)rodata);
    addParamToRspPkt(&rspPkt, ".data 0x%08lx", (uint32)data);
    addParamToRspPkt(&rspPkt, ".bss 0x%08lx", (uint32)bss);
    addParamToRspPkt(&rspPkt, ".heap 0x%08lx", (uint32)heap);
    addParamToRspPkt(&rspPkt, ".stack 0x%08lx", (uint32)stack);
    addParamToRspPkt(&rspPkt, ".scratch 0x%08lx", (uint32)scratch);

    sendRspPkt(&rspPkt);
}




static void chTest(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);
}


static void chToggleModel(CmdPkt* cmdPkt)
{
    int model_enable;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &model_enable)) return;

    enableModel( model_enable ? true : false );

    sendRspOk(cmdPkt);
}


static void chSetModel(CmdPkt* cmdPkt)
{
    bool pcr;
    bool sample;
    int  volume = -1;

    if(cmdPkt->paramCount < 1 || cmdPkt->paramCount > 2)
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 1, 2);
        return;
    }

    if(strcmp(PCR_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = true;
        sample = getLidPosition() == lid_lowered;
    }
    else if(strcmp(SDA_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = false;
        sample = getLidPosition() == lid_lowered;
    }
    else if(strcmp(PCR_OPEN_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = true;
        sample = false;
    }
    else if(strcmp(PCR_CLOSED_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = true;
        sample = true;
    }
    else if(strcmp(SDA_OPEN_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = false;
        sample = false;
    }
    else if(strcmp(SDA_CLOSED_KEY, cmdPkt->params[0]) == 0)
    {
        pcr    = false;
        sample = true;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    if(cmdPkt->paramCount == 1 ||
       (cmdPkt->paramCount == 2 &&
        validateIntValue(cmdPkt, cmdPkt->params[1], &volume)))
    {
        if( setModel( pcr, sample, volume ) )
        {
            sendRspOk(cmdPkt);
        }
        else
        {
            sendRspStatusInvalidParameter(cmdPkt);
        }
    }
}

static void chGetModel(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    calibrationType calType = getCalibrationType();

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    switch( calType )
    {
    case CAL_TYPE_PCR_SAMPLE:
        addStringParamToRspPkt(&rspPkt, PCR_CLOSED_KEY);
        break;
    case CAL_TYPE_PCR_BLOCK:
        addStringParamToRspPkt(&rspPkt, PCR_OPEN_KEY);
        break;
    case CAL_TYPE_SDA_SAMPLE:
        addStringParamToRspPkt(&rspPkt, SDA_CLOSED_KEY);
        break;
    case CAL_TYPE_SDA_BLOCK:
        addStringParamToRspPkt(&rspPkt, SDA_OPEN_KEY);
        break;
    default:
        ASSERT( 0 );
    }

    addParamToRspPkt(&rspPkt, "%d", getSampleVolume());

    sendRspPkt(&rspPkt);
}


static void chSetModelParam(CmdPkt* cmdPkt)
{
    int       channel;
    ModelType modelType;
    bool      heating;
    int       paramIndex;
    float     value;
    int       persist = (int)true;

    if(cmdPkt->paramCount < 4 || cmdPkt->paramCount > 5)
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 4, 5);
        return;
    }

    if(!validateChannelParameter(cmdPkt, 0, &channel,
                                 false, true, false, false)) return;

    // Check Model Parameter
    if(strcmp("25h", cmdPkt->params[1]) == 0)
    {
        modelType = model_25uL;
        heating   = true;
    }
    else if(strcmp("25c", cmdPkt->params[1]) == 0)
    {
        modelType = model_25uL;
        heating   = false;
    }
    else if(strcmp("50h", cmdPkt->params[1]) == 0)
    {
        modelType = model_50uL;
        heating   = true;
    }
    else if(strcmp("50c", cmdPkt->params[1]) == 0)
    {
        modelType = model_50uL;
        heating   = false;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    // Check "w" Parameter
    if(strcmp("w1", cmdPkt->params[2]) == 0)
    {
        paramIndex = 0;
    }
    else if(strcmp("w2", cmdPkt->params[2]) == 0)
    {
        paramIndex = 1;
    }
    else if(strcmp("w3", cmdPkt->params[2]) == 0)
    {
        paramIndex = 2;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    // Check "value" Parameter
    if(!validateFloatValue(cmdPkt, cmdPkt->params[3], &value)) return;

    // Check "persist" Parameter
    if(cmdPkt->paramCount == 5 &&
       !validateIntValue(cmdPkt, cmdPkt->params[4], &persist)) return;

    if(channel != ALL_BLOCK_CHANNELS)
    {
        setModelParam( channel, modelType, heating, paramIndex, value, persist );
    }
    else
    {
        int row;
        int column;

        for(row = 0; row < ROW_COUNT; row++)
        {
            for(column = 0; column < COLUMN_COUNT; column++)
            {
                setModelParam( COLUMN_ROW_TO_CHANNEL_TABLE[row][column],
                               modelType, heating, paramIndex, value, persist );
            }
        }
    }

    sendRspOk(cmdPkt);
}


static void chGetModelParams(CmdPkt* cmdPkt)
{
    float     w[3];
    int       channel;
    ModelType modelType;
    bool      heating;
    RspPkt    rspPkt;
    int       i;
    bool      error = false;

    if(!validateChannelParameter(cmdPkt, 0, &channel,
                                 false, false, false, false)) return;

    // Check Model Parameter
    if(strcmp("25h", cmdPkt->params[1]) == 0)
    {
        modelType = model_25uL;
        heating   = true;
    }
    else if(strcmp("25c", cmdPkt->params[1]) == 0)
    {
        modelType = model_25uL;
        heating   = false;
    }
    else if(strcmp("50h", cmdPkt->params[1]) == 0)
    {
        modelType = model_50uL;
        heating   = true;
    }
    else if(strcmp("50c", cmdPkt->params[1]) == 0)
    {
        modelType = model_50uL;
        heating   = false;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    for( i = 0; i < 3; ++i )
    {
        if(!getModelParam(channel, modelType, heating, i, &w[i])) error = true;
    }

    if(!error)
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, err_modelParamNotSet);
        addStringParamToRspPkt(&rspPkt, "- using defaults:");
    }

    for( i = 0; i < 3; ++i )
    {
        addParamToRspPkt(&rspPkt, "%.05f", w[i]);
    }

    sendRspPkt(&rspPkt);
}


static void chClearModelParams(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);
    clearModelParams();
}


static void chSetSampleVolume(CmdPkt* cmdPkt)
{
    int volume;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &volume)) return;

    if( !setSampleVolume( volume ) )
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    sendRspOk(cmdPkt);
}


static void chGetSampleVolume(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getSampleVolume());
    sendRspPkt(&rspPkt);
}


static void chGetPlateType(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addStringParamToRspPkt(&rspPkt, getPlateTypeName());
    sendRspPkt(&rspPkt);
}


static void chWriteFullScale(CmdPkt* cmdPkt)
{
    uint32 full_scale;

    if(!validateHexValue(cmdPkt, cmdPkt->params[0], &full_scale)) return;

    writeFullScale( full_scale > 0xFFFF ? 0xFFFF : ( uint16 )full_scale );

    sendRspOk(cmdPkt);
}

static void chWriteZeroScale(CmdPkt* cmdPkt)
{
    uint32 zero_scale;

    if(!validateHexValue(cmdPkt, cmdPkt->params[0], &zero_scale)) return;

    writeZeroScale( zero_scale > 0xFFFF ? 0xFFFF : ( uint16 )zero_scale );

    sendRspOk(cmdPkt);
}

static void chToggleStreaming(CmdPkt* cmdPkt)
{
    int shouldStream;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &shouldStream)) return;

    setTemperatureStreaming( shouldStream ? true : false );

    sendRspOk(cmdPkt);
}

static void chToggleLedStreaming(CmdPkt* cmdPkt)
{
    int shouldStream;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &shouldStream)) return;

    setLedStreaming( shouldStream ? true : false );

    sendRspOk(cmdPkt);
}





static void chSetBlockSerialNumber(CmdPkt* cmdPkt)
{
    setBlockSerialNumber(cmdPkt->params[0]);
    sendRspOk(cmdPkt);
}


static void chGetBlockSerialNumber(CmdPkt* cmdPkt)
{
    char serialNumber[MAX_SERIAL_NUM_LEN];
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    getBlockSerialNumber(serialNumber);

    if(!strlen(serialNumber))
    {
        addStringParamToRspPkt(&rspPkt, "not_set");
    }
    else
    {
        addStringParamToRspPkt(&rspPkt, serialNumber);
    }
    sendRspPkt(&rspPkt);
}


static void chSetBlockType(CmdPkt* cmdPkt)
{
    int type;
    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &type)) return;

    if(type < 0 || type >= pwmMap_typeCount)
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    setBlockType(type);
    sendRspOk(cmdPkt);
}


static void chGetBlockType(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    uint8  type;

    if(getBlockType(&type))
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, err_blockNotCalibrated);
        addStringParamToRspPkt(&rspPkt, "- using default:");
    }

    addParamToRspPkt(&rspPkt, "%d", (int)type);
    sendRspPkt(&rspPkt);
}


static void chMoveRelative(CmdPkt* cmdPkt)
{
    stepper_t motor;
    int steps;

    // Check Motor Parameter
    if(!validateMotorParameter(cmdPkt, 0, &motor))
    {
        return;
    }

    // Check steps parameter
    if(!validateIntValue(cmdPkt, cmdPkt->params[1], &steps))
    {
        return;
    }

    // Move Motor
    stepper_move_relative( motor, steps );
    sendRspOk(cmdPkt);
}



static void chSetMotorCalibration(CmdPkt* cmdPkt)
{
    if(cmdPkt->paramCount == 1)
    {
        if(strcmp("DOOR_CLOSED", cmdPkt->params[0]) == 0)
        {
            setCurrentDoorClosedPosition();
        }
        else if(strcmp("LID_LOWERED", cmdPkt->params[0]) == 0)
        {
            setCurrentLidLoweredPosition();
        }
        else
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return;
        }

        sendRspOk(cmdPkt);
    }
    else if(cmdPkt->paramCount == 2)
    {
        int position;

        if(!validateIntValue(cmdPkt, cmdPkt->params[1], &position)) return;

        if(strcmp("DOOR_CLOSED", cmdPkt->params[0]) == 0)
        {
            setDoorClosedPosition(position);
        }
        else if(strcmp("LID_LOWERED", cmdPkt->params[0]) == 0)
        {
            setLidLoweredPosition(position);
        }
        else
        {
            sendRspStatusInvalidParameter(cmdPkt);
            return;
        }

        sendRspOk(cmdPkt);
    }
    else
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 1, 2);
    }

}



static void chGetMotorCalibration(CmdPkt* cmdPkt)
{
    int position;
    bool error;

    if(strcmp("DOOR_CLOSED", cmdPkt->params[0]) == 0)
    {
        error = !getDoorClosedPosition(&position);
    }
    else if(strcmp("LID_LOWERED", cmdPkt->params[0]) == 0)
    {
        error = !getLidLoweredPosition(&position);
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    RspPkt rspPkt;

    if(!error)
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    }
    else
    {
        initErrorRspPkt(&rspPkt, cmdPkt, err_motorNotCalibrated);
        addStringParamToRspPkt(&rspPkt, "- using default:");
    }

    addParamToRspPkt(&rspPkt, "%d", position);
    sendRspPkt(&rspPkt);
}



static void chGetMotorSensors(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    addParamToRspPkt(&rspPkt, "Door-Home %d", stepper_is_at_home_position(stepper_door));
    addParamToRspPkt(&rspPkt, "Door-Alt %d", stepper_is_at_alt_position(stepper_door));

    addParamToRspPkt(&rspPkt, "Lid-Home %d", stepper_is_at_home_position(stepper_lid));
    addParamToRspPkt(&rspPkt, "Lid-Alt %d", stepper_is_at_alt_position(stepper_lid));

    addParamToRspPkt(&rspPkt, "Filter-Home %d", stepper_is_at_home_position(stepper_filter));
    addParamToRspPkt(&rspPkt, "Filter-Alt %d", stepper_is_at_alt_position(stepper_filter));

    sendRspPkt(&rspPkt);
}



static void chToggleVarianceCheck(CmdPkt* cmdPkt)
{
    int varianceCheckEnable;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &varianceCheckEnable)) return;

    toggleVarianceCheck( varianceCheckEnable ? true : false );

    sendRspOk(cmdPkt);
}


static void chSetRampRate(CmdPkt* cmdPkt)
{
    float rampRate_C_s;

    // Check ramp rate parameter
    if(!validateFloatParameterRange(cmdPkt, 0, MIN_RAMP_RATE_C_s, MAX_RAMP_RATE_C_s,
                                    &rampRate_C_s))
    {
        return;
    }

    // Set ramp rate
    setRampRate( ALL_BLOCK_CHANNELS, rampRate_C_s );

    sendRspOk(cmdPkt);
}



static void chGetRampRate(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt( &rspPkt, cmdPkt, RSP_OK );
    addFloat3ParamToRspPkt( &rspPkt, getRampRate( FIRST_BLOCK_CHANNEL ) );

    sendRspPkt( &rspPkt );
}



static void chSetDefaultRampRate(CmdPkt* cmdPkt)
{
    if(cmdPkt->paramCount == 0)
    {
        resetDefaultRampRate();
    }
    else if(cmdPkt->paramCount == 1)
    {
        float rampRate_C_s;

        // Check ramp rate parameter
        if(!validateFloatParameterRange(cmdPkt, 0, MIN_RAMP_RATE_C_s, MAX_RAMP_RATE_C_s, &rampRate_C_s)) return;

        // Set ramp rate
        setDefaultRampRate(rampRate_C_s);
    }
    else
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 0, 1);
        return;
    }

    sendRspOk(cmdPkt);
}


static void chGetDefaultRampRate(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addFloat3ParamToRspPkt(&rspPkt, getDefaultRampRate());
    sendRspPkt(&rspPkt);
}



static void chSetLidRampRate(CmdPkt* cmdPkt)
{
    float rampRate_C_s;

    // Check ramp rate parameter
    if(!validateFloatParameterRange(cmdPkt, 0,
                                    MIN_LID_RAMP_RATE_C_s, MAX_LID_RAMP_RATE_C_s,
                                    &rampRate_C_s))
    {
        return;
    }

    // Set ramp rate
    setRampRate( ALL_LID_CHANNELS, rampRate_C_s );

    sendRspOk(cmdPkt);
}



static void chGetLidRampRate(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt( &rspPkt, cmdPkt, RSP_OK );
    addFloat3ParamToRspPkt( &rspPkt, getRampRate( FIRST_LID_CHANNEL ) );

    sendRspPkt( &rspPkt );
}



static void chSelfTest(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_SelfTest, 0)) return;

    if(startSelfTest(signalOfflineTaskCompleteCallback, sendSelfTestStatus, OfflineCommand_SelfTest))
    {
        registerAndSendRspPending(OfflineCommand_SelfTest, cmdPkt);
    }
    else
    {
        sendRspError(cmdPkt, err_selfTestFailure, "Self Test failed to start");
    }

}


static void chSelfTestIgnoreErrors(CmdPkt* cmdPkt)
{
    selfTestIgnoreErrors();
    sendRspOk(cmdPkt);
}


static void chPerformanceTest(CmdPkt* cmdPkt)
{
    if(!checkPendingCmds(cmdPkt, OfflineCommand_PerformanceTest, 0)) return;

    if(startPerformanceTest(signalOfflineTaskCompleteCallback,
                            sendPerformanceTestStatus,
                            OfflineCommand_PerformanceTest,
                            strstr(cmdPkt->cmd, "Baseline") ? true : false))
    {
        registerAndSendRspPending(OfflineCommand_PerformanceTest, cmdPkt);
    }
    else
    {
        sendRspError(cmdPkt, err_selfTestFailure, "Performance Test failed to start");
    }

}


static void chGetPerformanceTarget(CmdPkt* cmdPkt)
{
    RspPkt           rspPkt;
    float            target;
    ThermalType      type;
    ThermalDirection direction;

    // Check Type Parameter
    if( strcmp( BLOCK_CHANNEL_KEY, cmdPkt->params[ 0 ] ) == 0 )
    {
        type = block;
    }
    else if( strcmp( HEATED_LID_CHANNEL_KEY, cmdPkt->params[ 0 ] ) == 0 )
    {
        type = lid;
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
        return;
    }

    // Check Direction Parameter
    if( strcmp( "H", cmdPkt->params[ 1 ] ) == 0 )
    {
        direction = heat;
    }
    else if( strcmp( "C", cmdPkt->params[ 1 ] ) == 0 && type == block )
    {
        direction = cool;
    }
    else
    {
        sendRspStatusInvalidParameter( cmdPkt );
        return;
    }

    // Get the target
    if( !getThermalPerformanceTarget( type, direction, &target ) )
    {
        sendRspStatusInvalidParameter(cmdPkt);
    }

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%0.1f", target);
    sendRspPkt(&rspPkt);
}


static void chGetPerformanceBaseline(CmdPkt* cmdPkt)
{
    RspPkt           rspPkt;
    int              effort;
    int              channel;
    ThermalDirection direction;

    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, false)) return;

    // Check Direction Parameter
    if( strcmp( "H", cmdPkt->params[ 1 ] ) == 0 )
    {
        direction = heat;
    }
    else if( strcmp( "C", cmdPkt->params[ 1 ] ) == 0 )
    {
        direction = cool;
    }
    else
    {
        sendRspStatusInvalidParameter( cmdPkt );
        return;
    }

    // Get the effort
    if( !getThermalBaselineEffort( channel, direction, &effort ) )
    {
        sendRspError(cmdPkt, err_performanceTestComponentBadBaseline, NULL);
    }

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%0.1f", (float)effort/10.0);
    sendRspPkt(&rspPkt);
}


static void chReboot(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);
    mdelay(100);

    reboot();
}


static void chRestoreDefaults(CmdPkt* cmdPkt)
{
    resetSystemToDefaults();
    sendRspOk(cmdPkt);
}



static void chSetBlockFan(CmdPkt* cmdPkt)
{
    float dutyCycle_percent;

    // Check duty cycle parameter
    if(validateFloatParameterRange(cmdPkt, 0, 0, 100, &dutyCycle_percent))
    {
        setFanDutyCycle(FAN_BLOCK, (int)(dutyCycle_percent * 10.0 + 0.5));
        sendRspOk(cmdPkt);
    }
}



static void chGetBlockFan(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addFloat1ParamToRspPkt(&rspPkt, ((float)getFanDutyCycle(FAN_BLOCK))/10.0);
    sendRspPkt(&rspPkt);
}



static void chSetBlockFanFrequency(CmdPkt* cmdPkt)
{
    int frequency;

    if(validateIntParameterRange(cmdPkt, 0, FAN_PWM_MIN_FREQUENCY,
                                 FAN_PWM_MAX_FREQUENCY, &frequency))
    {
        setFanPWMFrequency(FAN_BLOCK, frequency);
        sendRspOk(cmdPkt);
    }
}



static void chGetBlockFanFrequency(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getFanPWMFrequency(FAN_BLOCK));
    sendRspPkt(&rspPkt);
}



static void chSetBlockFanTachFrequency(CmdPkt* cmdPkt)
{
    int frequency;

    if(validateIntParameterRange(cmdPkt, 0, FAN_TACH_MIN_FREQUENCY,
                                 FAN_TACH_MAX_FREQUENCY, &frequency))
    {
        setFanTachFrequency(FAN_BLOCK, frequency);
        sendRspOk(cmdPkt);
    }
}



static void chGetBlockFanTachFrequency(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getFanTachFrequency(FAN_BLOCK));
    sendRspPkt(&rspPkt);
}



static void chGetBlockFanRPM(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getFanRPM(FAN_BLOCK));
    sendRspPkt(&rspPkt);
}



static void chSendErrorMessage(CmdPkt* cmdPkt)
{
    if(cmdPkt->paramCount < 1)
    {
        sendRspStatusInvalidParameterCount(cmdPkt, 1, MAX_PARAMS_COUNT);
        return;
    }

    int errorCode;
    if(!validateIntParameterRange(cmdPkt, 0, 0, num_errors - 1, &errorCode)) return;

    sendRspOk(cmdPkt);

    RspPkt errorPkt;
    initIpErrorPkt(&errorPkt, errorCode);

    if(cmdPkt->paramCount > 1)
    {
        addStringParamToRspPkt(&errorPkt, "-");

        unsigned i;
        for(i = 1; i < cmdPkt->paramCount; ++i)
        {
            addStringParamToRspPkt(&errorPkt, cmdPkt->params[i]);
        }
    }

    sendRspPkt(&errorPkt);
}



static void chSendLogMessage(CmdPkt* cmdPkt)
{
    sendRspOk(cmdPkt);

    RspPkt logPkt;
    initIpLogPkt(&logPkt);

    unsigned i;
    for(i = 0; i < cmdPkt->paramCount; ++i)
    {
        addStringParamToRspPkt(&logPkt, cmdPkt->params[i]);
    }

    sendRspPkt(&logPkt);
}


static void chSetSystemControlBoardSerialNumber(CmdPkt* cmdPkt)
{
    nvramWrite(NVRAM_ADDR_FPGA_BOARD_SERIAL_NUMBER,
               (uint8 *)cmdPkt->params[0], MAX_SERIAL_NUM_LEN - 1);
    sendRspOk(cmdPkt);
}


static void chGetSystemControlBoardSerialNumber(CmdPkt* cmdPkt)
{
    char serialNumber[MAX_SERIAL_NUM_LEN] = {0};
    RspPkt rspPkt;
    int i;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);

    if(nvramRead(NVRAM_ADDR_FPGA_BOARD_SERIAL_NUMBER,
                 (uint8 *)serialNumber, MAX_SERIAL_NUM_LEN - 1))
    {
        serialNumber[MAX_SERIAL_NUM_LEN - 1] = 0; //Ensure null termination

        for(i = 0; i < MAX_SERIAL_NUM_LEN - 1; i++)
        {
            if(!isprint(serialNumber[i]))
            {
                serialNumber[i] = 0;
                break;
            }
        }
    }

    addStringParamToRspPkt(&rspPkt, strlen(serialNumber) ? serialNumber :
                                                           "not_set");
    sendRspPkt(&rspPkt);
}


static void chWriteNonVolCRCs(CmdPkt* cmdPkt)
{
    sensorsNVWriteAllCRCs();
    illuminationNVWriteAllCRCs();
    nvramWriteCrc();

    sendRspOk(cmdPkt);
}


static void chCustomRamp(CmdPkt* cmdPkt)
{
    int ramp;
    int channel;

    // Check Ramp Parameter
    if(!validateIntParameterRange(cmdPkt, 0, 0, NUM_CUSTOM_RAMPS - 1, &ramp)) return;

    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 1, &channel, false, true, false, false)) return;
    if(channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL)
    {
        sendRspStatusInvalidParameter(cmdPkt);
    }

    if(!checkPendingCmds(cmdPkt, OfflineCommand_SetBlockTargetTemp,
                         SET_LID_TEMP_OFFLINE_CMD_MASK   |
                         MOTION_OFFLINE_CMD_MASK         |
                         SET_ILLUMINATION_OFFLINE_CMD_MASK)) return;

    registerAndSendRspPending(OfflineCommand_SetBlockTargetTemp, cmdPkt);
    customRamp(ramp, channel, signalOfflineTaskCompleteCallback,
               OfflineCommand_SetBlockTargetTemp );
}


static void chSetCustomRampData(CmdPkt* cmdPkt)
{
    int   ramp;
    int   index;
    float value;

    if(!validateIntParameterRange(cmdPkt, 0, 0, NUM_CUSTOM_RAMPS-1, &ramp)) return;
    if(!validateIntParameterRange(cmdPkt, 1, 0, MAX_RAMP_SIZE-1, &index)) return;
    if(!validateFloatValue(cmdPkt, cmdPkt->params[2], &value)) return;

    if(setCustomRampData(ramp, index, value))
    {
        sendRspOk(cmdPkt);
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
    }
}


static void chGetCustomRampData(CmdPkt* cmdPkt)
{
    int    ramp;
    int    index;
    float  value;
    RspPkt rspPkt;

    if(!validateIntParameterRange(cmdPkt, 0, 0, NUM_CUSTOM_RAMPS-1, &ramp)) return;
    if(!validateIntParameterRange(cmdPkt, 1, 0, MAX_RAMP_SIZE-1, &index)) return;

    if(getCustomRampData(ramp, index, &value))
    {
        initRspPkt(&rspPkt, cmdPkt, RSP_OK);
        addFloat3ParamToRspPkt(&rspPkt, value);
        sendRspPkt( &rspPkt );
    }
    else
    {
        sendRspStatusInvalidParameter(cmdPkt);
    }
}


static void chDisableCommWatchdog(CmdPkt* cmdPkt)
{
    commData.commWatchdogDisabled = true;
    sendRspOk(cmdPkt);
}


static void chToggleSmoothRamp(CmdPkt* cmdPkt)
{
    int smoothRampEnable;

    if(!validateIntValue(cmdPkt, cmdPkt->params[0], &smoothRampEnable)) return;

    toggleSmoothRamp( smoothRampEnable ? true : false );

    sendRspOk(cmdPkt);
}



static void chGetSmoothRampEnabled(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%s", getSmoothRampEnabled() ? "true" : "false");
    sendRspPkt(&rspPkt);
}



static void chSetRampParam(CmdPkt* cmdPkt)
{
    RampParam     param;
    RampParamType type = validateRampParameter(cmdPkt, 0, &param);

    if(type != RAMP_INVALID_PARAM)
    {
        if(type == RAMP_INT_PARAM)
        {
            int value;
            if(validateIntParameterRange(cmdPkt, 1, MIN_RAMP_INT_PARAM,
                                         MAX_RAMP_INT_PARAM, &value))
            {
                setRampParam(param, value);
                sendRspOk(cmdPkt);
                return;
            }
        }
        else if(type == RAMP_FLOAT_PARAM)
        {
            float value;
            if(validateFloatParameterRange(cmdPkt, 1, MIN_RAMP_FLOAT_PARAM,
                                           MAX_RAMP_FLOAT_PARAM, &value))
            {
                setRampFloatParam(param, value);
                sendRspOk(cmdPkt);
                return;
            }
        }
        else
        {
            ASSERT(0); // Unknown ramp param type!
        }
    }
}



static void chGetRampParam(CmdPkt* cmdPkt)
{
    RampParam param;
    RampParamType type = validateRampParameter(cmdPkt, 0, &param);

    if(type != RAMP_INVALID_PARAM)
    {
        RspPkt rspPkt;

        initRspPkt(&rspPkt, cmdPkt, RSP_OK);

        if(type==RAMP_INT_PARAM)
        {
            addParamToRspPkt(&rspPkt, "%d", getRampParam(param));
        }
        else if(type==RAMP_FLOAT_PARAM)
        {
            addParamToRspPkt(&rspPkt, "%.05f", getRampFloatParam(param));
        }
        else
        {
            ASSERT(0); // Unknown ramp param type!
        }

        sendRspPkt(&rspPkt);
    }
}



static void chSetBlockCycleCount(CmdPkt* cmdPkt)
{
    uint32 value;

    if(validateUnsignedValue(cmdPkt, cmdPkt->params[0], &value))
    {
        sensorsNVWriteBlockCycleCount(value);
        sendRspOk(cmdPkt);
    }
}



static void chGetBlockCycleCount(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%u", getBlockCycleCount());
    sendRspPkt(&rspPkt);
}



static void chBypassChannel(CmdPkt* cmdPkt)
{
    int channel;
    int bypass;

    // Check Channel Parameter
    if(!validateChannelParameter(cmdPkt, 0, &channel, false, false, false, false)) return;
    if(!validateIntValue(cmdPkt, cmdPkt->params[1], &bypass)) return;

    bypassChannel(channel, !!bypass);

    sendRspOk(cmdPkt);
}



static void chGetDoorControlValues(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getDoorStartPosition());
    addParamToRspPkt(&rspPkt, "%d", get_stepper_position(stepper_door));
    addParamToRspPkt(&rspPkt, "%d", !!getDoorHomePinFound());
    addParamToRspPkt(&rspPkt, "%d", !!getDoorAltPinFound());
    addParamToRspPkt(&rspPkt, "%d", getDoorHomePinFoundPos());
    addParamToRspPkt(&rspPkt, "%d", getDoorAltPinFoundPos());
    sendRspPkt(&rspPkt);
}



static void chGetLidControlValues(CmdPkt* cmdPkt)
{
    RspPkt rspPkt;

    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getLidStartPosition());
    addParamToRspPkt(&rspPkt, "%d", get_stepper_position(stepper_lid));
    addParamToRspPkt(&rspPkt, "%d", !!getLidHomePinFound());
    addParamToRspPkt(&rspPkt, "%d", getLidAltPinCount());
    addParamToRspPkt(&rspPkt, "%d", getLidAltSpaceCount());
    addParamToRspPkt(&rspPkt, "%d", getLidHomePinMakePos());
    addParamToRspPkt(&rspPkt, "%d", getLidAltPinMake1Pos());
    addParamToRspPkt(&rspPkt, "%d", getLidAltPinBreak1Pos());
    addParamToRspPkt(&rspPkt, "%d", getLidAltPinMake2Pos());
    addParamToRspPkt(&rspPkt, "%d", getLidAltPinBreak2Pos());
    sendRspPkt(&rspPkt);
}


static void chGetStepperParameter(CmdPkt* cmdPkt)
{
    stepper_t           motor;
    stepper_parameter_t stepperParam;

    // Check Motor Parameter
    if(!validateMotorParameter(cmdPkt, 0, &motor))
    {
        return;
    }

    // Check Stepper Parameter
    if(!validateStepperParameter(cmdPkt, 1, &stepperParam))
    {
        return;
    }

    RspPkt rspPkt;
    initRspPkt(&rspPkt, cmdPkt, RSP_OK);
    addParamToRspPkt(&rspPkt, "%d", getStepperParameter(motor, stepperParam));
    sendRspPkt(&rspPkt);
}


static void chSetStepperParameter(CmdPkt* cmdPkt)
{
    stepper_t           motor;
    stepper_parameter_t stepperParam;

    // Check Motor Parameter
    if(!validateMotorParameter(cmdPkt, 0, &motor))
    {
        return;
    }

    // Check Stepper Parameter
    if(!validateStepperParameter(cmdPkt, 1, &stepperParam))
    {
        return;
    }

    // Check value parameter
    int value;
    if(!validateIntParameterRange(cmdPkt, 2, 0, 20000, &value))
    {
        return;
    }

    setStepperParameter(motor, stepperParam, value);

    sendRspOk(cmdPkt);
}



// EOF
