//-----------------------------------------------------------------------------
//!\file
//!
//!\brief Stepper Motors Module
//!
//! This file contains the implementation of the stepper motors module.
//! The stepper motors module controls the steppers motors.  This module
//! requires a hardware-dependent module that implements the hardware
//! interface.
//!
//! Copyright (c) 2009 Idaho Technology Inc.
//-----------------------------------------------------------------------------

#include <timer.h>
#include <steppers.h>
#include <stepper_hw.h>
#include <processor.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>



typedef struct
{
    int position;
    int home_position;
    int home_pin_location;
    int max_steps;
    int slow_freq;
    int fast_freq;
    int current_freq;
    int ramp_steps;
    int fault;
    bool disable_after_move_at_home;
    bool disable_after_move_at_alt;
    bool disable_after_move_between;
    bool adjust_home_position;
    uint32 hw_address;
    uint32 hw_enable_mask;
    bool ( *home_sensor_make_hook )( int );
    bool ( *home_sensor_break_hook )( int );
    bool ( *alt_sensor_make_hook )( int );
    bool ( *alt_sensor_break_hook )( int );
} stepper_instance;



struct
{
    stepper_instance steppers[ num_steppers ];
    stepper_instance *moving_stepper;
    int target_position;
    int remaining_steps;
    int up_steps;
    int down_steps;
    int steps_taken;
    int freq_adjust;
    int increment;
} stepper_data;



enum stepper_hardware_constants
{
    max_lid_steps                 = 20000,
    max_door_steps                = 35000,
    max_filter_steps              = 35000,

    lid_home_pin_location         = 50,
    door_home_pin_location        = 20,
    filter_home_pin_location      = 0,

    lid_home_position             = 0,
    door_home_position            = 0,
    filter_home_position          = 0,

    lid_hw_enable_mask            = 0x04,
    lid_hw_address                = 0x01,
    filter_hw_enable_mask         = 0x02,
    filter_hw_address             = 0x03,
    door_hw_enable_mask           = 0x01,
    door_hw_address               = 0x00,
};



static void stepper_init_instance( stepper_instance *stepper, stepper_t id );
static void stepper_motor_callback( void );
static int  stepper_find_ramp_freq_adjust( stepper_instance *stepper );
static void stepper_disable( stepper_instance * moving_stepper );




//------------------------------------------------------------------------------
//! Initialize the stepper motor module.
//
//! This function initializes the stepper motor module.
//!
void stepper_init( void )
{
    int stepper_index;

    stepper_abort();

    for( stepper_index = 0; stepper_index < num_steppers; ++stepper_index )
    {
        stepper_init_instance( &stepper_data.steppers[ stepper_index ],
                                stepper_index );
    }

    stepper_init_hw(stepper_motor_callback);
}



//------------------------------------------------------------------------------
void stepper_abort( void )
{
    CRData crdata = enterCriticalRegion();
    {
        // If not ramping down already, start.
        if( stepper_data.moving_stepper)
        {
            if(!stepper_data.remaining_steps)
            {
                stepper_disable( stepper_data.moving_stepper );
                stepper_data.moving_stepper = NULL;
            }
            else if(stepper_data.up_steps ||
                    stepper_data.remaining_steps >= stepper_data.down_steps)
            {
                int new_remaining_steps = stepper_data.moving_stepper->ramp_steps - stepper_data.up_steps;
                int new_target_position = stepper_data.moving_stepper->position +
                                          stepper_data.increment * new_remaining_steps;
                
                if(((stepper_data.target_position - new_target_position) * stepper_data.increment) < 0)
                {
                    // New target position would move beyond the old target temp
                    new_remaining_steps = abs(stepper_data.target_position - stepper_data.moving_stepper->position);
                    new_target_position = stepper_data.target_position;
                }

                stepper_data.remaining_steps = new_remaining_steps;
                stepper_data.down_steps      = new_remaining_steps;
                stepper_data.target_position = new_target_position;

                stepper_data.up_steps = 0;
            }
        }
    }
    exitCriticalRegion(crdata);
}



//------------------------------------------------------------------------------
//! Function to set the various stepper parameters.
//
//! This function sets the \a param of the \a stepper to \a value.
//!
bool stepper_set_parameter( stepper_t stepper, stepper_parameter_t param, int value )
{
    if( stepper < num_steppers )
    {
        switch( param )
        {
        case stepper_fast_frequency:
            stepper_data.steppers[ stepper ].fast_freq = value;
            break;
        case stepper_slow_frequency:
            stepper_data.steppers[ stepper ].slow_freq = value;
            break;
        case stepper_ramp_steps:
            stepper_data.steppers[ stepper ].ramp_steps = value;
            break;
        case stepper_max_steps:
            stepper_data.steppers[ stepper ].max_steps = value;
            break;
        default:
            ASSERT( 0 );
            return false;
        }
        return true;
    }
    ASSERT( 0 );
    return false;
}

//------------------------------------------------------------------------------
bool stepper_busy_wait( uint32 ticks )
{
    Timer wait_timer;

    startTimer( &wait_timer, ticks );

    while( stepper_busy() )
    {
        if( timerExpired( &wait_timer ) )
            return false;
    }
    return true;
}

//------------------------------------------------------------------------------
bool stepper_busy( void )
{
    return stepper_data.moving_stepper != NULL;
}

//------------------------------------------------------------------------------
void stepper_reset_home_pin_location( void )
{
    // Called at ISR context
    
    if( stepper_data.moving_stepper &&
        stepper_data.moving_stepper->position != stepper_data.moving_stepper->home_pin_location )
    {
        printf("Adjusting stepper home pin position from %d to %d.\n",
               stepper_data.moving_stepper->position,
               stepper_data.moving_stepper->home_pin_location);
        stepper_data.moving_stepper->position = stepper_data.moving_stepper->home_pin_location;
    }
}

//------------------------------------------------------------------------------
int stepper_get_home_pin_location( stepper_t stepper )
{
    ASSERT( stepper < num_steppers );
    return stepper_data.steppers[ stepper ].home_pin_location;
}

//------------------------------------------------------------------------------
bool stepper_enable( stepper_t stepper, bool enable )
{
    ASSERT( stepper < num_steppers );
    if( stepper_data.moving_stepper != &stepper_data.steppers[ stepper ] )
    {
        if( enable )
            stepper_set_enable_hw( stepper_data.steppers[ stepper ].hw_enable_mask );
        else
            stepper_clear_enable_hw( stepper_data.steppers[ stepper ].hw_enable_mask );

        return true;
    }

    return false;
}

//------------------------------------------------------------------------------
bool stepper_move_relative( stepper_t stepper, int steps )
{
    ASSERT( stepper < num_steppers );
    return stepper_move_to_position( stepper,
                                     stepper_data.steppers[ stepper ].position + steps );
}

//------------------------------------------------------------------------------
bool stepper_move_to_position( stepper_t stepper, int position )
{
    ASSERT( stepper < num_steppers );
    if( stepper_data.moving_stepper )
        return false;

    stepper_set_address_hw( stepper_data.steppers[ stepper ].hw_address );

    if( ( stepper_data.steppers[ stepper ].position == position ) ||
        ( stepper_get_home_sensor_hw() && position == stepper_home ) )
    {
        return true; // No need to move, we are already there.
    }

    stepper_data.moving_stepper  = &stepper_data.steppers[ stepper ];
    stepper_data.target_position = position;
    stepper_data.steps_taken     = 0;
    stepper_data.freq_adjust     =
        stepper_find_ramp_freq_adjust( stepper_data.moving_stepper );
    stepper_set_enable_hw( stepper_data.moving_stepper->hw_enable_mask );

    if( position == stepper_home )
    {
        stepper_data.increment = -1;
        stepper_clear_direction_hw( stepper_data.moving_stepper );

        stepper_data.down_steps = stepper_data.remaining_steps = 0;
        stepper_data.up_steps = stepper_data.moving_stepper->ramp_steps;
    }
    else
    {
        stepper_data.remaining_steps =
            abs( stepper_data.moving_stepper->position - position );

        if( position < stepper_data.moving_stepper->position )
        {
            stepper_data.increment = -1;
            stepper_clear_direction_hw( stepper_data.moving_stepper );
        }
        else
        {
            stepper_data.increment = 1;
            stepper_set_direction_hw( stepper_data.moving_stepper );
        }

        if ( stepper_data.remaining_steps >=
             2 * stepper_data.moving_stepper->ramp_steps )
        {
            stepper_data.up_steps =
                stepper_data.down_steps = stepper_data.moving_stepper->ramp_steps;
        }
        else
        {
            stepper_data.up_steps   = stepper_data.remaining_steps / 2;
            stepper_data.down_steps = stepper_data.remaining_steps - stepper_data.up_steps;
        }
    }

    stepper_data.moving_stepper->current_freq = stepper_data.moving_stepper->slow_freq;

    stepper_start_step_hw( stepper_data.moving_stepper->current_freq );

    return true;
}


//------------------------------------------------------------------------------
void stepper_set_home_sensor_make_hook( stepper_t stepper, bool ( *hook_func )( int ) )
{
    ASSERT( stepper < num_steppers );
    stepper_data.steppers[ stepper ].home_sensor_make_hook = hook_func;
}


//------------------------------------------------------------------------------
void stepper_set_home_sensor_break_hook( stepper_t stepper, bool ( *hook_func )( int ) )
{
    ASSERT( stepper < num_steppers );
    stepper_data.steppers[ stepper ].home_sensor_break_hook = hook_func;
}


//------------------------------------------------------------------------------
void stepper_set_alt_sensor_make_hook( stepper_t stepper, bool ( *hook_func )( int ) )
{
    ASSERT( stepper < num_steppers );
    stepper_data.steppers[ stepper ].alt_sensor_make_hook = hook_func;
}


//------------------------------------------------------------------------------
void stepper_set_alt_sensor_break_hook( stepper_t stepper, bool ( *hook_func )( int ) )
{
    ASSERT( stepper < num_steppers );
    stepper_data.steppers[ stepper ].alt_sensor_break_hook = hook_func;
}


//------------------------------------------------------------------------------
bool stepper_is_at_home_position( stepper_t stepper )
{
    ASSERT( stepper < num_steppers );
    if( !stepper_busy() )
        stepper_set_address_hw( stepper_data.steppers[ stepper ].hw_address );
    return stepper_get_home_sensor_hw();
}


//------------------------------------------------------------------------------
bool stepper_is_at_alt_position( stepper_t stepper )
{
    ASSERT( stepper < num_steppers );
    if( !stepper_busy() )
        stepper_set_address_hw( stepper_data.steppers[ stepper ].hw_address );
    return stepper_get_alt_sensor_hw( &stepper_data.steppers[ stepper ] );
}


//------------------------------------------------------------------------------
int get_stepper_position( stepper_t stepper )
{
    ASSERT( stepper < num_steppers );
    return stepper_data.steppers[ stepper ].position;
}


//------------------------------------------------------------------------------
//! Stepper motor ISR callback.
//
//! This function is the interrupt service routine for the stepper motors.  The
//! stepper motor module uses a timer to control the stepper motors.  This
//! function is called when the timer expires.
//!
//! The interrupt service routine is responsible for tracking the location of
//! the steppers and moving the steppers to their target locations.  The home
//! sensors are monitored here.  This function is responsible for ramping
//! the step frequency up and down during each move to avoid misstepping
//! and jarring motion on the steppers.
//
static void stepper_motor_callback( void )
{
    bool abort_move = false;
    stepper_instance * moving_stepper = stepper_data.moving_stepper;

    if(!moving_stepper)
    {
        return;
    }

    moving_stepper->position += stepper_data.increment;
    ++stepper_data.steps_taken;

    if( stepper_get_home_sensor_hw() )
    {
        if( moving_stepper->home_sensor_make_hook )
        {
            abort_move = !moving_stepper->home_sensor_make_hook( moving_stepper->position );
        }
    }
    else
    {
        if( moving_stepper->home_sensor_break_hook )
        {
            abort_move = !moving_stepper->home_sensor_break_hook( moving_stepper->position );
        }
    }

    if( stepper_get_alt_sensor_hw() )
    {
        if( moving_stepper->alt_sensor_make_hook )
        {
            abort_move = !moving_stepper->alt_sensor_make_hook( moving_stepper->position );
        }
    }
    else
    {
        if( moving_stepper->alt_sensor_break_hook)
        {
            abort_move = !moving_stepper->alt_sensor_break_hook( moving_stepper->position );
        }
    }

    if( stepper_data.target_position == stepper_home && !abort_move )
    {
        if( stepper_data.steps_taken > moving_stepper->max_steps )
        {
            moving_stepper->fault = 1;
            abort_move = true;
        }
        else if( stepper_get_home_sensor_hw( moving_stepper ) )
        {
            moving_stepper->fault = 0;
            moving_stepper->position = moving_stepper->home_pin_location;

            // Step past home enough to ramp the frequency down.
            stepper_data.remaining_steps =
                stepper_data.down_steps =
                moving_stepper->ramp_steps - stepper_data.up_steps;

            stepper_data.target_position =
                moving_stepper->home_pin_location - stepper_data.remaining_steps;
        }
    }

    if( abort_move ||
       ( stepper_data.target_position != stepper_home &&
        ( ( stepper_data.target_position - moving_stepper->position ) * stepper_data.increment ) <= 0 ) )
    {
        stepper_disable( moving_stepper );
        stepper_data.moving_stepper = NULL;
    }
    else
    {
        // Ramp the stepper frequency up or down.
        if( stepper_data.remaining_steps )
            --stepper_data.remaining_steps;

        if( stepper_data.up_steps )
            --stepper_data.up_steps;

        if( stepper_data.up_steps )
        {
            stepper_data.moving_stepper->current_freq += stepper_data.freq_adjust;
        }
        else if( stepper_data.down_steps && stepper_data.remaining_steps <=
                 stepper_data.down_steps )
        {
            stepper_data.moving_stepper->current_freq -= stepper_data.freq_adjust;
        }
        
        if( stepper_data.moving_stepper->current_freq <
            stepper_data.moving_stepper->slow_freq )
        {
            stepper_data.moving_stepper->current_freq =
                stepper_data.moving_stepper->slow_freq;
        }

        stepper_start_step_hw( stepper_data.moving_stepper->current_freq );
    }
}



//------------------------------------------------------------------------------
static int stepper_find_ramp_freq_adjust( stepper_instance *stepper )
{
    ASSERT(stepper);
    return (stepper->fast_freq - stepper->slow_freq) / stepper->ramp_steps;
}



//------------------------------------------------------------------------------
static void stepper_init_instance( stepper_instance *stepper, stepper_t id )
{
    stepper->position               = 0;
    stepper->fault                  = 0;
    stepper->home_sensor_make_hook  = NULL;
    stepper->home_sensor_break_hook = NULL;
    stepper->alt_sensor_make_hook   = NULL;
    stepper->alt_sensor_break_hook  = NULL;

    switch( id )
    {
    case stepper_lid:
        stepper->hw_address                 = lid_hw_address;
        stepper->hw_enable_mask             = lid_hw_enable_mask;
        stepper->max_steps                  = max_lid_steps;
        stepper->slow_freq                  = default_lid_slow_frequency;
        stepper->fast_freq                  = default_lid_fast_frequency;
        stepper->ramp_steps                 = default_lid_ramp_steps;
        stepper->home_position              = lid_home_position;
        stepper->home_pin_location          = lid_home_pin_location;
        stepper->disable_after_move_at_home = true;
        stepper->disable_after_move_at_alt  = false;
        stepper->disable_after_move_between = true;
        stepper->adjust_home_position       = true;
        break;
    case stepper_door:
        stepper->hw_address                 = door_hw_address;
        stepper->hw_enable_mask             = door_hw_enable_mask;
        stepper->max_steps                  = max_door_steps;
        stepper->slow_freq                  = default_door_slow_frequency;
        stepper->fast_freq                  = default_door_fast_frequency;
        stepper->ramp_steps                 = default_door_ramp_steps;
        stepper->home_position              = door_home_position;
        stepper->home_pin_location          = door_home_pin_location;
        stepper->disable_after_move_at_home = false;
        stepper->disable_after_move_at_alt  = false;
        stepper->disable_after_move_between = true;
        stepper->adjust_home_position       = true;
        break;
    case stepper_filter:
        stepper->hw_address                 = filter_hw_address;
        stepper->hw_enable_mask             = filter_hw_enable_mask;
        stepper->max_steps                  = max_filter_steps;
        stepper->slow_freq                  = default_filter_slow_frequency;
        stepper->fast_freq                  = default_filter_fast_frequency;
        stepper->ramp_steps                 = default_filter_ramp_steps;
        stepper->home_position              = filter_home_position;
        stepper->home_pin_location          = filter_home_pin_location;
        stepper->disable_after_move_at_home = false;
        stepper->disable_after_move_at_alt  = false;
        stepper->disable_after_move_between = true;
        stepper->adjust_home_position       = false;
        break;
    default:
        ASSERT( 0 );
    }

    stepper_clear_enable_hw( stepper->hw_enable_mask );
}



//------------------------------------------------------------------------------
static void stepper_disable( stepper_instance * moving_stepper )
{
    if(!moving_stepper)
    {
        return;
    }
    if( moving_stepper->position == moving_stepper->home_position )
    {
        // Home
        if( moving_stepper->disable_after_move_at_home )
        {
            stepper_clear_enable_hw( moving_stepper->hw_enable_mask );
        }
    }
    else if( moving_stepper->position == stepper_data.target_position )
    {
        // Alt
        if( moving_stepper->disable_after_move_at_alt )
        {
            stepper_clear_enable_hw( moving_stepper->hw_enable_mask );
        }
    }
    else
    {
        // In between
        if( moving_stepper->disable_after_move_between )
        {
            stepper_clear_enable_hw( moving_stepper->hw_enable_mask );
        }
    }
}






//EOF
