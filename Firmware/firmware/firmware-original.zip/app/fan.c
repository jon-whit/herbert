/////////////////////////////////////////////////////////////
//
//  fan.c
//
//  Fan Driver
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#include <fan.h>
#include <xparameters.h>
#include <assert.h>
#include <string.h>
#include <timer.h>
#include <types.h>
#include <version.h>
#include <system.h>
#include <stdio.h>



///////////////////////////////////////////////////
// Constants

#define FAN_MINIMUM_FPGA_MAJOR_VER    2
#define FAN_MINIMUM_FPGA_MINOR_VER    3

#define DEFAULT_FAN_PWM_PERIOD_us     100
#define DEFAULT_FAN_TACH_PERIOD_us    1000000



///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    volatile uint32 pwmPeriod;    // PWM period in clock ticks (32 bits)
    volatile uint32 pwmDutyCycle; // PWM duty cycle in clock ticks (32 bits)
    volatile uint32 tachPeriod;   // Tach period in clock ticks (32 bits)
    volatile uint32 tachCount;    // Tach count in rev. per tach period (32 bits)
} FanRegs;


#define FAN (*((FanRegs*)XPAR_HEATSINK_FAN_CONTROLLER_BASEADDR))


typedef struct
{
    uint32    pwmPeriod_us;
    FanRegs * fanRegPtr;
} FanData;



#define PERIOD_TO_TICKS(period)                 (USEC_TO_TICKS((period)) - 1)
#define DUTY_CYCLE_TO_TICKS(period, dutyCycle)  (((int32)PERIOD_TO_TICKS((period))) * (dutyCycle) / 1000)  // Dutycycle is fixed point, tenth percent



///////////////////////////////////////////////////
// Local function prototypes



///////////////////////////////////////////////////
// Local data

static FanRegs dummyFanRegs; // Dummy register set for old FPGA images.
static FanData fanData;


///////////////////////////////////////////////////
// Interface functions

void fanInit(void)
{
    if( FPGA_MAJOR_VER() > FAN_MINIMUM_FPGA_MAJOR_VER ||
       ( FPGA_MAJOR_VER() == FAN_MINIMUM_FPGA_MAJOR_VER &&
         FPGA_MINOR_VER() >= FAN_MINIMUM_FPGA_MINOR_VER ) )
    {
        fanData.fanRegPtr = &FAN;
    }
    else
    {
        memset( &dummyFanRegs, 0, sizeof( FanRegs ) );
        fanData.fanRegPtr = &dummyFanRegs;

        printf("************************************************\n"
               "  Fan Error - Incompatible FPGA Image\n"
               "      Expecting version: %u.%u\n",
               FAN_MINIMUM_FPGA_MAJOR_VER, FAN_MINIMUM_FPGA_MINOR_VER);
        printf("      Actual version:    %lu.%lu\n",
               FPGA_MAJOR_VER(), FPGA_MINOR_VER());
        printf("    Fan conrol is unavailable!\n"
               "************************************************\n");
    }

    fanReset();
}


void fanAbort(void)
{
    fanData.fanRegPtr->pwmDutyCycle = 0;
}


void fanReset(void)
{
    fanData.pwmPeriod_us = DEFAULT_FAN_PWM_PERIOD_us;
    fanData.fanRegPtr->pwmPeriod        = PERIOD_TO_TICKS(fanData.pwmPeriod_us);
    fanData.fanRegPtr->tachPeriod       = PERIOD_TO_TICKS(DEFAULT_FAN_TACH_PERIOD_us);

    fanAbort();
}


void setFanDutyCycle(int fan, int percentDutyCycle)
{
    ASSERT(fan == 0);
    ASSERT(percentDutyCycle >= 0 && percentDutyCycle <= 1000);

    fanData.fanRegPtr->pwmDutyCycle = DUTY_CYCLE_TO_TICKS(fanData.pwmPeriod_us,
                                           percentDutyCycle);
}


int getFanDutyCycle(int fan)
{
    ASSERT(fan == 0);
    return ( fanData.fanRegPtr->pwmDutyCycle * 1000 ) / fanData.fanRegPtr->pwmPeriod;
}


void setFanPWMFrequency(int fan, int frequency_hz)
{
    ASSERT(fan == 0);

    if(frequency_hz <= 0 || frequency_hz > 1000000)
    {
        return;
    }
    
    uint32 newPeriod_us = 1000000 / frequency_hz;

    fanData.fanRegPtr->pwmDutyCycle = fanData.fanRegPtr->pwmDutyCycle * newPeriod_us / fanData.pwmPeriod_us;
    fanData.pwmPeriod_us = newPeriod_us;
    fanData.fanRegPtr->pwmPeriod = PERIOD_TO_TICKS(fanData.pwmPeriod_us);
}


int getFanPWMFrequency(int fan)
{
    ASSERT(fan == 0);
    return 1000000 / fanData.pwmPeriod_us;
}


void setFanTachFrequency(int fan, int frequency_hz)
{
    ASSERT(fan == 0);

    if(frequency_hz <= 0 || frequency_hz > 1000000)
    {
        return;
    }
    
    fanData.fanRegPtr->tachPeriod = PERIOD_TO_TICKS(1000000 / frequency_hz);
}


int getFanTachFrequency(int fan)
{
    ASSERT(fan == 0);
    return 1000000 / TICKS_TO_USEC(fanData.fanRegPtr->tachPeriod);
}


int getFanTachCount(int fan)
{
    ASSERT(fan == 0);
    return fanData.fanRegPtr->tachCount;
}


int getFanRPM(int fan)
{
    ASSERT(fan == 0);
    return 30 * fanData.fanRegPtr->tachCount;
}


bool fanIsControllable(void)
{
    return fanData.fanRegPtr != &dummyFanRegs;
}


///////////////////////////////////////////////////
// Local functions

// EOF
