/////////////////////////////////////////////////////////////
//
//  ramp.c
//
//  Plate Cycler temperature ramp generator
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#include <types.h>

typedef enum
{
    RAMP_COOLING_TAKE_OFF_ITERATIONS,
    RAMP_HEATING_TAKE_OFF_ITERATIONS,
    RAMP_COOLING_SETTLE_ITERATIONS,
    RAMP_HEATING_SETTLE_ITERATIONS,
    RAMP_FINAL_SMOOTHING_ITERATIONS,
    RAMP_COOLING_TAKE_OFF_TRIM,
    RAMP_HEATING_TAKE_OFF_TRIM,
    RAMP_COOLING_SETTLE_TRIM,
    RAMP_HEATING_SETTLE_TRIM
} RampParam;

void  rampInit();
void  resetRampParams( void );
void  setRampParam( RampParam param, int value );
int   getRampParam( RampParam param );
void  setRampFloatParam( RampParam param, float value );
float getRampFloatParam( RampParam param );
bool  startGenerateRamp( float startTemp, float endTemp, float rampRate,
                         float sampleFrequency, float *ramp, int *rampPoints,
                         void (*callbackFunc)(int, bool), int callbackRef );
