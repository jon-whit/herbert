/////////////////////////////////////////////////////////////
//
//  power.h
//
//  Driver for the power break-out relay board
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert
//
//
//  Power board outputs
//
//    J1 - Heated Lid (PWM)
//    J2 - Filter Wheel Motor
//    J2 - Single-Board Computer
//    J4 - Master Sensor Interface
//    J5 - Slave Sensor Interface
//    J6 - Illumination
//    J7 - Heat Block Fan
//    J8 - Aux (unused)

#ifndef power_h
#define power_h

#include <types.h>


typedef enum
{
    MOTOR_POWER         = 0x01,    
    COMPUTER_POWER      = 0x02,    
    MASTER_SENSOR_POWER = 0x04,    
    SLAVE_SENSOR_POWER  = 0x08,    
    ILLUMINATION_POWER  = 0x10,    
    FAN_POWER           = 0x20,    
    AUX_POWER           = 0x40,    

    ALL_POWER           = 0xFF,
} PowerDevice;



void powerInit();

void turnOnPower(PowerDevice device);
void turnOffPower(PowerDevice device);

void turnOffAllPower();



#endif
