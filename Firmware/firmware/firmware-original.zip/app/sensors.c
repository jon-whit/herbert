/////////////////////////////////////////////////////////////
//
//  sensors.c
//
//  Plate Cycler Sensor Controls
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#include <sensors.h>
#include <assert.h>
#include <timer.h>
#include <spi.h>
#include <lcd.h>
#include <nvramMap.h>
#include <string.h>
#include <version.h>
#include <stdio.h>
#include <ctype.h>
#include <startup.h>
#include <eeprom.h>
#include <comm.h>



///////////////////////////////////////////////////
// Constants

#define CONFIG_DELAY_ms               30
#define TX_TIMEOUT_us                 5000
#define RX_TIMEOUT_us                 500

#define SENSOR_BUFFER_SIZE            8

#define CALIBRATION_SAMPLE_COUNT      50
#define CALIBRATION_SAMPLE_DELAY_ms   50

#define DEFAULT_HIGH_CALIBRATION_TEMP 100.0
#define DEFAULT_LOW_CALIBRATION_TEMP  28.0

#define DEFAULT_SENSOR_HIGH_VALUE     0x7C00
#define DEFAULT_SENSOR_LOW_VALUE      0x4600

#define DEFAULT_RAW_VALUE             0
#define DEFAULT_TEMP                  20


#define SPI_INTERFACE_COUNT           2


#define NVRAM_SPI_ADDR                14
#define SPI_ADDRESS_OFF               (0xff)

#define BLOCK_CYCLE_COUNT_VALID       0xA5


enum EepromSizes
{
    EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE     = 14 * 2, // 14 channels * 2 bytes
    EEPROM_ADDR_SENSOR_CALIBRATION_POINT_SIZE      = 14 * 4, // 14 channels * 4 bytes
};

enum EepromMap
{
    // There are two sensor interface boards with 14 sensors on each
    // These indexes are per sensor board

    EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES = 0x0000, // 14 channels * 2 bytes (per calibration)
    EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_VALUES = 0x0100,
    EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT  = 0x0100, // 14 channels * 4 bytes (per calibration)
    EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_POINT  = 0x0200,

    EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES  = 0x0300, // 14 channels * 2 bytes (per calibration)
    EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES  = 0x0100,
    EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT   = 0x0400, // 14 channels * 4 bytes (per calibration)
    EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT   = 0x0200,

    EEPROM_ADDR_BLOCK_CYCLE_COUNT              = 0x5800,
    EEPROM_SIZE_BLOCK_CYCLE_COUNT              = 0x0800,
    EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE         = 0x0080,
    EEPROM_NUM_CYCLE_COUNT_PAGES               = 4,

    EEPROM_ADDR_MODEL_PARAMETERS               = 0x6000,
    EEPROM_SIZE_MODEL_PARAMETERS               = 0x1000,

    EEPROM_ADDR_PERFORMANCE_DATA               = 0x7000,
    EEPROM_SIZE_PERFORMANCE_DATA               = 0x0800,

    EEPROM_ADDR_BLOCK_DATA                     = 0x7800,
    EEPROM_SIZE_BLOCK_DATA                     = 0x0100,
    EEPROM_ADDR_BLOCK_SERIAL_NUMBER            = 0x7800, // 32 bytes
    EEPROM_ADDR_BLOCK_TYPE                     = 0x7820, // 1 byte
};




enum adc_config
{
    adc_zero_scale = 0x9300,
    adc_full_scale = 0xE000
};








///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    int   rawReading;
    float temp;
    float m[ TEMP_SENSOR_CALIBRATION_COUNT ]; //Slope   y = mx + b
    float b[ TEMP_SENSOR_CALIBRATION_COUNT ]; //Offset

    SpiInterface*    spiInterface;
    volatile uint32* spiAddrReg;
    int              spiAddr;
    
    Eeprom*          eeprom;
} Sensor;

typedef struct
{
    SpiInterface spiInterface[SPI_INTERFACE_COUNT];
    Eeprom       eeprom[SPI_INTERFACE_COUNT];
    Sensor       sensors[TEMP_SENSOR_COUNT];
} SensorData;



typedef struct
{
    unsigned spiInterface;
    unsigned spiAddress;
} SensorChannelMap;

typedef struct
{
    SensorChannelMap sensorChannelMap[PWM_BLOCK_CHANNEL_COUNT];
} SensorMap;

typedef struct
{
    uint8  status;
    uint32 count;
} BlockCyclesType;




///////////////////////////////////////////////////
// Local function prototypes

void   setBlockMapping(uint8 type);
void   storeCalibrationValue(uint8 sensor, bool high, float calPoint, int calIndex, uint16 calValue);
void   getRawSensorCalibrationAverages(uint32 rawValueAverages[TEMP_SENSOR_COUNT]);
bool   loadSensorCalibration();
bool   loadOneSensorCalibration(uint8 sensor, int calIndex);
void   configureAdc(SpiInterface* spiInterface);
void   setModeContinuous(SpiInterface* spiInterface);
void   setConfig();
void   setAddress(volatile uint32* reg, uint32 addr);
void   selectSensor(uint8 sensor);
void   deselectSensors();
uint8  getSensorStatus(uint8 sensor);
void   getModeStatus(SpiInterface* spiInterface, uint8* buffer);
void   zeroScaleCalibrate(SpiInterface* spiInterface);
void   fullScaleCalibrate(SpiInterface* spiInterface);
void   resetADC(SpiInterface* spiInterface);
void   getOffset(SpiInterface* spiInterface, uint8* buffer);
void   getFullScale(SpiInterface* spiInterface, uint8* buffer);



///////////////////////////////////////////////////
// Local data

static SensorData sensorData;



static const SensorMap sensorMaps[pwmMap_typeCount] =
{   // Hardware Index {Interface,address}
    //   A1      A2      A3      A4      A5      A6
    //   B1      B2      B3      B4      B5      B6
    //   C1      C2      C3      C4      C5      C6
    //   D1      D2      D3      D4      D5      D6
    {{ {0, 6}, {0, 7}, {0, 8}, {1, 3}, {1, 4}, {1, 5},
       {0,11}, {0,10}, {0, 9}, {1, 2}, {1, 1}, {1, 0},
       {0, 0}, {0, 1}, {0, 2}, {1, 9}, {1,10}, {1,11},
       {0, 5}, {0, 4}, {0, 3}, {1, 8}, {1, 7}, {1, 6} }},  // Type 0

    {{ {0, 6}, {0, 7}, {0, 8}, {1, 3}, {1, 4}, {1, 5},
       {0,11}, {0,10}, {0, 9}, {1, 2}, {1, 1}, {1, 0},
       {0, 0}, {0, 1}, {0, 2}, {1, 9}, {1,10}, {1,11},
       {0, 5}, {0, 4}, {0, 3}, {1, 8}, {1, 7}, {1, 6} }},  // Type 1

    {{ {0, 6}, {0, 7}, {0, 8}, {1, 3}, {1, 4}, {1, 5},
       {0,11}, {0,10}, {0, 9}, {1, 2}, {1, 1}, {1, 0},
       {0, 0}, {0, 1}, {0, 2}, {1, 9}, {1,10}, {1,11},
       {0, 5}, {0, 4}, {0, 3}, {1, 8}, {1, 7}, {1, 6} }},  // Type 2

    {{ {0,11}, {0, 9}, {0, 7}, {1, 5}, {1, 3}, {1, 1},
       {0, 6}, {0, 8}, {0,10}, {1, 0}, {1, 2}, {1, 4},
       {0, 1}, {0, 3}, {0, 5}, {1, 7}, {1, 9}, {1,11},
       {0, 4}, {0, 2}, {0, 0}, {1,10}, {1, 8}, {1, 6} }},  // Type 3
};


///////////////////////////////////////////////////
// Interface functions

const char* getSensorName(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    switch(sensor)
    {
    case BLOCK_TEMP_SENSOR0:            return "A1";
    case BLOCK_TEMP_SENSOR1:            return "A2";
    case BLOCK_TEMP_SENSOR2:            return "A3";
    case BLOCK_TEMP_SENSOR3:            return "A4";
    case BLOCK_TEMP_SENSOR4:            return "A5";
    case BLOCK_TEMP_SENSOR5:            return "A6";
    case BLOCK_TEMP_SENSOR6:            return "B1";
    case BLOCK_TEMP_SENSOR7:            return "B2";
    case BLOCK_TEMP_SENSOR8:            return "B3";
    case BLOCK_TEMP_SENSOR9:            return "B4";
    case BLOCK_TEMP_SENSOR10:           return "B5";
    case BLOCK_TEMP_SENSOR11:           return "B6";
    case BLOCK_TEMP_SENSOR12:           return "C1";
    case BLOCK_TEMP_SENSOR13:           return "C2";
    case BLOCK_TEMP_SENSOR14:           return "C3";
    case BLOCK_TEMP_SENSOR15:           return "C4";
    case BLOCK_TEMP_SENSOR16:           return "C5";
    case BLOCK_TEMP_SENSOR17:           return "C6";
    case BLOCK_TEMP_SENSOR18:           return "D1";
    case BLOCK_TEMP_SENSOR19:           return "D2";
    case BLOCK_TEMP_SENSOR20:           return "D3";
    case BLOCK_TEMP_SENSOR21:           return "D4";
    case BLOCK_TEMP_SENSOR22:           return "D5";
    case BLOCK_TEMP_SENSOR23:           return "D6";
    case HEATED_LID_CENTER_TEMP_SENSOR: return "LIDCENTER";
    case HEATED_LID_RING_TEMP_SENSOR:   return "LIDRING";
    case AMBIENT_TEMP_SENSOR:           return "AMBIENT";
    case HEAT_SINK_TEMP_SENSOR:         return "HEATSINK";
    default:                            return "Unknown";
    }
}



void sensorsInit()
{
    spiInterfaceInit(&sensorData.spiInterface[0], XPAR_SENSOR_A_SPI_DEVICE_ID,
                     XPAR_INTC_SENSOR_A_SPI_IP2INTC_IRPT_INTR,
                     XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION | XSP_CLK_PHASE_1_OPTION,
                     SPI_INVERTED_DATA);

    spiInterfaceInit(&sensorData.spiInterface[1], XPAR_SENSOR_B_SPI_DEVICE_ID,
                     XPAR_INTC_SENSOR_B_SPI_IP2INTC_IRPT_INTR,
                     XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION | XSP_CLK_PHASE_1_OPTION,
                     SPI_INVERTED_DATA);

    eepromInterfaceInit(&sensorData.eeprom[0], &sensorData.spiInterface[0],
                        &SPI_CONTROL.sensorAaddr, NVRAM_SPI_ADDR, SPI_ADDRESS_OFF,
                        &setAddress);

    eepromInterfaceInit(&sensorData.eeprom[1], &sensorData.spiInterface[1],
                        &SPI_CONTROL.sensorBaddr, NVRAM_SPI_ADDR, SPI_ADDRESS_OFF,
                        &setAddress);


    deselectSensors();



    // Get Block Type
    uint8 type;

    getBlockType(&type);
    setBlockMapping(type);



    if(!loadSensorCalibration())
    {
        sendErrorMsg( err_blockNotCalibrated, "Error loading sensor calibration!" );
    }

    configSensors();
}



void getBlockSerialNumber(char* serialNumber)
{
    ASSERT(serialNumber);

    readEeprom(&sensorData.eeprom[0], EEPROM_ADDR_BLOCK_SERIAL_NUMBER, (uint8*)serialNumber, MAX_SERIAL_NUM_LEN - 1);
    serialNumber[MAX_SERIAL_NUM_LEN - 1] = 0; //Ensure null termination

    if(!validateEepromCRC(&sensorData.eeprom[0],
                          EEPROM_ADDR_BLOCK_DATA, EEPROM_SIZE_BLOCK_DATA))
    {
        serialNumber[0] = 0;
    }
    else
    {
        int i;
        for(i = 0; i < MAX_SERIAL_NUM_LEN - 1; i++)
        {
            if(!isprint(serialNumber[i]))
            {
                serialNumber[i] = 0;
            }
        }
    }
}



void setBlockSerialNumber(char* serialNumber)
{
    ASSERT(serialNumber);

    writeEeprom(&sensorData.eeprom[0], EEPROM_ADDR_BLOCK_SERIAL_NUMBER, (uint8*)serialNumber, MAX_SERIAL_NUM_LEN - 1);
    writeEepromCRC(&sensorData.eeprom[0],
                   EEPROM_ADDR_BLOCK_DATA, EEPROM_SIZE_BLOCK_DATA);
}



bool getBlockType(uint8 *blockType)
{
    *blockType = pwmMap_default;

    if(validateEepromCRC(&sensorData.eeprom[0],
                         EEPROM_ADDR_BLOCK_DATA, EEPROM_SIZE_BLOCK_DATA))
    {
        *blockType =
            readEepromUint8(&sensorData.eeprom[0], EEPROM_ADDR_BLOCK_TYPE);
    }
    else
    {
        return false;
    }

    if( *blockType >= pwmMap_typeCount)
    {
        *blockType = pwmMap_default;
        return false;
    }

    return true;
}



void setBlockType(uint8 type)
{
    writeEepromUint8(&sensorData.eeprom[0], EEPROM_ADDR_BLOCK_TYPE, type);
    writeEepromCRC(&sensorData.eeprom[0],
                   EEPROM_ADDR_BLOCK_DATA, EEPROM_SIZE_BLOCK_DATA);
    setBlockMapping(type);
}



void configSensors()
{
    resetSensors();

    mdelay(500);

    int sensor;
    for(sensor = 0; sensor < TEMP_SENSOR_COUNT; sensor++)
    {
        sensorData.sensors[sensor].rawReading = DEFAULT_RAW_VALUE;
        sensorData.sensors[sensor].temp       = DEFAULT_TEMP;

        // Configure sensor
        selectSensor(sensor);

        zeroScaleCalibrate(sensorData.sensors[sensor].spiInterface);
        fullScaleCalibrate(sensorData.sensors[sensor].spiInterface);
        configureAdc(sensorData.sensors[sensor].spiInterface);
    }

    deselectSensors();

    mdelay(CONFIG_DELAY_ms);
}



float getSensorTemp(uint8 sensor, uint8 calIndex)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT( calIndex < TEMP_SENSOR_CALIBRATION_COUNT );

    float sensorTemp;

    sensorTemp = sensorData.sensors[sensor].m[ calIndex ] *
                 sensorData.sensors[sensor].rawReading +
                 sensorData.sensors[sensor].b[ calIndex ];

    return sensorTemp;
}


uint16 getSensorRawReading(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);

    return sensorData.sensors[sensor].rawReading;
}



void readSensorTemp(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    sensorData.sensors[sensor].rawReading = readRawSensorReading(sensor);
}



uint16 readRawSensorReading(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);

    uint8  writeBuffer[SENSOR_BUFFER_SIZE];
    uint8  readBuffer[SENSOR_BUFFER_SIZE];
    uint16 readCount;

    selectSensor(sensor);

    writeBuffer[0] = 0x58; // request to read ADC
    writeBuffer[1] = 0x00; // read ADC
    writeBuffer[2] = 0x00;

    writeBuffer[3] = 0x08; // write to mode register next
    writeBuffer[4] = 0x20; // Start new capture -
    writeBuffer[5] = 0x04; // Refresh rate - 0x04 = 62Hz



    if(spiWaitAndStartTransmit(sensorData.sensors[sensor].spiInterface, writeBuffer, 6, TX_TIMEOUT_us) != SPI_STATUS_TX_STARTED)  return 0; // SPI Write Error
    if(spiWaitAndReadData(sensorData.sensors[sensor].spiInterface, readBuffer, 6, &readCount, RX_TIMEOUT_us) != SPI_STATUS_RX_OK) return 0; // SPI Read Error
    if(readCount != 6) return 0; // SPI Read Error

    deselectSensors();

    return (readBuffer[1] << 8) + readBuffer[2];
}



void resetSensors()
{
    uint8 sensor;

    // cycle through each sensor
    for(sensor = 0; sensor < TEMP_SENSOR_COUNT; sensor++)
    {
        selectSensor(sensor);
        resetADC(sensorData.sensors[sensor].spiInterface);
    }
}



void calibrateSensor(uint8 sensor, bool high, float calPoint, int calIndex)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    systemStop();

    printf("Calibrating Channel %d at %.3f...\n", sensor, calPoint);

    uint32 rawValueAverages[TEMP_SENSOR_COUNT];

    getRawSensorCalibrationAverages(rawValueAverages);

    storeCalibrationValue(sensor, high, calPoint, calIndex, rawValueAverages[sensor]);

    loadSensorCalibration();

    systemStart();

    printf("Done calibrating\n");
}



void calibrateBlock(bool high, float calPoint, int calIndex)
{
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    systemStop();

    printf("Calibrating Block at %.3f...\n", calPoint);

    uint32 rawValueAverages[TEMP_SENSOR_COUNT];

    getRawSensorCalibrationAverages(rawValueAverages);

    int sensor;
    for(sensor = FIRST_BLOCK_TEMP_SENSOR; sensor < FIRST_BLOCK_TEMP_SENSOR + BLOCK_TEMP_SENSOR_COUNT; sensor++)
    {
        storeCalibrationValue(sensor, high, calPoint, calIndex, rawValueAverages[sensor]);
    }

    loadSensorCalibration();

    systemStart();

    printf("Done calibrating\n");
}



void calibrateLid(bool high, float calPoint, int calIndex)
{
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    systemStop();

    printf("Calibrating Lid at %.3f...\n", calPoint);

    uint32 rawValueAverages[TEMP_SENSOR_COUNT];

    getRawSensorCalibrationAverages(rawValueAverages);

    int sensor;
    for(sensor = FIRST_HEATED_LID_TEMP_SENSOR; sensor < FIRST_HEATED_LID_TEMP_SENSOR + LID_TEMP_SENSOR_COUNT; sensor++)
    {
        storeCalibrationValue(sensor, high, calPoint, calIndex, rawValueAverages[sensor]);
    }

    loadSensorCalibration();

    systemStart();

    printf("Done calibrating\n");
}



void setCalibrationPoint(uint8 sensor, bool high, float calPoint, int calIndex)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    uint32 value;
    uint16 eepromCalStart = high ? EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT :
                                   EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT;
    uint16 eepromCalAddr  = eepromCalStart +
                            EEPROM_ADDR_SENSOR_CALIBRATION_POINT_SIZE * calIndex  +
                            sensorData.sensors[sensor].spiAddr * sizeof(uint32);

    memcpy(&value, &calPoint, sizeof(uint32));

    writeEepromUint32(sensorData.sensors[sensor].eeprom, eepromCalAddr, value);
    writeEepromCRC(sensorData.sensors[sensor].eeprom,
                   eepromCalStart, EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT);

    loadSensorCalibration();
}



bool getCalibrationPoint(uint8 sensor, bool high, int calIndex,
                         bool validateCRC, float *calPoint)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    uint16 eepromCalStart = high ? EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT :
                                   EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT;
    uint16 eepromCalAddr  = eepromCalStart +
                            EEPROM_ADDR_SENSOR_CALIBRATION_POINT_SIZE * calIndex +
                            sensorData.sensors[sensor].spiAddr * sizeof(uint32);

    uint32 value = readEepromUint32(sensorData.sensors[sensor].eeprom,
                                    eepromCalAddr);

    if(validateCRC &&
       !validateEepromCRC(sensorData.sensors[sensor].eeprom,
                          eepromCalStart, EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT))
    {
        value = 0xFFFFFFFF;
    }

    memcpy(calPoint, &value, 4);

    if(value != 0xFFFFFFFF &&
       *calPoint <= SENSOR_MAX_CAL_POINT && *calPoint >= SENSOR_MIN_CAL_POINT)
    {
        return true;
    }

    *calPoint = high ? DEFAULT_HIGH_CALIBRATION_TEMP :
                       DEFAULT_LOW_CALIBRATION_TEMP;
    return false;
}



void setSensorCalibration(uint8 sensor, uint16 lowCalibration,
                          uint16 highCalibration, int calIndex)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    uint16 eepromLowCalStart = EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES +
                               EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE * calIndex;
    uint16 eepromHighCalStart = EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES +
                                EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE * calIndex;

    writeEepromUint16(sensorData.sensors[sensor].eeprom,
                      eepromLowCalStart + sensorData.sensors[sensor].spiAddr * sizeof(uint16),
                      lowCalibration);
    writeEepromCRC(sensorData.sensors[sensor].eeprom,
                   EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES,
                   EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES);

    writeEepromUint16(sensorData.sensors[sensor].eeprom,
                      eepromHighCalStart + sensorData.sensors[sensor].spiAddr * sizeof(uint16),
                      highCalibration);
    writeEepromCRC(sensorData.sensors[sensor].eeprom,
                   EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES,
                   EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_VALUES);

    loadSensorCalibration();
}



bool getSensorCalibration(uint8 sensor, bool high, int calIndex,
                          bool validateCRC, uint16 *calValue)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT(calIndex < TEMP_SENSOR_CALIBRATION_COUNT);

    uint16 eepromCalStart = high ? EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES :
                                   EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES;
    uint16 eepromCalAddr  = eepromCalStart +
                            EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE*calIndex +
                            sensorData.sensors[sensor].spiAddr * sizeof(uint16);

    *calValue = readEepromUint16(sensorData.sensors[sensor].eeprom, eepromCalAddr);

    if( *calValue <= SENSOR_MAX_CAL_VALUE && *calValue >= SENSOR_MIN_CAL_VALUE &&
        ( !validateCRC ||
          validateEepromCRC(sensorData.sensors[sensor].eeprom, eepromCalStart,
                            EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES ) ) )
    {
        return true;
    }

    *calValue = high ? DEFAULT_SENSOR_HIGH_VALUE : DEFAULT_SENSOR_LOW_VALUE;
    return false;
}


bool validateSensorCalibrationCRCs( void )
{
    return(validateEepromCRC(&sensorData.eeprom[0],
                             EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES,
                             EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES)  &&
           validateEepromCRC(&sensorData.eeprom[0],
                             EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES,
                             EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_VALUES) &&
           validateEepromCRC(&sensorData.eeprom[0],
                             EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT,
                             EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT)   &&
           validateEepromCRC(&sensorData.eeprom[0],
                             EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT,
                             EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_POINT)  &&
           validateEepromCRC(&sensorData.eeprom[1],
                             EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES,
                             EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES)  &&
           validateEepromCRC(&sensorData.eeprom[1],
                             EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES,
                             EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_VALUES) &&
           validateEepromCRC(&sensorData.eeprom[1],
                              EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT,
                             EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT)   &&
           validateEepromCRC(&sensorData.eeprom[1],
                             EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT,
                             EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_POINT));
}


uint32 sensorsNVReadModelParam( uint16 address )
{
    ASSERT( address < EEPROM_SIZE_MODEL_PARAMETERS );

    return readEepromUint32( &sensorData.eeprom[ 0 ],
                             EEPROM_ADDR_MODEL_PARAMETERS + address );
}

void sensorsNVWriteModelParam( uint16 address, uint32 value )
{
    ASSERT( address < EEPROM_SIZE_MODEL_PARAMETERS );

    writeEepromUint32( &sensorData.eeprom[ 0 ],
                       EEPROM_ADDR_MODEL_PARAMETERS + address, value);
}

bool sensorsNVValidateModelDataCRC( void )
{
    return validateEepromCRC( &sensorData.eeprom[0],
                              EEPROM_ADDR_MODEL_PARAMETERS,
                              EEPROM_SIZE_MODEL_PARAMETERS );
}

void sensorsNVWriteModelDataCRC( void )
{
    writeEepromCRC( &sensorData.eeprom[0],
                    EEPROM_ADDR_MODEL_PARAMETERS, EEPROM_SIZE_MODEL_PARAMETERS );
}

uint32 sensorsNVReadPerfData( uint16 address )
{
    ASSERT( address < EEPROM_SIZE_PERFORMANCE_DATA );

    return readEepromUint32( &sensorData.eeprom[ 0 ],
                             EEPROM_ADDR_PERFORMANCE_DATA + address );
}

void sensorsNVWritePerfData( uint16 address, uint32 value )
{
    ASSERT( address < EEPROM_SIZE_PERFORMANCE_DATA );

    writeEepromUint32( &sensorData.eeprom[ 0 ],
                       EEPROM_ADDR_PERFORMANCE_DATA + address, value);
}

bool sensorsNVValidatePerfDataCRC( void )
{
    return validateEepromCRC( &sensorData.eeprom[0],
                              EEPROM_ADDR_PERFORMANCE_DATA,
                              EEPROM_SIZE_PERFORMANCE_DATA );
}

void sensorsNVWritePerfDataCRC( void )
{
    writeEepromCRC( &sensorData.eeprom[0],
                    EEPROM_ADDR_PERFORMANCE_DATA, EEPROM_SIZE_PERFORMANCE_DATA );
}

void sensorsNVWriteAllCRCs( void )
{
    int i;

    for( i = 0; i < SPI_INTERFACE_COUNT; ++i )
    {
        writeEepromCRC(&sensorData.eeprom[i],
                       EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES,
                       EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_VALUES);
        writeEepromCRC(&sensorData.eeprom[i],
                       EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_POINT,
                       EEPROM_SIZE_SENSOR_HIGH_CALIBRATION_POINT);
        writeEepromCRC(&sensorData.eeprom[i],
                       EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES,
                       EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES);
        writeEepromCRC(&sensorData.eeprom[i],
                       EEPROM_ADDR_SENSOR_LOW_CALIBRATION_POINT,
                       EEPROM_SIZE_SENSOR_LOW_CALIBRATION_POINT);
    }

    sensorsNVWriteModelDataCRC();
    sensorsNVWritePerfDataCRC();
    writeEepromCRC(&sensorData.eeprom[0],
                   EEPROM_ADDR_BLOCK_DATA, EEPROM_SIZE_BLOCK_DATA);
}

uint32 sensorsNVReadBlockCycleCount( void )
{
    int             page;
    BlockCyclesType blockCycles;

    // Read block cycle counts from EEPROM until we find a valid one.
    for( page = 0; page < EEPROM_NUM_CYCLE_COUNT_PAGES; ++page )
    {
        readEeprom( &sensorData.eeprom[ 0 ],
                    EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                    EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * page,
                    (uint8*)&blockCycles, sizeof( blockCycles ) );

        if( blockCycles.status == BLOCK_CYCLE_COUNT_VALID )
        {
            break;
        }
    }

    return blockCycles.status == BLOCK_CYCLE_COUNT_VALID ? blockCycles.count : 0;
}

void sensorsNVUpdateBlockCycleCount( uint32 cycles )
{
    int             page;
    int             pageToInvalidate;
    bool            invalidatePage = false;
    BlockCyclesType blockCycles;

    if( cycles )
    {
        // Read block cycle counts from EEPROM until we find a valid one.
        for( page = 0; page < EEPROM_NUM_CYCLE_COUNT_PAGES; ++page )
        {
            readEeprom( &sensorData.eeprom[ 0 ],
                        EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                        EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * page,
                        (uint8*)&blockCycles, sizeof( blockCycles ) );

            if( blockCycles.status == BLOCK_CYCLE_COUNT_VALID )
            {
                invalidatePage   = true;
                pageToInvalidate = page++;
                break;
            }
        }

        if( blockCycles.status != BLOCK_CYCLE_COUNT_VALID )
        {
            // No valid cycle count!
            blockCycles.status = BLOCK_CYCLE_COUNT_VALID;
            blockCycles.count  = 0;
        }

        page %= EEPROM_NUM_CYCLE_COUNT_PAGES;

        blockCycles.count += cycles;

        writeEeprom( &sensorData.eeprom[ 0 ],
                     EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                     EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * page,
                     (uint8*)&blockCycles, sizeof( blockCycles ) );

        if( invalidatePage )
        {
            blockCycles.status = '\xFF';

            writeEeprom( &sensorData.eeprom[ 0 ],
                         EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                         EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * pageToInvalidate,
                         (uint8*)&blockCycles, sizeof( blockCycles ) );
        }
    }
}

void sensorsNVWriteBlockCycleCount( uint32 cycles )
{
    int             page;
    int             pageToInvalidate;
    bool            invalidatePage = false;
    BlockCyclesType blockCycles;

    // Read block cycle counts from EEPROM until we find a valid one.
    for( page = 0; page < EEPROM_NUM_CYCLE_COUNT_PAGES; ++page )
    {
        readEeprom( &sensorData.eeprom[ 0 ],
                    EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                    EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * page,
                    (uint8*)&blockCycles, sizeof( blockCycles ) );

        if( blockCycles.status == BLOCK_CYCLE_COUNT_VALID )
        {
            invalidatePage   = true;
            pageToInvalidate = page++;
            break;
        }
    }

    if( blockCycles.status != BLOCK_CYCLE_COUNT_VALID )
    {
        // No valid cycle count!
        blockCycles.status = BLOCK_CYCLE_COUNT_VALID;
    }

    page %= EEPROM_NUM_CYCLE_COUNT_PAGES;

    blockCycles.count = cycles;

    writeEeprom( &sensorData.eeprom[ 0 ],
                 EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                 EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * page,
                 (uint8*)&blockCycles, sizeof( blockCycles ) );

    if( invalidatePage )
    {
        blockCycles.status = '\xFF';

        writeEeprom( &sensorData.eeprom[ 0 ],
                     EEPROM_ADDR_BLOCK_CYCLE_COUNT +
                     EEPROM_SIZE_BLOCK_CYCLE_COUNT_PAGE * pageToInvalidate,
                     (uint8*)&blockCycles, sizeof( blockCycles ) );
    }
}


///////////////////////////////////////////////////
// Local functions

void setBlockMapping(uint8 type)
{
    ASSERT(type < pwmMap_typeCount);
    
    const SensorMap* map = &sensorMaps[type];

    int channel;

 
    
    // Set SPI interface
    for(channel = 0; channel < BLOCK_TEMP_SENSOR_COUNT; channel++)
    {
        ASSERT(map->sensorChannelMap[channel].spiInterface >= 0 &&
               map->sensorChannelMap[channel].spiInterface <= 1);
        
        sensorData.sensors[channel].spiInterface =
            &sensorData.spiInterface[map->sensorChannelMap[channel].spiInterface];
    }

    sensorData.sensors[HEATED_LID_CENTER_TEMP_SENSOR].spiInterface = &sensorData.spiInterface[0];
    sensorData.sensors[HEATED_LID_RING_TEMP_SENSOR  ].spiInterface = &sensorData.spiInterface[0];

    sensorData.sensors[AMBIENT_TEMP_SENSOR  ].spiInterface = &sensorData.spiInterface[1];
    sensorData.sensors[HEAT_SINK_TEMP_SENSOR].spiInterface = &sensorData.spiInterface[1];



    // Set EEPROM interface
    for(channel = 0; channel < BLOCK_TEMP_SENSOR_COUNT; channel++)
    {
        sensorData.sensors[channel].eeprom = &sensorData.eeprom[map->sensorChannelMap[channel].spiInterface];
    }

    sensorData.sensors[HEATED_LID_CENTER_TEMP_SENSOR].eeprom = &sensorData.eeprom[0];
    sensorData.sensors[HEATED_LID_RING_TEMP_SENSOR  ].eeprom = &sensorData.eeprom[0];

    sensorData.sensors[AMBIENT_TEMP_SENSOR  ].eeprom = &sensorData.eeprom[1];
    sensorData.sensors[HEAT_SINK_TEMP_SENSOR].eeprom = &sensorData.eeprom[1];



    // Set SPI Address Register
    for(channel = 0; channel < BLOCK_TEMP_SENSOR_COUNT; channel++)
    {
        sensorData.sensors[channel].spiAddrReg =
            map->sensorChannelMap[channel].spiInterface == 0 ?
            &SPI_CONTROL.sensorAaddr : &SPI_CONTROL.sensorBaddr;
    }

    sensorData.sensors[HEATED_LID_CENTER_TEMP_SENSOR].spiAddrReg = &SPI_CONTROL.sensorAaddr;
    sensorData.sensors[HEATED_LID_RING_TEMP_SENSOR  ].spiAddrReg = &SPI_CONTROL.sensorAaddr;

    sensorData.sensors[AMBIENT_TEMP_SENSOR  ].spiAddrReg = &SPI_CONTROL.sensorBaddr;
    sensorData.sensors[HEAT_SINK_TEMP_SENSOR].spiAddrReg = &SPI_CONTROL.sensorBaddr;



    // Set SPI Addresses
    for(channel = 0; channel < BLOCK_TEMP_SENSOR_COUNT; channel++)
    {
        sensorData.sensors[channel].spiAddr = map->sensorChannelMap[channel].spiAddress;
    }

    sensorData.sensors[HEATED_LID_CENTER_TEMP_SENSOR].spiAddr = 12;
    sensorData.sensors[HEATED_LID_RING_TEMP_SENSOR  ].spiAddr = 13;

    sensorData.sensors[AMBIENT_TEMP_SENSOR    ].spiAddr = 12;
    sensorData.sensors[HEAT_SINK_TEMP_SENSOR  ].spiAddr = 13;



    // Set Drive Mapping
    setPwmMapping(type);
}



void storeCalibrationValue(uint8 sensor, bool high, float calPoint, int calIndex, uint16 calValue)
{
    uint16 eepromCalStart = high ? EEPROM_ADDR_SENSOR_HIGH_CALIBRATION_VALUES :
                                   EEPROM_ADDR_SENSOR_LOW_CALIBRATION_VALUES;
    uint16 eepromCalAddr  = eepromCalStart +
                            EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE*calIndex +
                            sensorData.sensors[sensor].spiAddr * sizeof(uint16);

    printf("  Storing sensor %d %s calibration %d value 0x%04x at %.3f C\n",
           sensor, high ? "high" : "low", calIndex, calValue, calPoint);

    writeEepromUint16(sensorData.sensors[sensor].eeprom, eepromCalAddr, calValue);
    writeEepromCRC(sensorData.sensors[sensor].eeprom, eepromCalStart,
                   EEPROM_SIZE_SENSOR_LOW_CALIBRATION_VALUES);

    setCalibrationPoint(sensor, high, calPoint, calIndex);
}




void getRawSensorCalibrationAverages(uint32 rawValueAverages[TEMP_SENSOR_COUNT])
{
    int sensorIndex;
    int iteration;
    
    for(sensorIndex = 0; sensorIndex < TEMP_SENSOR_COUNT; sensorIndex++)
    {
        rawValueAverages[sensorIndex] = 0;
    }

    for(iteration = 0; iteration < CALIBRATION_SAMPLE_COUNT; iteration++)
    {
        for(sensorIndex = 0; sensorIndex < TEMP_SENSOR_COUNT; ++sensorIndex)
        {
            rawValueAverages[sensorIndex] += readRawSensorReading(sensorIndex);
        }

        mdelay(CALIBRATION_SAMPLE_DELAY_ms);
    }

    for(sensorIndex = 0; sensorIndex < TEMP_SENSOR_COUNT; sensorIndex++)
    {
        rawValueAverages[sensorIndex] /= CALIBRATION_SAMPLE_COUNT;
    }
}



bool loadSensorCalibration()
{
    int  sensor;
    bool success;

    success = validateSensorCalibrationCRCs();

    for(sensor = 0; sensor < TEMP_SENSOR_COUNT; sensor++)
    {
        int calIndex;

        for(calIndex = 0; calIndex < TEMP_SENSOR_CALIBRATION_COUNT; calIndex++)
        {
            success &= loadOneSensorCalibration(sensor, calIndex);
        }
    }

    return success;
}



bool loadOneSensorCalibration(uint8 sensor, int calIndex)
{
    float  highCalPoint, lowCalPoint;
    uint16 sensorHighValue, sensorLowValue;
    bool   success = true;

    ASSERT(sensor < TEMP_SENSOR_COUNT);
    ASSERT( calIndex < TEMP_SENSOR_CALIBRATION_COUNT );

    success &= getCalibrationPoint(sensor, true,  calIndex, false, &highCalPoint);
    success &= getCalibrationPoint(sensor, false, calIndex, false, &lowCalPoint);

    success &= getSensorCalibration(sensor, true,  calIndex, false, &sensorHighValue);
    success &= getSensorCalibration(sensor, false, calIndex, false, &sensorLowValue);

    // Calculate Slope (m) and Offset (b) from calibration data

    sensorData.sensors[sensor].m[ calIndex ] =
        (highCalPoint - lowCalPoint) / (1.0 * (sensorHighValue - sensorLowValue));

    sensorData.sensors[sensor].b[ calIndex ] =
        lowCalPoint - sensorData.sensors[sensor].m[ calIndex ] * sensorLowValue;

    return success;
}



void configureAdc(SpiInterface* spiInterface)
{
    ASSERT(spiInterface);

    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    writeBuffer[0] = 0x10; // Select write to config register
    writeBuffer[1] = 0x15; //   Unipolar / Gain 32 (39.06mV)
    writeBuffer[2] = 0x10; //   BUF enabled

    writeBuffer[3] = 0x28; // Select write to IO register
    writeBuffer[4] = 0x02; //   Excitation Current: 0x02=210uA, 0x03=1mA

    writeBuffer[5] = 0x08; // Select write to mode register
    writeBuffer[6] = 0x20; //   Single Conversion
    writeBuffer[7] = 0x04; //   Update rate - 0x04 = 62Hz

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 8, TX_TIMEOUT_us);
    spiWaitForReady(spiInterface, RX_TIMEOUT_us);
}



void setModeContinuous(SpiInterface* spiInterface)
{
    ASSERT(spiInterface);

    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    writeBuffer[0] = 0x08; // write to mode register next
    writeBuffer[1] = 0x00;
    writeBuffer[2] = 0x04; // write to mode register - refresh rate - 0x04 = 62Hz
    writeBuffer[3] = 0x10; // write to config register next
    writeBuffer[4] = 0x15; // set gain: 0x10 through 0x17
    writeBuffer[5] = 0x10; // write to config register
    writeBuffer[6] = 0x28; // write to IO reg next
    writeBuffer[7] = 0x02; // write to IO reg: 0x02=210uA, 0x03=1mA

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 8, TX_TIMEOUT_us);
    spiWaitForReady(spiInterface, RX_TIMEOUT_us);
}


void zeroScaleCalibrate(SpiInterface* spiInterface)
{
    ASSERT(spiInterface);

    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    writeBuffer[0] = 0x08; //write to mode register next
    writeBuffer[1] = 0x40; //idle mode
    writeBuffer[2] = 0x03; //refresh rate
    writeBuffer[3] = 0x30; //write to offset register next
    writeBuffer[4] = ( uint8 )( ( adc_zero_scale >> 8 ) & 0x00FF );
    writeBuffer[5] = ( uint8 )( adc_zero_scale & 0x00FF );

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 6, TX_TIMEOUT_us);
    spiWaitForReady(spiInterface, RX_TIMEOUT_us);
}



void fullScaleCalibrate(SpiInterface* spiInterface)
{
    ASSERT(spiInterface);

    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    //write calibration register manually
    writeBuffer[0] = 0x08; //write to mode register next
    writeBuffer[1] = 0x40; //idle mode
    writeBuffer[2] = 0x03; //refresh rate
    writeBuffer[3] = 0x38; //write to full scale register next
    writeBuffer[4] = ( uint8 )( ( adc_full_scale >> 8 ) & 0x00FF );
    writeBuffer[5] = ( uint8 )( adc_full_scale & 0x00FF );

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 6, TX_TIMEOUT_us);
    spiWaitForReady(spiInterface, RX_TIMEOUT_us);
}


void writeFullScale(uint16 value)
{
    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    //write calibration register manually
    writeBuffer[0] = 0x08; //write to mode register next
    writeBuffer[1] = 0x40; //idle mode
    writeBuffer[2] = 0x03; //refresh rate
    writeBuffer[3] = 0x38; //write to full scale register next
    writeBuffer[4] = ( uint8 )( ( value >> 8 ) & 0x00FF );
    writeBuffer[5] = ( uint8 )( value & 0x00FF );

    int sensor;
    for(sensor = 0; sensor < TEMP_SENSOR_COUNT; sensor++)
    {
        selectSensor(sensor);
        spiWaitAndStartTransmit(sensorData.sensors[sensor].spiInterface, writeBuffer, 6, TX_TIMEOUT_us);
        spiWaitForReady(sensorData.sensors[sensor].spiInterface, RX_TIMEOUT_us);
        deselectSensors();
    }
}

void writeZeroScale(uint16 value)
{
    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    //write calibration register manually
    writeBuffer[0] = 0x08; //write to mode register next
    writeBuffer[1] = 0x40; //idle mode
    writeBuffer[2] = 0x03; //refresh rate
    writeBuffer[3] = 0x30; //write to offset register next
    writeBuffer[4] = ( uint8 )( ( value >> 8 ) & 0x00FF );
    writeBuffer[5] = ( uint8 )( value & 0x00FF );

    int sensor;
    for(sensor = 0; sensor < TEMP_SENSOR_COUNT; sensor++)
    {
        selectSensor(sensor);
        spiWaitAndStartTransmit(sensorData.sensors[sensor].spiInterface, writeBuffer, 6, TX_TIMEOUT_us);
        spiWaitForReady(sensorData.sensors[sensor].spiInterface, RX_TIMEOUT_us);
        deselectSensors();
    }
}


void resetADC(SpiInterface* spiInterface)
{
    ASSERT(spiInterface);

    uint8 writeBuffer[SENSOR_BUFFER_SIZE];

    writeBuffer[0] = 0xFF;
    writeBuffer[1] = 0xFF;
    writeBuffer[2] = 0xFF;
    writeBuffer[3] = 0xFF;

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 4, TX_TIMEOUT_us);
    spiWaitForReady(spiInterface, RX_TIMEOUT_us);

    mdelay(20);
}



void setAddress(volatile uint32* reg, uint32 addr)
{
    ASSERT(reg);
    *reg = ~addr;
}



void selectSensor(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);
    setAddress(sensorData.sensors[sensor].spiAddrReg, sensorData.sensors[sensor].spiAddr);
}



void deselectSensors()
{
    setAddress(&SPI_CONTROL.sensorAaddr, SPI_ADDRESS_OFF);
    setAddress(&SPI_CONTROL.sensorBaddr, SPI_ADDRESS_OFF);
}


uint8 getSensorStatus(uint8 sensor)
{
    ASSERT(sensor < TEMP_SENSOR_COUNT);

    uint8  writeBuffer[SENSOR_BUFFER_SIZE];
    uint8  readBuffer[SENSOR_BUFFER_SIZE];
    uint16 readCount;

    selectSensor(sensor);

    writeBuffer[0] = 0x40;
    writeBuffer[1] = 0x00; //read from Status Reg next

    if(spiWaitAndStartTransmit(sensorData.sensors[sensor].spiInterface, writeBuffer, 2, TX_TIMEOUT_us) != SPI_STATUS_TX_STARTED)  return 0; // SPI Write Error
    if(spiWaitAndReadData(sensorData.sensors[sensor].spiInterface, readBuffer, 2, &readCount, RX_TIMEOUT_us) != SPI_STATUS_RX_OK) return 0; // SPI Read Error
    if(readCount != 2) return 0; // SPI Read Error

    return readBuffer[1];
}



void getModeStatus(SpiInterface* spiInterface, uint8* buffer)
{
    ASSERT(spiInterface);
    ASSERT(buffer);

    uint8  writeBuffer[SENSOR_BUFFER_SIZE];
    uint16 readCount;

    writeBuffer[0] = 0x48; //read from Mode Register next
    writeBuffer[1] = 0x00;
    writeBuffer[2] = 0x00;

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 3, TX_TIMEOUT_us);
    spiWaitAndReadData(spiInterface, buffer, 3, &readCount, RX_TIMEOUT_us);
}



void getOffset(SpiInterface* spiInterface, uint8* buffer)
{
    ASSERT(spiInterface);
    ASSERT(buffer);

    uint8  writeBuffer[SENSOR_BUFFER_SIZE];
    uint16 readCount;

    writeBuffer[0] = 0x70; //read from Offset Register next
    writeBuffer[1] = 0x00;
    writeBuffer[2] = 0x00;

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 3, TX_TIMEOUT_us);
    spiWaitAndReadData(spiInterface, buffer, 3, &readCount, RX_TIMEOUT_us);
}



void getFullScale(SpiInterface* spiInterface, uint8* buffer)
{
    ASSERT(spiInterface);
    ASSERT(buffer);

    uint8  writeBuffer[SENSOR_BUFFER_SIZE];
    uint16 readCount;

    writeBuffer[0] = 0x78; //read from Offset Register next
    writeBuffer[1] = 0x00;
    writeBuffer[2] = 0x00;

    spiWaitAndStartTransmit(spiInterface, writeBuffer, 3, TX_TIMEOUT_us);
    spiWaitAndReadData(spiInterface, buffer, 3, &readCount, RX_TIMEOUT_us);
}




// EOF
