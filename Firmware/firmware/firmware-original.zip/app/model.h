//-----------------------------------------------------------------------------
//! \file
//!
//! \brief Temperature Model
//!
//! This file contains the interface to the temperature model module.
//!
//! Copyright (c) 2009 Idaho Technology Inc.
//-----------------------------------------------------------------------------

#include <types.h>

enum { MODEL_ORDER = 2 };

typedef struct
{
    double x[ MODEL_ORDER + 1 ];
    double y[ MODEL_ORDER + 1 ];
} ModelData_t;

typedef struct
{
    // Poles and Zero
    float w1;
    float w2;
    float w3;

    // Coefficients
    double a;
    double b;
    double c;
    double d;
    double e;
} ModelParams_t;

typedef struct
{
    ModelData_t data;
    ModelParams_t *heatingParams;
    ModelParams_t *coolingParams;
} Model_t;

typedef enum
{
    model_25uL,
    model_50uL,
    numModels
} ModelType;


void  modelInit( void );
void  modelDataInit( Model_t * model, ModelType type,
                     int channel, float temperature );
float modelTemp( Model_t * model, float currentTemp );
void  setModelParam( int channel, ModelType type, bool heating,
                     int paramIndex, float value, bool persist );
bool  getModelParam( int channel, ModelType type,
                     bool heating, int paramIndex, float *value );
void  clearModelParams( void );
