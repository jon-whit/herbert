/////////////////////////////////////////////////////////////
//
//  devices.h
//
//  Definitions of system devices and status for
//  initialization and self test
//
//  Copyright 2010 Idaho Technology
//  Created by Brett Gilbert

#ifndef devices_h
#define devices_h




typedef enum
{
    TestDevice_BlockThermal,
    TestDevice_HeatsinkThermal,
    TestDevice_HeatsinkFan,
    TestDevice_LidThermal,
    TestDevice_AmbientThermal,
    TestDevice_FilterWheelMotion,
    TestDevice_LidMotion,
    TestDevice_DoorMotion,
    TestDevice_IlluminationBlue,
    TestDevice_IlluminationGreen,
    TestDevice_IlluminationOrange,
    TestDevice_IlluminationRed,
    TestDevice_IlluminationCrimson,
} TestDevices;



const char* getTestDeviceName(TestDevices device);


#endif
