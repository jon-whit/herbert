/////////////////////////////////////////////////////////////
//
//  power.c
//
//  Driver for the power break-out relay board
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#include <power.h>
#include <systemController.h>
#include <os.h>
#include <timer.h>



///////////////////////////////////////////////////
// Constants

#define POWER_PWM_PERIOD_ms 200


///////////////////////////////////////////////////
// Local types and macros

#define PERIOD_TO_TICKS_ms(period)                 (MSEC_TO_TICKS((period)) - 1)




///////////////////////////////////////////////////
// Interface functions

void powerInit()
{
    turnOffAllPower();

    CONTROL_REGS.power.pwmDutyCycle = 0;
    CONTROL_REGS.power.pwmPeriod    = PERIOD_TO_TICKS_ms(POWER_PWM_PERIOD_ms);
}



void turnOnPower(PowerDevice device)
{
    CRData crdata = enterCriticalRegion();
    {
        CONTROL_REGS.power.output |= device;
    }
    exitCriticalRegion(crdata);
}



void turnOffPower(PowerDevice device)
{
    CRData crdata = enterCriticalRegion();
    {
        CONTROL_REGS.power.output &= ~device;
    }
    exitCriticalRegion(crdata);
}



void turnOffAllPower()
{
    setHeatedLidPwmDutyCycle(0);
    
    CRData crdata = enterCriticalRegion();
    {
        CONTROL_REGS.power.output = ~ALL_POWER;
    }
    exitCriticalRegion(crdata);
}



void setHeatedLidPwmDutyCycle(uint32 dutyCycle)
{
    CONTROL_REGS.power.pwmDutyCycle = PERIOD_TO_TICKS_ms(POWER_PWM_PERIOD_ms) / 1000 * dutyCycle; //dutyCycle is 1/10 percent
}


// EOF
