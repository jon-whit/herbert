/////////////////////////////////////////////////////////////
//
//  devices.c
//
//  Definitions of system devices and status for
//  initialization and self test
//
//  Copyright 2010 Idaho Technology
//  Created by Brett Gilbert


#include <types.h>
#include <devices.h>
#include <assert.h>



const char* getTestDeviceName(TestDevices device)
{
    switch(device)
    {
    case TestDevice_BlockThermal:        return "BlockThermal";
    case TestDevice_HeatsinkThermal:     return "HeatsinkThermal";
    case TestDevice_HeatsinkFan:         return "HeatsinkFan";
    case TestDevice_LidThermal:          return "LidThermal";
    case TestDevice_AmbientThermal:      return "AmbientThermal";
    case TestDevice_FilterWheelMotion:   return "FilterWheelMotion";
    case TestDevice_LidMotion:           return "LidMotion";
    case TestDevice_DoorMotion:          return "DoorMotion";
    case TestDevice_IlluminationBlue:    return "IlluminationBlue";
    case TestDevice_IlluminationGreen:   return "IlluminationGreen";
    case TestDevice_IlluminationOrange:  return "IlluminationOrange";
    case TestDevice_IlluminationRed:     return "IlluminationRed";
    case TestDevice_IlluminationCrimson: return "IlluminationCrimson";
    default: ASSERT(false); return NULL;
    }
}



// EOF
