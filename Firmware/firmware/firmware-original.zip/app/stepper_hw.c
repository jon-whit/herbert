//-----------------------------------------------------------------------------
//!\file
//!
//!\brief Implemntation of the Hardware-Dependent Stepper Motors Module
//!
//! This file contains the implementation of the hardware-dependent portion
//! of the stepper motors module.  The functions defined here are used by
//! the hardware-independent portion of the stepper motors module to
//! interface with the hardware.
//!
//! Copyright (c) 2009 Idaho Technology Inc.
//-----------------------------------------------------------------------------

#include <assert.h>
#include <interrupt.h>
#include <stepper_hw.h>
#include <xparameters.h>
#include <timer.h>
#include <stdio.h>


//------------------------------------------------------------------------------
// Motor Hardware Definitions

typedef struct
{
    // Control Register
    //  Read: (Reading clears interrupt)
    //    bit 0 - interrupt enable
    //    bit 1 - interrupt pending
    //  Write:
    //    bit 0 - interrupt enable
    volatile uint32 control;
    
    // Enable Register
    //  Read/Write:
    //    bit 0 - Door
    //    bit 1 - Filter
    //    bit 2 - Lid
    volatile uint32 enable;
    
    // Channel Select Register
    //  Read/Write:
    //    bit 0-1 - Select signals
    volatile uint32 channelSelect;
    
    // Sensors Register
    //  Read only:
    //    bit 0 - Closed
    //    bit 1 - Open
    volatile uint32 sensors;
    
    // Direction Register
    //  Read/Write:
    //    bit 0 - Direction signal
    volatile uint32 direction;
    
    // Period Register
    //  Read/Write: (Writing starts a step sequence and will interrupt processor when complete)
    //    32 bits - Step period in ticks
    volatile uint32 period;
    
    // Pulse Width Register
    //  Read/Write:
    //    32 bits - Step pulse width in ticks
    volatile uint32 pulseWidth;
} MotorRegs;

#define MOTOR_REGS (*((MotorRegs*)XPAR_MOTOR_BASEADDR))


#define PULSE_WIDTH_us   2
#define MIN_LOW_TIME_us  1


static void stepper_hw_isr(void *callbackRef);



enum Motor_Hardware
{
    interrupt_enable_mask = 0x01,
    interrupt_clear_mask  = 0x02,
    
    home_sensor_mask  = 0x02,
    alt_sensor_mask   = 0x01,

    min_stepper_frequency = 10,
};




//------------------------------------------------------------------------------
void stepper_init_hw(void(*step_callback)(void))
{
    ASSERT(step_callback);
    
    MOTOR_REGS.control       = interrupt_clear_mask;
    MOTOR_REGS.enable        = 0;
    MOTOR_REGS.channelSelect = 0;
    MOTOR_REGS.direction     = 0;
    MOTOR_REGS.pulseWidth    = USEC_TO_TICKS(PULSE_WIDTH_us);

    registerInterruptHandler(XPAR_INTC_MOTOR_INTERRUPT_INTR, stepper_hw_isr, step_callback);
    enableInterrupt(XPAR_INTC_MOTOR_INTERRUPT_INTR);
    
    MOTOR_REGS.control = interrupt_enable_mask | interrupt_clear_mask;
}



//------------------------------------------------------------------------------
void stepper_set_address_hw(uint32 select)
{
    MOTOR_REGS.channelSelect = select;
}



//------------------------------------------------------------------------------
void stepper_set_enable_hw(uint32 enable)
{
    MOTOR_REGS.enable |= enable;
}



//------------------------------------------------------------------------------
void stepper_clear_enable_hw(uint32 enable)
{
    MOTOR_REGS.enable &= ~enable;
}



//------------------------------------------------------------------------------
void stepper_start_step_hw(uint32 frequency)
{
    if(frequency < min_stepper_frequency )
    {
        frequency = min_stepper_frequency;
    }


    uint32 period = XPAR_MICROBLAZE_CORE_CLOCK_FREQ_HZ / frequency - 2;

    if(period < USEC_TO_TICKS(PULSE_WIDTH_us + MIN_LOW_TIME_us))
    {
        period = USEC_TO_TICKS(PULSE_WIDTH_us + MIN_LOW_TIME_us);
    }

    MOTOR_REGS.period = period;
}



//------------------------------------------------------------------------------
bool stepper_get_home_sensor_hw()
{
    return !!(MOTOR_REGS.sensors & home_sensor_mask);
}



//------------------------------------------------------------------------------
bool stepper_get_alt_sensor_hw()
{
    return !!(MOTOR_REGS.sensors & alt_sensor_mask);
}



//------------------------------------------------------------------------------
void stepper_clear_direction_hw()
{
    MOTOR_REGS.direction = 0;
}


//------------------------------------------------------------------------------
void stepper_set_direction_hw()
{
    MOTOR_REGS.direction = 1;
}


//------------------------------------------------------------------------------
static void stepper_hw_isr(void *callbackRef)
{
    // Clear interrupt
    MOTOR_REGS.control = interrupt_enable_mask | interrupt_clear_mask;

    if(callbackRef)
    {
        ((void(*)())callbackRef)();
    }
}

