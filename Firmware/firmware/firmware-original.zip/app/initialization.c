/////////////////////////////////////////////////////////////
//
//  initialization.c
//
//  System initialization
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#include <initialization.h>


#include <stdio.h>
#include <types.h>
#include <interrupt.h>
#include <led.h>
#include <pwm.h>
#include <lcd.h>
#include <timer.h>
#include <processor.h>
#include <assert.h>
#include <sensors.h>
#include <serial.h>
#include <comm.h>
#include <control.h>
#include <version.h>
#include <cache.h>
#include <illumination.h>
#include <model.h>
#include <AT45DB161D.h>
#include <motion.h>
#include <os.h>
#include <selfTest.h>
#include <system.h>
#include <ramp.h>



///////////////////////////////////////////////////
// Constants



///////////////////////////////////////////////////
// Local types and macros

typedef struct
{
    OfflineTaskCompleteCallback completedCallbackFunc;
    OfflineTaskInfoCallback     infoCallbackFunc;
    int                         reference;
} OperationCallback;



typedef enum
{
    MotionState_Idle,
    MotionState_FilterInit,
    MotionState_LidInit,
    MotionState_DoorInit,
    MotionState_Complete,
} MotionInitStates;


typedef struct
{
    MotionInitStates  state;
    ErrorCodes        error;
} MotionInit;



typedef struct
{
    MotionInit        motion;
    OperationCallback callback;
    bool              haltOnError;
} InitData;



///////////////////////////////////////////////////
// Local function prototypes

static bool startInitTask(void* unused);
static void sendTaskInfo(int reference, ErrorCodes error, const char* errorDesc);
static void finishInitTask(ErrorCodes error, const char* errorDesc);


static void motionInitStart();
static void motionInitProcess();
static void motionInitCallback(int reference, ErrorCodes error, const char* errorDesc);



///////////////////////////////////////////////////
// Local data

static InitData initData;



///////////////////////////////////////////////////
// Interface functions

void initializationInit()
{
    initData.callback.completedCallbackFunc = NULL;
    initData.callback.infoCallbackFunc      = NULL;
}



void resetSystemToDefaults()
{
    bool lidLowered = getLidPosition() == lid_lowered ? true : false;

    resetRampRate( ALL_BLOCK_CHANNELS );
    resetRampRate( ALL_LID_CHANNELS );
    resetRampParams();
    motionRestoreDefaults();
    toggleIlluminationControl( true );
    restoreIlluminationIntensity();
    setSampleVolume( 0 );
    toggleVarianceCheck( true );
    enableModel( false /*lidLowered*/ ); //@ddh Don't automatically enable the model.
    setCalibrationType( lidLowered ? CAL_TYPE_PCR_SAMPLE :
                                     CAL_TYPE_PCR_BLOCK );
}



void startSystemInitialization(OfflineTaskCompleteCallback completedCallbackFunc,
                               OfflineTaskInfoCallback     infoCallbackFunc,
                               int                         callbackRef,
                               bool                        haltOnError)
{
    ASSERT(completedCallbackFunc);

    if(initData.callback.completedCallbackFunc)
    {
        completedCallbackFunc(callbackRef, err_systemBusy, "Init system busy");
        return;
    }
    
    initData.callback.completedCallbackFunc = completedCallbackFunc;
    initData.callback.infoCallbackFunc      = infoCallbackFunc;
    initData.callback.reference             = callbackRef;
    initData.haltOnError                    = haltOnError;

    scheduleTask(startInitTask, NULL, false);
}



void startFilterInitialization(OfflineTaskCompleteCallback completedCallbackFunc, int callbackRef)
{
    printf("Filter init...\n");
    motionInitFilter(completedCallbackFunc, callbackRef);
}



void startLidInitialization(OfflineTaskCompleteCallback completedCallbackFunc, int callbackRef)
{
    printf("Lid init...\n");
    motionInitLid(completedCallbackFunc, callbackRef);
}



void startDoorInitialization(OfflineTaskCompleteCallback completedCallbackFunc, int callbackRef)
{
    printf("Door init...\n");
    motionInitDoor(completedCallbackFunc, callbackRef);
}



void initializationAbort()
{
    if(initData.callback.completedCallbackFunc)
    {
        initData.callback.completedCallbackFunc = NULL;
        initData.callback.infoCallbackFunc      = NULL;
        initData.motion.state                   = MotionState_Idle;

        printf("System Init Aborted\n");
    }
}





///////////////////////////////////////////////////
// Local functions

static bool startInitTask(void* unused)
{
    // Kick off all parallel initializations
    motionInitStart();



    return false;
}


static void sendTaskInfo(int reference, ErrorCodes error, const char* errorDesc)
{
    if(initData.callback.infoCallbackFunc)
    {
        initData.callback.infoCallbackFunc(reference, error, errorDesc);
    }
}


static void finishInitTask(ErrorCodes error, const char* errorDesc)
{
    if(initData.callback.completedCallbackFunc)
    {
        initData.callback.completedCallbackFunc(initData.callback.reference, error, errorDesc);
        initData.callback.completedCallbackFunc = NULL;
    }
}



///////////////////////////////////////////////////
// Motion Init Functions - Sequential Init Steps

static void motionInitStart()
{
    initData.motion.state = MotionState_FilterInit;
    initData.motion.error = err_noError;

    motionInitProcess();
}



static void motionInitProcess()
{
    switch(initData.motion.state)
    {
        case MotionState_Idle:
            break;

        case MotionState_FilterInit:
            printf("Filter init...\n");

            if(!motionInitFilter(motionInitCallback, TestDevice_FilterWheelMotion))
            {
                motionInitCallback(TestDevice_FilterWheelMotion, err_filterInitializationFailure, "Filter busy");
            }

            break;

        case MotionState_LidInit:
            printf("Lid init...\n");

            if(!motionInitLid(motionInitCallback, TestDevice_LidMotion))
            {
                motionInitCallback(TestDevice_LidMotion, err_lidInitializationFailure, "Lid busy");
            }

            break;

        case MotionState_DoorInit:
            printf("Door init...\n");

            if(!motionInitDoor(motionInitCallback, TestDevice_DoorMotion))
            {
                motionInitCallback(TestDevice_DoorMotion, err_doorInitializationFailure, "Door busy");
            }

            break;

        case MotionState_Complete:
            initData.motion.state = MotionState_Idle;
            finishInitTask(initData.motion.error, NULL);
            break;
            
        default:
            ASSERT(false);
    }
}



static void motionInitCallback(int reference, ErrorCodes error, const char* errorDesc)
{
    switch(initData.motion.state)
    {
        case MotionState_Idle:
            break;

        case MotionState_FilterInit:
            sendTaskInfo(TestDevice_FilterWheelMotion, error, errorDesc);

            if(error == err_noError)
            {
                printf("Filter done\n");
                initData.motion.state = MotionState_LidInit;
            }
            else
            {
                printf("Filter init error (%d) %s\n", error, errorDesc ? errorDesc : "");
                
                if(initData.haltOnError)
                {
                    finishInitTask(error, errorDesc);
                    initData.motion.state = MotionState_Idle;
                }
                else
                {
                    initData.motion.state = MotionState_LidInit;
                }

                initData.motion.error = err_filterInitializationFailure;
            }

            break;


        case MotionState_LidInit:
            sendTaskInfo(TestDevice_LidMotion, error, errorDesc);

            if(error == err_noError)
            {
                printf("Lid init done\n");
                initData.motion.state = MotionState_DoorInit;
            }
            else
            {
                printf("Lid init error (%d) %s\n", error, errorDesc ? errorDesc : "");

                if(initData.haltOnError)
                {
                    sendTaskInfo(TestDevice_DoorMotion, err_initializationSkipped, "Lid Failed - Can't Init Door");
                    finishInitTask(error, errorDesc);

                    initData.motion.state = MotionState_Idle;
                }
                else
                {
                    initData.motion.state = MotionState_DoorInit;
                }

                initData.motion.error = err_lidInitializationFailure;
            }

            break;

        case MotionState_DoorInit:
            sendTaskInfo(TestDevice_DoorMotion, error, errorDesc);

            if(error == err_noError)
            {
                printf("Door init done\n");
                initData.motion.state = MotionState_Complete;
            }
            else
            {
                printf("Door init error (%d) %s\n", error, errorDesc ? errorDesc : "");

                if(initData.haltOnError)
                {
                    finishInitTask(error, errorDesc);
                    initData.motion.state = MotionState_Idle;
                }
                else
                {
                    initData.motion.state = MotionState_DoorInit;
                }

                initData.motion.error = err_doorInitializationFailure;
            }

            break;

        case MotionState_Complete:
            break;
            
        default:
            ASSERT(false);
    }

    motionInitProcess();
}


// EOF
