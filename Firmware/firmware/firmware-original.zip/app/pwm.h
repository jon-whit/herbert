/////////////////////////////////////////////////////////////
//
//  pwm.h
//
//  Xilinx Spartan-3A FPGA Starter Kit LED Driver
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#ifndef pwm_h
#define pwm_h

#include <types.h>



#define PWM_BLOCK_CHANNEL_COUNT 24
#define PWM_LID_CHANNEL_COUNT   2
#define PWM_MIN_FREQUENCY       100
#define PWM_MAX_FREQUENCY       1000000

#define PWM_FIRST_BLOCK_CHANNEL 0
#define PWM_LAST_BLOCK_CHANNEL  (PWM_FIRST_BLOCK_CHANNEL + PWM_BLOCK_CHANNEL_COUNT - 1)

#define PWM_FIRST_LID_CHANNEL   PWM_BLOCK_CHANNEL_COUNT
#define PWM_LAST_LID_CHANNEL    (PWM_FIRST_LID_CHANNEL + PWM_LID_CHANNEL_COUNT - 1)


enum PwmMapTypes
{
    pwmMap_type0,
    pwmMap_type1,
    pwmMap_type2,
    pwmMap_type3,
    
    pwmMap_typeCount,
    
    pwmMap_default = pwmMap_type3,
};




void pwmInit();
bool pwmProcess(void* unused);

void setPwmMapping(unsigned mapType);

void pwmAbort();
void pwmReset();

void setPwmDutyCycle(int channel, int percentDutyCycle);

void setPwmFrequency(int frequency_hz);
int  getPwmFrequency();

uint32 getErrorStatus();


#endif
