//-----------------------------------------------------------------------------
//!\file
//!
//!\brief Stepper Motors Module Interface
//!
//! This file contains the interface to the stepper motors module.  The
//! stepper motors module controls the lid, door, and filter wheel stepper
//! motors of the PlateCycler.
//!
//! Copyright (c) 2009 Idaho Technology Inc.
//-----------------------------------------------------------------------------

#ifndef steppers_h
#define steppers_h

#include <limits.h>
#include <types.h>

//! Enumeration of the available steppers.
typedef enum { stepper_lid, stepper_door, stepper_filter, num_steppers } stepper_t;


enum stepper_constants
{
    stepper_home = INT_MAX, /*!< This value is reserved for home requests. */

    default_lid_fast_frequency    = 3000,
    default_lid_slow_frequency    = 800,
    default_lid_ramp_steps        = 260,

    default_door_fast_frequency   = 3000,
    default_door_slow_frequency   = 400,
    default_door_ramp_steps       = 300,

    default_filter_fast_frequency = 800,
    default_filter_slow_frequency = 100,
    default_filter_ramp_steps     = 40,
};



typedef enum
{
    stepper_fast_frequency,
    stepper_slow_frequency,
    stepper_ramp_steps,
    stepper_max_steps 
} stepper_parameter_t;




void stepper_init( void );
void stepper_abort( void );
bool stepper_move_to_position( stepper_t stepper, int position );
bool stepper_move_relative( stepper_t stepper, int steps );
bool stepper_enable( stepper_t stepper, bool enable );
bool stepper_busy_wait( uint32 ticks );
bool stepper_busy( void );
void stepper_reset_home_pin_location( void );
int  stepper_get_home_pin_location( stepper_t stepper );
bool stepper_set_parameter( stepper_t stepper, stepper_parameter_t param, int value );
void stepper_set_home_sensor_make_hook( stepper_t stepper, bool ( *hook_func )( int ) );
void stepper_set_home_sensor_break_hook( stepper_t stepper, bool ( *hook_func )( int ) );
void stepper_set_alt_sensor_make_hook( stepper_t stepper, bool ( *hook_func )( int ) );
void stepper_set_alt_sensor_break_hook( stepper_t stepper, bool ( *hook_func )( int ) );
bool stepper_is_at_home_position( stepper_t stepper );
bool stepper_is_at_alt_position( stepper_t stepper );
int  get_stepper_position( stepper_t stepper );


#endif //...#ifndef steppers_h
