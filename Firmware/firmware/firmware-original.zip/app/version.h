/////////////////////////////////////////////////////////////
//
//  version.h
//
//  Firmware Version defines
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#ifndef version_h
#define version_h


#define EXPECTED_FPGA_MAJOR_VER  2
#define EXPECTED_FPGA_MINOR_VER  2



#define FW_VER "0.51"


#endif
