/////////////////////////////////////////////////////////////
//
//  startup.h
//
//  System Startup
//
//  Copyright 2010 Idaho Technology
//  Created by Brett Gilbert

#ifndef startup_h
#define startup_h


void systemStartup();  // Never returns

void systemStart();
void systemStop();


#endif
