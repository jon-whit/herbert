/////////////////////////////////////////////////////////////
//
//  control.c
//
//  Plate Cycler control loop
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#include <control.h>
#include <timer.h>
#include <assert.h>
#include <sensors.h>
#include <lcd.h>
#include <fixedPoint.h>
#include <nvramMap.h>
#include <stdio.h>
#include <signal.h>
#include <power.h>
#include <stdlib.h>
#include <model.h>
#include <math.h>
#include <os.h>
#include <conversion.h>
#include <string.h>
#include <fan.h>
#include <flash.h>
#include <ramp.h>



///////////////////////////////////////////////////
// Constants

#define MAX_CONSECUTIVE_PROCESSING_OVERRUNS    3

#define DEFAULT_HEATBLOCK_RAMP_RATE            1.7
#define DEFAULT_HEATED_LID_RAMP_RATE           0.5
#define DEFAULT_TEMP                           20.0
#define DEFAULT_SAMPLE_VOLUME                  50
#define SDA_TRANSITION_RAMP_RATE_C_s           0.05

// Fan Parameters
#define FAN_PCR_DUTY_CYCLE                     500
#define FAN_SDA_DUTY_CYCLE                     500
#define FAN_PCR_TARGET_RPM                     3000
#define FAN_SDA_TARGET_RPM                     3000
#define FAN_OUT_OF_SPEED_TIME_s                10
#define FAN_STARTUP_TIME_s                     30
#define FAN_DUTY_CYLCE_DELTA                   10

// Ramp configuration
#define UP_RAMP_TICKS_TO_SETTLE                20
#define DOWN_RAMP_TICKS_TO_SETTLE              20
#define MAX_RAMP_DELTA                         5

#define USE_TEMP_AVERAGING                     1
#define TEMP_ACCUMULATOR_COUNT                 10

#define PWM_HISTORY_LENGTH                     5

#define NUM_INITIAL_SAMPLES                    3

#define TARGET_TEMP_DELTA                      0.009

#define MAX_TEMP_DIFFERENTIAL                  20

#define TARGET_THRESHOLD                       0.5

const float min_drive_temp                   = -20;
const float max_drive_temp                   = 180;

// SDA Ambient Compensation
#define SDA_AMBIENT_COMPENSATION_SCALE_LID     0.037
#define SDA_AMBIENT_COMPENSATION_OFFSET_LID    -1.03
#define SDA_AMBIENT_COMPENSATION_SCALE_NO_LID  0.078
#define SDA_AMBIENT_COMPENSATION_OFFSET_NO_LID -1.95

// Heatblock PID Settings and Gains
#define HEATBLOCK_CONTROL_PROCESS_PERIOD_ms    50

#define MARLOW
#ifdef MARLOW
#define HEATBLOCK_MAX_PID_PWM                  700
#define HEATBLOCK_MAX_SMOOTH_PID_PWM           700
#define HEATBLOCK_MIN_PID_PWM                  -400
#else
#define HEATBLOCK_MAX_PID_PWM                  750
#define HEATBLOCK_MAX_SMOOTH_PID_PWM           900
#define HEATBLOCK_MIN_PID_PWM                  -500
#endif


#define SAMPLE_MODEL_PID_PGAIN                 32.0
#define SAMPLE_MODEL_PID_IGAIN                 0.008
#define SAMPLE_MODEL_PID_DGAIN                 90000.0
#define SAMPLE_MODEL_PID_IMAX                  ( 100 / SAMPLE_MODEL_PID_IGAIN )
#define SAMPLE_MODEL_PID_IMIN                  ( -100 / SAMPLE_MODEL_PID_IGAIN )
#define SAMPLE_MODEL_PID_FGAIN                 1.0

#define HEATBLOCK_PID_PGAIN                    5.0
#define HEATBLOCK_PID_IGAIN                    0.005
#define HEATBLOCK_PID_DGAIN                    2000.0
#define HEATBLOCK_PID_FGAIN                    1.0
#define HEATBLOCK_PID_IMAX                     ( 100 / HEATBLOCK_PID_IGAIN )
#define HEATBLOCK_PID_IMIN                     ( -100 / HEATBLOCK_PID_IGAIN )
#define HEATBLOCK_INTEGRAL_THRESHOLD           10


// Feed forward term calibration values
#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_TEMP   22.5
#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_DRIVE  -50.0

#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_TEMP  31.0
#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_DRIVE -25.0

#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP   50.0
#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_DRIVE  26.0

#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_HIGH_TEMP  90.0
#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_HIGH_DRIVE 55.5

#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_TRANSITION SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_TEMP
#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_TRANSITION SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP

#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_SLOPE                        \
    ( ( SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_DRIVE - SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_DRIVE ) / \
      ( SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_TEMP - SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_TEMP ) )

#define SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_OFFSET                       \
    ( SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_DRIVE -                    \
      SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_SLOPE * SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_LOW_TEMP )

#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_SLOPE                        \
    ( ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_HIGH_DRIVE - SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_DRIVE ) / \
      ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_HIGH_TEMP - SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP ) )

#define SAMPLE_MODEL_POSITIVE_FEED_FORWARD_OFFSET                       \
    ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_DRIVE -                    \
      SAMPLE_MODEL_POSITIVE_FEED_FORWARD_SLOPE * SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP )

#define SAMPLE_MODEL_TRANSITION_FEED_FORWARD_SLOPE                      \
    ( ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_DRIVE - SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_DRIVE ) / \
      ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP - SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_HIGH_TEMP ) )

#define SAMPLE_MODEL_TRANSITION_FEED_FORWARD_OFFSET                     \
    ( SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_DRIVE -                    \
      SAMPLE_MODEL_TRANSITION_FEED_FORWARD_SLOPE * SAMPLE_MODEL_POSITIVE_FEED_FORWARD_LOW_TEMP )

#define HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_TEMP   4.0
#define HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_DRIVE  -50.0

#define HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_TEMP  12.5
#define HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_DRIVE -25.0

#define HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP   43.57
#define HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_DRIVE  25.0

#define HEATBLOCK_POSITIVE_FEED_FORWARD_HIGH_TEMP  78.28
#define HEATBLOCK_POSITIVE_FEED_FORWARD_HIGH_DRIVE 50.0

#define HEATBLOCK_NEGATIVE_FEED_FORWARD_TRANSITION HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_TEMP
#define HEATBLOCK_POSITIVE_FEED_FORWARD_TRANSITION HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP

#define HEATBLOCK_NEGATIVE_FEED_FORWARD_SLOPE                        \
    ( ( HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_DRIVE - HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_DRIVE ) / \
      ( HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_TEMP - HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_TEMP ) )

#define HEATBLOCK_NEGATIVE_FEED_FORWARD_OFFSET                       \
    ( HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_DRIVE -                    \
      HEATBLOCK_NEGATIVE_FEED_FORWARD_SLOPE * HEATBLOCK_NEGATIVE_FEED_FORWARD_LOW_TEMP )

#define HEATBLOCK_POSITIVE_FEED_FORWARD_SLOPE                        \
    ( ( HEATBLOCK_POSITIVE_FEED_FORWARD_HIGH_DRIVE - HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_DRIVE ) / \
      ( HEATBLOCK_POSITIVE_FEED_FORWARD_HIGH_TEMP - HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP ) )

#define HEATBLOCK_POSITIVE_FEED_FORWARD_OFFSET                       \
    ( HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_DRIVE -                    \
      HEATBLOCK_POSITIVE_FEED_FORWARD_SLOPE * HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP )

#define HEATBLOCK_TRANSITION_FEED_FORWARD_SLOPE                      \
    ( ( HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_DRIVE - HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_DRIVE ) / \
      ( HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP - HEATBLOCK_NEGATIVE_FEED_FORWARD_HIGH_TEMP ) )

#define HEATBLOCK_TRANSITION_FEED_FORWARD_OFFSET                     \
    ( HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_DRIVE -                    \
      HEATBLOCK_TRANSITION_FEED_FORWARD_SLOPE * HEATBLOCK_POSITIVE_FEED_FORWARD_LOW_TEMP )


// Heated Lid PID Settings and Gains
#define HEATED_LID_CONTROL_PROCESS_PERIOD_ms  50
#define HEATED_LID_MAX_PID_PWM                1000
#define HEATED_LID_MIN_PID_PWM                0
#define HEATED_LID_INTEGRAL_THRESHOLD         20

#define HEATED_LID_CENTER_PID_PGAIN           12
#define HEATED_LID_CENTER_PID_IGAIN           0.004
#define HEATED_LID_CENTER_PID_DGAIN           0.0
#define HEATED_LID_CENTER_PID_FGAIN           1.0
#define HEATED_LID_CENTER_PID_IMAX            ( HEATED_LID_MAX_PID_PWM / 10 / HEATED_LID_CENTER_PID_IGAIN )
#define HEATED_LID_CENTER_PID_IMIN            ( - HEATED_LID_CENTER_PID_IMAX )

#define HEATED_LID_CENTER_FEED_FORWARD_SLOPE  0.4049
#define HEATED_LID_CENTER_FEED_FORWARD_OFFSET -18.26
#define HEATED_LID_CENTER_FEED_FORWARD_CUTOFF 40.0

#define HEATED_LID_RING_PID_PGAIN             12
#define HEATED_LID_RING_PID_IGAIN             0.004
#define HEATED_LID_RING_PID_DGAIN             0.0
#define HEATED_LID_RING_PID_FGAIN             1.0
#define HEATED_LID_RING_PID_IMAX              ( HEATED_LID_MAX_PID_PWM / 10 / HEATED_LID_RING_PID_IGAIN )
#define HEATED_LID_RING_PID_IMIN              ( - HEATED_LID_RING_PID_IMAX )

#define HEATED_LID_RING_FEED_FORWARD_SLOPE    0.4049
#define HEATED_LID_RING_FEED_FORWARD_OFFSET   -18.26
#define HEATED_LID_RING_FEED_FORWARD_CUTOFF   40.0


///////////////////////////////////////////////////
// Local types and macros

typedef void ( *StateFunction )( void );

typedef enum
{
    BLOCK_CHANNEL,
    LID_CHANNEL
} ChannelType;

typedef enum
{
    IDLE,
    SMOOTH_RAMP,
    STARTING_SMOOTH_RAMP,
    STARTING_RAMP,
    RAMPING,
    SETTLING,
    STARTING_HOLD,
    HOLDING
} RampState;

typedef struct
{
    float slope;
    float offset;
} OnePieceLinearParams;

typedef struct
{
    OnePieceLinearParams positive;
    OnePieceLinearParams negative;
    OnePieceLinearParams transition;
    float                negativeTransition;
    float                positiveTransition;
} FeedForwardParams;

typedef struct
{
    float iGain;      // integral gain
    float pGain;      // proportional gain
    float dGain;      // derivative gain
    float fGain;      // forward gain
    float iMax, iMin; // Max and min allowable integration values
    FeedForwardParams ff;
} PidGains;

#define ERR_COUNT 3

typedef struct
{
    float  err[ERR_COUNT]; // temp errors of this thermocycler
    float  err_int;        // integral of the error
    float  err_deriv;      // derivative of the error

    int    integral_threshold; // threshold to enable integral term

    uint32 processingPeriod_ms;

    PidGains* gains;
} Pid;


typedef struct
{
    OfflineTaskCompleteCallback function;
    int                         reference;
} OperationCallback;


typedef struct
{
    int   size;
    float data[MAX_RAMP_SIZE];
} RampData;


typedef struct
{
    float       tempAccumulator;
    float       currentTemp;
    float       modeledTemp;
    float       targetTemp;
    int         currentPwm;
    int         maxPwm;
    int         minPwm;

    bool        tempControlOn;
    bool        bypassed;
    int         initialSamples;

    int         channelNumber;
    int         sensorNumber;
    int         pwmNumber;

    Pid         pid;

    Model_t     model;

    RampState   rampState;
    float       rampStartTemp;
    float       rampTargetTemp;
    float       rampRate;
    float       rampTime;
    int         settleTicks;
    float       upRampSettleDelta;
    float       downRampSettleDelta;
    float       belowAmbientDownRampSettleDelta;

    int         rampIndex;
    int         customRampIndex;
    RampData   *customRampPtr;
} ChannelData;


typedef struct
{
    ChannelData       blockChannel[BLOCK_CHANNEL_COUNT];
    ChannelData       lidChannel[LID_CHANNEL_COUNT];
    ChannelData       ambientChannel;
    ChannelData       heatSinkChannel;

    PidGains          sampleModelPidGains;
    PidGains          heatBlockPidGains;
    PidGains          heatedLidCenterPidGains;
    PidGains          heatedLidRingPidGains;

    ChannelData      *dispRaw;           //TODO: debug
    ChannelData      *dispChannel;       //TODO: debug
    int               pidMonitorChannel; //TODO: debug
    bool              streaming;         //TODO: debug

    bool              useModel;
    bool              reportModelTemp;
    calibrationType   calType;
    bool              checkChannelVariance;
    bool              rampEnabled;
    bool              smoothRampEnabled;
    bool              setLidTempPending;
    bool              setBlockTempPending;
    int               sampleVolume;
    int               overrunCount;
    bool              fanIsControllable;
    Timer             fanTimer;
    bool              transitioningCalibration;

    TimerCallBackInfo chainedCallBack;
    OperationCallback lidCallback;
    OperationCallback blockCallback;

    ChannelData      *currentChannel;
    ChannelData      *lastChannel;
    ChannelType       channelType;
    StateFunction     state;

    RampData          customRamp[NUM_CUSTOM_RAMPS];
    RampData          ramp;

    uint32            tempCycleCount;
    bool              currentlyHeating;
} ControlData;



///////////////////////////////////////////////////
// Local function prototypes

static bool  controlTask(void* unused);

static void  stateReadSensors( void );
static void  stateHeatControl( void );
static void  stateUpdateMisc( void );
static void  checkPendingCommand( ChannelData* channel, float currentTemp );
static void  checkChannelVariance( ChannelData* channel, float averageTemp );
static void  channelMonitor(void);

static float findNewTargetTemp(ChannelData* channel);
static int   tempPIDControl(ChannelData* channel);
static float findFeedForward(float targetTemp, FeedForwardParams* params);

static void  controlTimerCallback(void* unused);
static PidGains *gainTypeToGainPointer( gainType type );
static void updateTemp(ChannelData *channel, calibrationType calType, bool stream);
static ChannelData * channelNumberToChannelData(int channel,
                                                bool allowAllBlock,
                                                bool allowAllLid,
                                                bool allowSensors,
                                                int * numChannels);

static void enableChannelControl(ChannelData* channelData);
static char* addFloat3ParamToString(char* string, float value, bool delimit);
static void postControlFailure(bool blockError, ErrorCodes error, const char errorString[]);
static bool channelIsABlockChannel( ChannelData *channel );
static bool calTypeIsPCR( void );
static bool blockIsOff( void );
static bool blockDirectionIsHeating( float targetTemp );
static void checkFan( void );
static void rampGenCompleteCallback( int channel, bool status );
static bool setupSmoothRamp(int channel, float targetTemp,
                            OfflineTaskCompleteCallback callbackFunc,
                            int callbackRef);
static void startSDACalibrationTransition( void );
static void transitionCalibrationCallback(int intSavedRampRate, ErrorCodes error,
                                          const char* errorDesc);
static void postRampFailure( ChannelData* channel, float currentTemp );


///////////////////////////////////////////////////
// Local data

static ControlData control;



///////////////////////////////////////////////////
// Interface functions

void controlInit()
{
    // Debug controls
    control.dispRaw           = NULL;
    control.dispChannel       = NULL;
    control.pidMonitorChannel = -1;
    control.streaming         = false;

    // Sample Model Gains
    control.sampleModelPidGains.iMax                  = SAMPLE_MODEL_PID_IMAX;
    control.sampleModelPidGains.iMin                  = SAMPLE_MODEL_PID_IMIN;
    control.sampleModelPidGains.pGain                 = SAMPLE_MODEL_PID_PGAIN;
    control.sampleModelPidGains.iGain                 = SAMPLE_MODEL_PID_IGAIN;
    control.sampleModelPidGains.dGain                 = SAMPLE_MODEL_PID_DGAIN;
    control.sampleModelPidGains.fGain                 = SAMPLE_MODEL_PID_FGAIN;
    control.sampleModelPidGains.ff.negative.slope     = SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_SLOPE;
    control.sampleModelPidGains.ff.negative.offset    = SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_OFFSET;
    control.sampleModelPidGains.ff.positive.slope     = SAMPLE_MODEL_POSITIVE_FEED_FORWARD_SLOPE;
    control.sampleModelPidGains.ff.positive.offset    = SAMPLE_MODEL_POSITIVE_FEED_FORWARD_OFFSET;
    control.sampleModelPidGains.ff.transition.slope   = SAMPLE_MODEL_TRANSITION_FEED_FORWARD_SLOPE;
    control.sampleModelPidGains.ff.transition.offset  = SAMPLE_MODEL_TRANSITION_FEED_FORWARD_OFFSET;
    control.sampleModelPidGains.ff.negativeTransition = SAMPLE_MODEL_NEGATIVE_FEED_FORWARD_TRANSITION;
    control.sampleModelPidGains.ff.positiveTransition = SAMPLE_MODEL_POSITIVE_FEED_FORWARD_TRANSITION;


    // Heatblock Gains
    control.heatBlockPidGains.iMax                    = HEATBLOCK_PID_IMAX;
    control.heatBlockPidGains.iMin                    = HEATBLOCK_PID_IMIN;
    control.heatBlockPidGains.pGain                   = HEATBLOCK_PID_PGAIN;
    control.heatBlockPidGains.iGain                   = HEATBLOCK_PID_IGAIN;
    control.heatBlockPidGains.dGain                   = HEATBLOCK_PID_DGAIN;
    control.heatBlockPidGains.fGain                   = HEATBLOCK_PID_FGAIN;
    control.heatBlockPidGains.ff.negative.slope       = HEATBLOCK_NEGATIVE_FEED_FORWARD_SLOPE;
    control.heatBlockPidGains.ff.negative.offset      = HEATBLOCK_NEGATIVE_FEED_FORWARD_OFFSET;
    control.heatBlockPidGains.ff.positive.slope       = HEATBLOCK_POSITIVE_FEED_FORWARD_SLOPE;
    control.heatBlockPidGains.ff.positive.offset      = HEATBLOCK_POSITIVE_FEED_FORWARD_OFFSET;
    control.heatBlockPidGains.ff.transition.slope     = HEATBLOCK_TRANSITION_FEED_FORWARD_SLOPE;
    control.heatBlockPidGains.ff.transition.offset    = HEATBLOCK_TRANSITION_FEED_FORWARD_OFFSET;
    control.heatBlockPidGains.ff.negativeTransition   = HEATBLOCK_NEGATIVE_FEED_FORWARD_TRANSITION;
    control.heatBlockPidGains.ff.positiveTransition   = HEATBLOCK_POSITIVE_FEED_FORWARD_TRANSITION;


    // Heated Lid Gains
    control.heatedLidCenterPidGains.iMax                  = HEATED_LID_CENTER_PID_IMAX;
    control.heatedLidCenterPidGains.iMin                  = HEATED_LID_CENTER_PID_IMIN;
    control.heatedLidCenterPidGains.pGain                 = HEATED_LID_CENTER_PID_PGAIN;
    control.heatedLidCenterPidGains.iGain                 = HEATED_LID_CENTER_PID_IGAIN;
    control.heatedLidCenterPidGains.dGain                 = HEATED_LID_CENTER_PID_DGAIN;
    control.heatedLidCenterPidGains.fGain                 = HEATED_LID_CENTER_PID_FGAIN;
    control.heatedLidCenterPidGains.ff.negative.slope     = 0.0;
    control.heatedLidCenterPidGains.ff.negative.offset    = 0.0;
    control.heatedLidCenterPidGains.ff.positive.slope     = HEATED_LID_CENTER_FEED_FORWARD_SLOPE;
    control.heatedLidCenterPidGains.ff.positive.offset    = HEATED_LID_CENTER_FEED_FORWARD_OFFSET;
    control.heatedLidCenterPidGains.ff.transition.slope   = HEATED_LID_CENTER_FEED_FORWARD_SLOPE;
    control.heatedLidCenterPidGains.ff.transition.offset  = HEATED_LID_CENTER_FEED_FORWARD_OFFSET;
    control.heatedLidCenterPidGains.ff.negativeTransition = HEATED_LID_CENTER_FEED_FORWARD_CUTOFF;
    control.heatedLidCenterPidGains.ff.positiveTransition = HEATED_LID_CENTER_FEED_FORWARD_CUTOFF;

    control.heatedLidRingPidGains.iMax                    = HEATED_LID_RING_PID_IMAX;
    control.heatedLidRingPidGains.iMin                    = HEATED_LID_RING_PID_IMIN;
    control.heatedLidRingPidGains.pGain                   = HEATED_LID_RING_PID_PGAIN;
    control.heatedLidRingPidGains.iGain                   = HEATED_LID_RING_PID_IGAIN;
    control.heatedLidRingPidGains.dGain                   = HEATED_LID_RING_PID_DGAIN;
    control.heatedLidRingPidGains.fGain                   = HEATED_LID_RING_PID_FGAIN;
    control.heatedLidRingPidGains.ff.negative.slope       = 0.0;
    control.heatedLidRingPidGains.ff.negative.offset      = 0.0;
    control.heatedLidRingPidGains.ff.positive.slope       = HEATED_LID_RING_FEED_FORWARD_SLOPE;
    control.heatedLidRingPidGains.ff.positive.offset      = HEATED_LID_RING_FEED_FORWARD_OFFSET;
    control.heatedLidRingPidGains.ff.transition.slope     = HEATED_LID_RING_FEED_FORWARD_SLOPE;
    control.heatedLidRingPidGains.ff.transition.offset    = HEATED_LID_RING_FEED_FORWARD_OFFSET;
    control.heatedLidRingPidGains.ff.negativeTransition   = HEATED_LID_RING_FEED_FORWARD_CUTOFF;
    control.heatedLidRingPidGains.ff.positiveTransition   = HEATED_LID_RING_FEED_FORWARD_CUTOFF;


    // Heat Block Control
    float defaultRampRate = getDefaultRampRate();

    int index;

    for(index = 0; index < BLOCK_CHANNEL_COUNT; index++)
    {
        control.blockChannel[index].channelNumber           = FIRST_BLOCK_CHANNEL + index;
        control.blockChannel[index].sensorNumber            = FIRST_BLOCK_TEMP_SENSOR + index;
        control.blockChannel[index].pwmNumber               = PWM_FIRST_BLOCK_CHANNEL + index;

        control.blockChannel[index].currentTemp             = DEFAULT_TEMP;
        control.blockChannel[index].targetTemp              = DEFAULT_TEMP;

        control.blockChannel[index].rampState               = IDLE;
        control.blockChannel[index].rampRate                = defaultRampRate;
        control.blockChannel[index].rampTargetTemp          = DEFAULT_TEMP;
        control.blockChannel[index].upRampSettleDelta       = defaultRampRate;
        control.blockChannel[index].downRampSettleDelta     = defaultRampRate;
        control.blockChannel[index].belowAmbientDownRampSettleDelta = 1.0;

        control.blockChannel[index].tempControlOn           = false;
        control.blockChannel[index].bypassed                = false;
        control.blockChannel[index].initialSamples          = NUM_INITIAL_SAMPLES;
        control.blockChannel[index].currentPwm              = 0;
        control.blockChannel[index].maxPwm                  = HEATBLOCK_MAX_PID_PWM;
        control.blockChannel[index].minPwm                  = HEATBLOCK_MIN_PID_PWM;

        control.blockChannel[index].pid.err_int             = 0.0;
        control.blockChannel[index].pid.err_deriv           = 0.0;

        control.blockChannel[index].pid.gains               = &control.heatBlockPidGains;
        control.blockChannel[index].pid.integral_threshold  = HEATBLOCK_INTEGRAL_THRESHOLD;
        control.blockChannel[index].pid.processingPeriod_ms = HEATBLOCK_CONTROL_PROCESS_PERIOD_ms;

        control.blockChannel[index].customRampIndex         = 0;
        control.blockChannel[index].customRampPtr           = NULL;

        modelDataInit( &control.blockChannel[index].model, model_50uL, index, DEFAULT_TEMP );
    }


    // Heated Lid Control
    for(index = 0; index < LID_CHANNEL_COUNT; index++)
    {
        control.lidChannel[index].channelNumber           = FIRST_LID_CHANNEL + index;
        control.lidChannel[index].sensorNumber            = FIRST_HEATED_LID_TEMP_SENSOR + index;
        control.lidChannel[index].pwmNumber               = PWM_FIRST_LID_CHANNEL + index;

        control.lidChannel[index].currentTemp             = DEFAULT_TEMP;
        control.lidChannel[index].targetTemp              = DEFAULT_TEMP;

        control.lidChannel[index].rampState               = IDLE;
        control.lidChannel[index].rampRate                = DEFAULT_HEATED_LID_RAMP_RATE;
        control.lidChannel[index].rampTargetTemp          = DEFAULT_TEMP;
        control.lidChannel[index].upRampSettleDelta       = DEFAULT_HEATED_LID_RAMP_RATE;
        control.lidChannel[index].downRampSettleDelta     = DEFAULT_HEATED_LID_RAMP_RATE;
        control.lidChannel[index].belowAmbientDownRampSettleDelta = 1.0;

        control.lidChannel[index].tempControlOn           = false;
        control.lidChannel[index].bypassed                = false;
        control.lidChannel[index].initialSamples          = NUM_INITIAL_SAMPLES;
        control.lidChannel[index].currentPwm              = 0;
        control.lidChannel[index].maxPwm                  = HEATED_LID_MAX_PID_PWM;
        control.lidChannel[index].minPwm                  = HEATED_LID_MIN_PID_PWM;

        control.lidChannel[index].pid.err_int             = 0.0;
        control.lidChannel[index].pid.err_deriv           = 0.0;

        control.lidChannel[index].pid.integral_threshold  = HEATED_LID_INTEGRAL_THRESHOLD;
        control.lidChannel[index].pid.processingPeriod_ms = HEATED_LID_CONTROL_PROCESS_PERIOD_ms;

        control.lidChannel[index].customRampIndex         = 0;
        control.lidChannel[index].customRampPtr           = NULL;
    }

    control.lidChannel[LIDCENTER_CHANNEL-FIRST_LID_CHANNEL].pid.gains = &control.heatedLidCenterPidGains;
    control.lidChannel[  LIDRING_CHANNEL-FIRST_LID_CHANNEL].pid.gains = &control.heatedLidRingPidGains;

    // Sensor-only channels
    control.ambientChannel.channelNumber  = AMBIENT_CHANNEL;
    control.ambientChannel.sensorNumber   = AMBIENT_TEMP_SENSOR;
    control.ambientChannel.pwmNumber      = INVALID_PWM_CHANNEL;
    control.ambientChannel.currentTemp    = DEFAULT_TEMP;

    control.heatSinkChannel.channelNumber = HEAT_SINK_CHANNEL;
    control.heatSinkChannel.sensorNumber  = HEAT_SINK_TEMP_SENSOR;
    control.heatSinkChannel.pwmNumber     = INVALID_PWM_CHANNEL;
    control.heatSinkChannel.currentTemp   = DEFAULT_TEMP;


    // Set the default control mode and temperature to report.
    control.useModel             = false;
    control.calType              = CAL_TYPE_PCR_BLOCK;
    control.reportModelTemp      = 1;
    control.checkChannelVariance = true;
    control.rampEnabled          = true;
    control.smoothRampEnabled    = true;
    control.setLidTempPending    = false;
    control.setBlockTempPending  = false;
    control.sampleVolume         = DEFAULT_SAMPLE_VOLUME;
    control.overrunCount         = 0;
    control.state                = NULL;
    control.fanIsControllable    = fanIsControllable();
    control.ramp.size            = 0;
    control.transitioningCalibration = false;
    control.tempCycleCount       = 0;
    control.currentlyHeating     = false;

    // Custom Ramp initialization
    for(index = 0; index < NUM_CUSTOM_RAMPS; index++)
    {
        control.customRamp[index].size = 0;
    }
}



void controlStart()
{
    // Start timer
    enablePeriodicTimer(controlTimerCallback, NULL,
                        MSEC_TO_TICKS(HEATBLOCK_CONTROL_PROCESS_PERIOD_ms),
                        &control.chainedCallBack);
}


void controlStop()
{
    disablePeriodicTimer();
}



uint32 getBlockCycleCount()
{
    return control.tempCycleCount + sensorsNVReadBlockCycleCount();
}



bool setTargetTemp(int channel, float targetTemp,
                   OfflineTaskCompleteCallback callbackFunc, int callbackRef)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, false, &numChannels);
    ChannelData * endChannelData = &channelData[numChannels];
    ChannelData * channelPtr;

    ASSERT(numChannels); // Bad channel number

    // Check sensors
    for( channelPtr = channelData; channelPtr < endChannelData; ++channelPtr )
    {
        if( !channelPtr->bypassed && 
            ( channelPtr->currentTemp > max_drive_temp ||
              channelPtr->currentTemp < min_drive_temp ) )
        {
            if( callbackFunc )
            {
                callbackFunc( callbackRef,
                              channelIsABlockChannel( channelPtr ) ?
                              err_blockSensorFailure : err_lidSensorFailure,
                              NULL );
            }
            return false;
        }
    }

    if( channel == ALL_LID_CHANNELS  ||
        channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL )
    {
        if( control.setLidTempPending )
        {
            if( callbackFunc )
            {
                callbackFunc( callbackRef, err_systemBusy, NULL );
            }
            return false;
        }

        control.setLidTempPending     = true;
        control.lidCallback.function  = callbackFunc;
        control.lidCallback.reference = callbackRef;
        puts( "Set Target Temp starting" );
    }
    else
    {
        if( control.setBlockTempPending )
        {
            if( callbackFunc )
            {
                callbackFunc( callbackRef,
                              control.transitioningCalibration ?
                              err_transitioningCalibration : err_systemBusy,
                              NULL );
            }
            return false;
        }

        control.setBlockTempPending     = true;
        control.blockCallback.function  = callbackFunc;
        control.blockCallback.reference = callbackRef;
        puts( "Set Target Temp starting" );

        if( !blockDirectionIsHeating( targetTemp ) )
        {
            control.currentlyHeating = false;
        }
        else if( !control.currentlyHeating )
        {
            ++control.tempCycleCount;
            control.currentlyHeating = true;
        }

        if( control.smoothRampEnabled )
        {
            if( setupSmoothRamp( channel, targetTemp, callbackFunc, callbackRef ) )
            {
                return true;
            }
        }
    }

    for( ; numChannels; --numChannels )
    {
        if( !channelData->tempControlOn ||
            fabs( channelData->rampTargetTemp - targetTemp ) > TARGET_TEMP_DELTA )
        {
            // Start ramping from our current target (or current temperature
            // if not controlling the temperature).
            channelData->rampStartTemp =
                channelData->tempControlOn ? channelData->targetTemp :
                control.useModel ? channelData->modeledTemp : channelData->currentTemp;

            channelData->rampTargetTemp = channelData->targetTemp = targetTemp;
            enableChannelControl(channelData);
            channelData->initialSamples = NUM_INITIAL_SAMPLES;
            channelData->rampState      = STARTING_RAMP;
        }
        else if( control.rampEnabled &&
                 channelData->rampState == HOLDING )
        {
            if( channel == ALL_LID_CHANNELS  ||
                channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL )
            {
                control.setLidTempPending   = false;
            }
            else
            {
                control.setBlockTempPending = false;
            }
            if( callbackFunc )
            {
                callbackFunc( callbackRef, err_noError, NULL);
                puts( "Set Target Temp finished" );
            }
        }

        ++channelData;
    }

    return true;
}



float getTargetTemp(int channel)
{
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, false, NULL);

    if( channelData )
    {
        return channelData->rampTargetTemp;
    }

    ASSERT(false); // Bad channel number
    return 0;
}



float getCurrentTemp(int channel)
{
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, true, NULL);

    if( channelData )
    {
        if( control.reportModelTemp && control.useModel &&
            ( channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL ) )
        {
            return channelData->modeledTemp;
        }
        return channelData->currentTemp;
    }

    ASSERT(false); // Bad channel number
    return 0;
}



uint16 getRawReading(int channel)
{
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, true, NULL);

    if( channelData )
    {
        return readRawSensorReading( channelData->sensorNumber );
    }

    ASSERT(false); // Bad channel number
    return 0;
}



int getPwm(int channel, pwmType type)
{
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, true, NULL);

    if( channelData )
    {
        switch( type )
        {
        case pwmCurrent:
            return channelData->currentPwm;
        case pwmMax:
            return channelData->maxPwm;
        case pwmMin:
            return channelData->minPwm;
        default:
            ASSERT( 0 );
        }
    }

    ASSERT(false); // Bad channel number
    return 0;
}



void setRampRate(int channel, float rampRate)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, false, &numChannels);

    ASSERT(numChannels); // Bad channel number

    for( ; numChannels; --numChannels )
    {
        channelData->upRampSettleDelta               = rampRate;
        channelData->downRampSettleDelta             = rampRate;
        channelData->belowAmbientDownRampSettleDelta = rampRate > 1.0 ? 1.0 :
                                                                        rampRate;
        channelData++->rampRate                      = rampRate;
    }
}



void resetRampRate(int channel)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, false, &numChannels);

    ASSERT(numChannels); // Bad channel number

    float blockRampRate = getDefaultRampRate();

    for( ; numChannels; --numChannels )
    {
        float rampRate =
            channelIsABlockChannel( channelData ) ? blockRampRate :
                                                    DEFAULT_HEATED_LID_RAMP_RATE;

        setRampRate(channel, rampRate);
    }
}




float getRampRate(int channel)
{
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, false, NULL);

    if( channelData )
    {
        return fabs(channelData->rampRate);
    }

    ASSERT(false); // Bad channel number
    return 0;
}



void setDefaultRampRate(float rampRate)
{
    uint32 value;
    memcpy(&value, &rampRate, 4);
    nvramWrite(NVRAM_ADDR_DEFAULT_RAMP_RATE, (uint8*)&value, sizeof(value));
}



float getDefaultRampRate()
{
    uint32 value;

    if(nvramRead(NVRAM_ADDR_DEFAULT_RAMP_RATE, (uint8*)&value, sizeof(value)) &&
       value != 0xffffffff)
    {
        float rampRate;

        memcpy(&rampRate, &value, sizeof(value));

        if(rampRate >= MIN_RAMP_RATE_C_s && rampRate <= MAX_RAMP_RATE_C_s)
        {
            return rampRate;
        }
    }

    return DEFAULT_HEATBLOCK_RAMP_RATE;
}



void resetDefaultRampRate()
{
    setDefaultRampRate(DEFAULT_HEATBLOCK_RAMP_RATE);
}



void resetTempControl(int channel)
{
    bool savedRampRateIsValid = false;
    int  numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, true, &numChannels);

    ASSERT(numChannels); // Bad channel number

    if( control.setBlockTempPending                          &&
        control.transitioningCalibration                     &&
        control.blockCallback.function                       &&
        control.blockCallback.reference <= MAX_RAMP_RATE_C_s &&
        control.blockCallback.reference >= MIN_RAMP_RATE_C_s )
    {
        savedRampRateIsValid = true;
    }
        
    if( channel == ALL_LID_CHANNELS  ||
        channel == LIDCENTER_CHANNEL || channel == LIDRING_CHANNEL )
    {
        control.setLidTempPending   = false;
    }
    else
    {
        control.setBlockTempPending = false;
        control.currentlyHeating    = false;
    }

    for( ; numChannels; --numChannels )
    {
        channelData->tempControlOn  = false;
        channelData->rampState      = IDLE;
        channelData->currentPwm     = 0;
        channelData->targetTemp     = DEFAULT_TEMP;
        channelData->rampTargetTemp = DEFAULT_TEMP;
        channelData->customRampPtr  = NULL;

        if( channelIsABlockChannel( channelData ) )
        {
            channelData->maxPwm = HEATBLOCK_MAX_PID_PWM;
            if( savedRampRateIsValid )
            {
                channelData->rampRate = control.blockCallback.reference;
            }
        }

        setPwmDutyCycle(channelData->pwmNumber, 0);
        ++channelData;
    }

    control.transitioningCalibration = false;

    if( blockIsOff() )
    {
        setFanDutyCycle( FAN_BLOCK, 0 );

        if( control.tempCycleCount )
        {
            sensorsNVUpdateBlockCycleCount( control.tempCycleCount );
            control.tempCycleCount = 0;
        }
    }
}



void setWatchRaw(int channel)
{
    control.dispRaw =
        channelNumberToChannelData(channel, false, false, true, NULL);
}



void setWatchChannel(int channel)
{
    control.dispChannel =
        channelNumberToChannelData(channel, false, false, true, NULL);
}



void setPidMonitorChannel(int channel)
{
    if((channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL) ||
       (channel >= FIRST_LID_CHANNEL && channel <= LAST_LID_CHANNEL))
    {
        int numChannels;
        ChannelData * channelData =
            channelNumberToChannelData(channel, true, true, true, &numChannels);

        printf("\n\nBegin monitoring channel %d PID\n", channel);
        printf("Gains:\t%f\t%f\t%f\n",
               channelData->pid.gains->pGain,
               channelData->pid.gains->iGain,
               channelData->pid.gains->dGain);
        printf("target,\tsample,\tsensor,\terror,\tinteg,\tderiv,\tfforward,\tu\n");
    }

    control.pidMonitorChannel = channel;
}



void enableChannel(int channel)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, true, &numChannels);

    ASSERT(numChannels); // Bad channel number

    for( ; numChannels; --numChannels )
    {
        enableChannelControl(channelData);
        ++channelData;
    }
}



void enablePwmControl(int channel, int dutyCycle_tenthPercent)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, true, true, &numChannels);

    ASSERT(numChannels); // Bad channel number

    if( channelIsABlockChannel( channelData ) )
    {
        startTimer( &control.fanTimer, SEC_TO_TICKS( FAN_STARTUP_TIME_s  ) );
        setFanDutyCycle( FAN_BLOCK, FAN_PCR_DUTY_CYCLE );
    }

    for( ; numChannels; --numChannels )
    {
        channelData->tempControlOn = false;
        setPwmDutyCycle(channelData->pwmNumber, dutyCycle_tenthPercent);
        ++channelData;
    }
}



void disableChannel(int channel)
{
    resetTempControl(channel);
}



void setPGain(gainType type, float pGain)
{
    gainTypeToGainPointer( type )->pGain = pGain;
}



void setIGain(gainType type, float iGain)
{
    gainTypeToGainPointer( type )->iGain = iGain;
    gainTypeToGainPointer( type )->iMax = 100 / iGain;
    gainTypeToGainPointer( type )->iMin = -100 / iGain;
}



void setIMax(gainType type, float iMax)
{
    gainTypeToGainPointer( type )->iMax = iMax;
}



void setIMin(gainType type, float iMin)
{
    gainTypeToGainPointer( type )->iMin = iMin;
}


void setDGain(gainType type, float dGain)
{
    gainTypeToGainPointer( type )->dGain = dGain;
}



void setFGain(gainType type, float fGain)
{
    gainTypeToGainPointer( type )->fGain = fGain;
}



float getPGain(gainType type)
{
    return gainTypeToGainPointer( type )->pGain;
}



float getIGain(gainType type)
{
    return gainTypeToGainPointer( type )->iGain;
}



float getIMax(gainType type)
{
    return gainTypeToGainPointer( type )->iMax;
}



float getIMin(gainType type)
{
    return gainTypeToGainPointer( type )->iMin;
}



float getDGain(gainType type)
{
    return gainTypeToGainPointer( type )->dGain;
}



float getFGain(gainType type)
{
    return gainTypeToGainPointer( type )->fGain;
}


void setReportModelTemp( bool enable )
{
    control.reportModelTemp = enable;
}


void enableModel( bool enable )
{
    int       index;
    PidGains* gains = enable ? &control.sampleModelPidGains :
                               &control.heatBlockPidGains;

    control.useModel = enable;

    for(index = 0; index < BLOCK_CHANNEL_COUNT; index++)
    {
        control.blockChannel[index].pid.gains = gains;
    }
}


void setCalibrationType( calibrationType calType )
{
    switch( calType )
    {
    case CAL_TYPE_PCR_SAMPLE:
    case CAL_TYPE_PCR_BLOCK:
    case CAL_TYPE_SDA_SAMPLE:
    case CAL_TYPE_SDA_BLOCK:
        control.calType = calType;
        break;
    default:
        ASSERT( 0 );
    }
}

calibrationType getCalibrationType( void )
{
    return control.calType;
}

void transitionCalibration( bool lidIsLowered )
{
    switch( control.calType )
    {
    case CAL_TYPE_PCR_BLOCK:
    case CAL_TYPE_PCR_SAMPLE:
        control.calType = lidIsLowered ? CAL_TYPE_PCR_SAMPLE : CAL_TYPE_PCR_BLOCK;
        break;
    case CAL_TYPE_SDA_BLOCK:
        if( lidIsLowered )
        {
            control.calType = CAL_TYPE_SDA_SAMPLE;
            startSDACalibrationTransition();
        }
        break;
    case CAL_TYPE_SDA_SAMPLE:
        control.calType = lidIsLowered ? CAL_TYPE_SDA_SAMPLE : CAL_TYPE_SDA_BLOCK;
        break;
    default:
        ASSERT( 0 );
    }

    //@ddh Don't automatically enable the model.
    //enableModel( control.calType == CAL_TYPE_PCR_BLOCK ? false : true );
    enableModel( false );

    printf( "Transition Calibration: calType = %d\n", control.calType );
}

void setTemperatureStreaming( bool stream )
{
    control.streaming = stream;
}

void toggleVarianceCheck( bool enable )
{
    control.checkChannelVariance = enable;
}

void toggleTemperatureRamping( bool enable )
{
    control.rampEnabled = enable;
}

void toggleSmoothRamp( bool enable )
{
    control.smoothRampEnabled = enable;
}

bool getSmoothRampEnabled( void )
{
    return control.smoothRampEnabled;
}

bool setSampleVolume( int volume )
{
    bool pcr = control.calType == CAL_TYPE_PCR_SAMPLE ||
               control.calType == CAL_TYPE_PCR_BLOCK;

    if( volume == 0 )
    {
        volume = pcr ? DEFAULT_SAMPLE_VOLUME : 100;
    }

    if( (  pcr && ( volume == 25 || volume == 50 ) ) ||
        ( !pcr && ( volume == 100 ) ) )
    {
        int index;
        ModelType type;

        control.sampleVolume = volume;
        type = volume == 25 ? model_25uL : model_50uL;

        for( index = 0; index < BLOCK_CHANNEL_COUNT; index++ )
        {
            modelDataInit( &control.blockChannel[index].model, type,
                           index, control.blockChannel[index].currentTemp );
        }
        return true;
    }

    return false;
}

int getSampleVolume( void )
{
    return control.sampleVolume;
}

bool setModel( bool pcr, bool sample, int volume )
{
    bool            model;
    calibrationType calType;

    if( volume == -1 )
    {
        if( !pcr )
        {
            volume = 100;
        }
        else if( control.sampleVolume == 100 )
        {
            volume = DEFAULT_SAMPLE_VOLUME;
        }
        else
        {
            volume = control.sampleVolume;
        }
    }

    if( (  pcr && ( volume == 25 || volume == 50 ) ) ||
        ( !pcr && volume == 100 ) )
    {
        if( pcr )
        {
            if( sample )
            {
                model   = true;
                calType = CAL_TYPE_PCR_SAMPLE;
            }
            else
            {
                model   = false;
                calType = CAL_TYPE_PCR_BLOCK;
            }
        }
        else
        {
            model = true;

            if( sample )
            {
                calType = CAL_TYPE_SDA_SAMPLE;
            }
            else
            {
                calType = CAL_TYPE_SDA_BLOCK;
            }
        }

        //@ddh Don't automatically enable the model.
        //enableModel( model );
        setCalibrationType( calType );
        setSampleVolume( volume );
        return true;
    }

    return false;
}


bool customRamp(int ramp, int channel,
                OfflineTaskCompleteCallback callbackFunc, int callbackRef)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, true, false, false, &numChannels);

    ASSERT(numChannels); // Bad channel number
    ASSERT(channel != LIDCENTER_CHANNEL && channel != LIDRING_CHANNEL);
    ASSERT(ramp < NUM_CUSTOM_RAMPS);

    control.setBlockTempPending     = true;
    control.blockCallback.function  = callbackFunc;
    control.blockCallback.reference = callbackRef;

    if(control.customRamp[ramp].size > 0)
    {
        for(; numChannels; --numChannels)
        {
            enableChannelControl(channelData);
            channelData->customRampIndex = 0;
            channelData->customRampPtr   = &control.customRamp[ramp];
            channelData->initialSamples  = NUM_INITIAL_SAMPLES;
            channelData->rampState       = STARTING_RAMP;
            channelData->rampTargetTemp  =
                control.customRamp[ramp].data[control.customRamp[ramp].size-1];

            ++channelData;
        }
    }
    else
    {
        control.setBlockTempPending = false;

        if(callbackFunc)
        {
            callbackFunc(callbackRef, err_noError, NULL);
        }
    }

    return true;
}


bool setCustomRampData(int ramp, int index, float value)
{
    if(ramp < NUM_CUSTOM_RAMPS)
    {
        if(index == 0)
        {
            control.customRamp[ramp].size = 0;
        }

        if(index < MAX_RAMP_SIZE &&
           index == control.customRamp[ramp].size)
        {
            control.customRamp[ramp].data[control.customRamp[ramp].size++] = value;
            return true;
        }
    }

    return false;
}


bool getCustomRampData(int ramp, int index, float *value)
{
    if(ramp < NUM_CUSTOM_RAMPS &&
       index < control.customRamp[ramp].size)
    {
        *value = control.customRamp[ramp].data[index];
        return true;
    }

    return false;
}


bool blockControlEnabled( void )
{
    int channel = BLOCK_CHANNEL_COUNT;

    while( channel != 0 )
    {
        if( control.blockChannel[--channel].tempControlOn )
        {
            return true;
        }
    }
    return false;
}


bool lidControlEnabled( void )
{
    int channel = LID_CHANNEL_COUNT;

    while( channel != 0 )
    {
        if( control.lidChannel[--channel].tempControlOn )
        {
            return true;
        }
    }
    return false;
}


///////////////////////////////////////////////////
// Local functions


static bool controlTask(void* unused)
{
    ASSERT( control.state );

    control.state();

    return control.state ? true : false;
}


static void stateReadSensors( void )
{
    int index;

    for(index = 0; index < BLOCK_CHANNEL_COUNT; index++)
    {
        readSensorTemp(control.blockChannel[index].sensorNumber);
    }

    for(index = 0; index < LID_CHANNEL_COUNT; index++)
    {
        readSensorTemp(control.lidChannel[index].sensorNumber);
    }

    readSensorTemp(control.ambientChannel.sensorNumber);
    readSensorTemp(control.heatSinkChannel.sensorNumber);

    control.currentChannel = &control.blockChannel[ 0 ];
    control.lastChannel    = &control.blockChannel[ BLOCK_CHANNEL_COUNT-1 ];
    control.channelType    = BLOCK_CHANNEL;
    control.state          = stateHeatControl;
}


static void stateHeatControl( void )
{
    if( control.currentChannel <= control.lastChannel )
    {
        updateTemp( control.currentChannel,
                    control.channelType == BLOCK_CHANNEL ? control.calType :
                                                           CAL_TYPE_PCR_SAMPLE,
                    control.streaming );

        // Call "findNewTargetTemp()" before range checking currentTemp so
        // the ramp can complete even if we develop a bad sensor.
        if(control.currentChannel->tempControlOn)
        {
            control.currentChannel->targetTemp =
                findNewTargetTemp(control.currentChannel);

            control.currentChannel->currentPwm =
                tempPIDControl(control.currentChannel);
        }

        if(control.currentChannel->currentTemp > max_drive_temp ||
           control.currentChannel->currentTemp < min_drive_temp)
        {
            control.currentChannel->currentPwm = 0;
            setPwmDutyCycle(control.currentChannel->pwmNumber,
                            control.currentChannel->currentPwm);
        }
        else if(control.currentChannel->tempControlOn)
        {
            setPwmDutyCycle(control.currentChannel->pwmNumber,
                            control.currentChannel->currentPwm);
        }
    }

    if( ++control.currentChannel > control.lastChannel )
    {
        if( control.channelType == BLOCK_CHANNEL )
        {
            control.currentChannel = &control.lidChannel[ 0 ];
            control.lastChannel    = &control.lidChannel[ LID_CHANNEL_COUNT-1 ];
            control.channelType    = LID_CHANNEL;
        }
        else
        {
            control.state = stateUpdateMisc;
        }
    }
}


static void stateUpdateMisc( void )
{
    float averageSensorTemp  = 0.0;
    float averageModelTemp   = 0.0;
    int   numEnabledChannels = 0;
    int   index;
    bool  allHolding         = true;

    // Sensor-only Channels
    updateTemp( &control.ambientChannel,
                CAL_TYPE_PCR_SAMPLE, control.streaming );
    updateTemp( &control.heatSinkChannel,
                CAL_TYPE_PCR_SAMPLE, control.streaming );

    if( control.streaming )
    {
        puts("");
    }

    channelMonitor();

    allHolding = true;
    for(index = 0; index < LID_CHANNEL_COUNT; index++)
    {
        if(control.lidChannel[index].tempControlOn &&
           control.lidChannel[index].rampState != HOLDING )
        {
            allHolding = false;
        }
    }

    for(index = 0; index < LID_CHANNEL_COUNT; index++)
    {
        if( allHolding && control.lidChannel[index].tempControlOn )
        {
            checkPendingCommand( &control.lidChannel[index],
                                 control.lidChannel[index].currentTemp );
        }
    }

    allHolding = true;
    for(index = 0; index < BLOCK_CHANNEL_COUNT; index++)
    {
        if(control.blockChannel[index].tempControlOn)
        {
            averageModelTemp  += control.blockChannel[index].modeledTemp;
            averageSensorTemp += control.blockChannel[index].currentTemp;

            ++numEnabledChannels;
            if( control.blockChannel[index].rampState != HOLDING )
            {
                allHolding = false;
            }
        }
    }

    if( numEnabledChannels > 0 )
    {
        averageSensorTemp /= numEnabledChannels;
        averageModelTemp  /= numEnabledChannels;

        for(index = 0; index < BLOCK_CHANNEL_COUNT; index++)
        {
            if( allHolding && control.blockChannel[index].tempControlOn )
            {
                checkChannelVariance( &control.blockChannel[index],
                                      averageSensorTemp );

                checkPendingCommand( &control.blockChannel[index],
                                     control.useModel ? averageModelTemp :
                                                        averageSensorTemp );
            }
        }
        checkFan();
    }

    control.state = NULL;
}


static void checkPendingCommand( ChannelData* channel, float currentTemp )
{
    bool                        *pending;
    OfflineTaskCompleteCallback  function;
    int                          reference;

    if( channelIsABlockChannel( channel ) )
    {
        pending   = &control.setBlockTempPending;
        function  = control.blockCallback.function;
        reference = control.blockCallback.reference;
    }
    else
    {
        pending   = &control.setLidTempPending;
        function  = control.lidCallback.function;
        reference = control.lidCallback.reference;
    }

    if( *pending && fabs(currentTemp - channel->targetTemp) <= TARGET_THRESHOLD )
    {
        puts( "Set Target Temp finished" );
        *pending = false;

        if(function)
        {
            function(reference, err_noError, NULL);
        }
    }
}


static void checkChannelVariance( ChannelData* channel, float averageTemp )
{
    // Abort if an enabled channel differs from the average too widely.
    if( control.checkChannelVariance                              &&
        ( !control.rampEnabled || channel->rampState == HOLDING ) &&
        fabs( averageTemp - channel->currentTemp ) > MAX_TEMP_DIFFERENTIAL )
    {
        char varianceDescription[ 100 ];

        sprintf( varianceDescription,
                 "Variance Violation Abort: Channel %s = %.03f, Average = %.03f",
                 getSensorName( channel->sensorNumber ),
                 channel->currentTemp,
                 averageTemp );

        postControlFailure( true, err_blockZoneTemperatureVarianceError,
                            varianceDescription );
    }
}


static void channelMonitor(void)
{
    if( control.dispChannel )
    {
        printf("Monitor: Channel %d Temp = %6.2f C",
               control.dispChannel->channelNumber,
               control.dispChannel->currentTemp);

        if(control.dispChannel->tempControlOn)
        {
            FixedPointInt pwm  =
                separateFixedPoint(control.dispChannel->currentPwm, 1);
            printf(" PWM = %d.%d%%", pwm.wholePart, pwm.fractionalPart);
        }

        printf("\n");
    }
    else if( control.dispRaw )
    {
        printf("Monitor: Channel %d Raw = 0x%04X",
               control.dispRaw->channelNumber,
               readRawSensorReading(control.dispRaw->sensorNumber));
    }
}



static float findNewTargetTemp(ChannelData* channel)
{
    int   settleTicks;
    float settleDelta;
    float currentTemp = control.useModel ? channel->modeledTemp :
                                           channel->currentTemp;

    if( channel->customRampPtr )
    {
        if( channel->customRampIndex < channel->customRampPtr->size )
        {
            channel->targetTemp =
                channel->customRampPtr->data[channel->customRampIndex++];
        }
        else
        {
            channel->rampState     = HOLDING;
            channel->customRampPtr = NULL;
        }

        return channel->targetTemp;
    }

    if( control.rampEnabled )
    {
        switch( channel->rampState )
        {
        case IDLE:
        case HOLDING:
        case STARTING_SMOOTH_RAMP:
            break;

        case SMOOTH_RAMP:
            if( channel->rampIndex < control.ramp.size )
            {
                if( fabs( currentTemp - channel->targetTemp ) >= MAX_RAMP_DELTA )
                {
                    postRampFailure( channel, currentTemp );
                }

                channel->targetTemp = control.ramp.data[channel->rampIndex++];
            }
            else
            {
                channel->targetTemp = channel->rampTargetTemp;
                channel->rampState  = HOLDING;
                channel->maxPwm     = HEATBLOCK_MAX_PID_PWM;
                if( channel->channelNumber == 0 ) puts( "Ending smooth ramp." );
            }
            break;

        case STARTING_RAMP:
            channel->rampTime   = 0.05;
            channel->rampState  = RAMPING;

            channel->rampRate = channel->rampStartTemp < channel->rampTargetTemp ?
                                fabs( channel->rampRate ) : -fabs( channel->rampRate );

            channel->targetTemp =
                channel->rampStartTemp + channel->rampRate * channel->rampTime;
            break;

        case RAMPING:
            channel->rampTime  += 0.05;
            channel->targetTemp =
                channel->rampStartTemp + channel->rampRate * channel->rampTime;

            // Determine how close we have to be to start holding.
            if( channel->rampRate > 0 )
            {
                settleTicks = UP_RAMP_TICKS_TO_SETTLE;
                settleDelta = channel->upRampSettleDelta;
            }
            else
            {
                settleTicks = DOWN_RAMP_TICKS_TO_SETTLE;
                if( channel->rampTargetTemp > control.ambientChannel.currentTemp )
                {
                    settleDelta = channel->downRampSettleDelta;
                }
                else
                {
                    settleDelta = channel->belowAmbientDownRampSettleDelta;
                }
            }

            // Are we close enough to start settling?
            // Note: If a lid channel is being driven at maximum PWM, don't
	        //       continue ramping past the ramp target, start settling.
            if( !channelIsABlockChannel( channel )     &&
                channel->currentPwm == channel->maxPwm &&
                channel->targetTemp > channel->rampTargetTemp - TARGET_TEMP_DELTA )
            {
                channel->initialSamples = NUM_INITIAL_SAMPLES;
                channel->settleTicks    = settleTicks;
                channel->rampState      = SETTLING;
                channel->targetTemp     = channel->rampTargetTemp;
            }
            else if( ( channel->rampRate > 0 &&
                       channel->rampTargetTemp - currentTemp <= settleDelta ) ||
                     ( channel->rampRate < 0 &&
                       currentTemp - channel->rampTargetTemp <= settleDelta ) )
            {
                channel->initialSamples = NUM_INITIAL_SAMPLES;
                channel->settleTicks    = settleTicks;
                channel->rampState      = SETTLING;
                channel->targetTemp     = currentTemp;
            }
            else if( fabs( currentTemp - channel->targetTemp ) >= MAX_RAMP_DELTA )
            {
                postRampFailure( channel, currentTemp );
            }
            break;

        case SETTLING:
            if( --channel->settleTicks <= 0 )
            {
                channel->targetTemp  = channel->rampTargetTemp;
                channel->rampState   = STARTING_HOLD;
                if( control.useModel )
                {
                    // In order to reduce settling time, we clear out the
                    // integrator and derivative when using the model.
                    channel->pid.err_int    = 0;
                    channel->initialSamples = NUM_INITIAL_SAMPLES;
                }
            }
            break;

        case STARTING_HOLD:
            if( fabs( currentTemp - channel->rampTargetTemp ) <= TARGET_THRESHOLD )
            {
                channel->rampState = HOLDING;
            }
            break;

        default:
            ASSERT( 0 );
        }
    }

    return channel->targetTemp;
}

static int tempPIDControl(ChannelData* channel)
{
    const float processingPeriod_ms = (float)channel->pid.processingPeriod_ms;  // The sampling period in mS
    float u;                                                                    // summation of P,I,D,F terms


    ///////////////////////////////////
    // Calculate the Error:

    // update error readings
    channel->pid.err[2] = channel->pid.err[1];
    channel->pid.err[1] = channel->pid.err[0];

    // calculate the current error value
    channel->pid.err[0] =
      channel->targetTemp - ( control.useModel ? channel->modeledTemp :
                                                 channel->currentTemp );

    // Initialize previous errors the first time through.
    if( channel->initialSamples == NUM_INITIAL_SAMPLES )
    {
        channel->pid.err[2] = channel->pid.err[1] = channel->pid.err[0];
    }


    ///////////////////////////////////
    // Calculate the Integral:

    // integrate the error using 3-point Simpson's method cumulative
    channel->pid.err_int += (processingPeriod_ms / 6.0) * (channel->pid.err[0] +
                                                           4.0 * channel->pid.err[1] +
                                                           channel->pid.err[2]);

    // anti-windup
    if      (channel->pid.err_int > channel->pid.gains->iMax)  channel->pid.err_int = channel->pid.gains->iMax;
    else if (channel->pid.err_int < channel->pid.gains->iMin)  channel->pid.err_int = channel->pid.gains->iMin;



    ///////////////////////////////////
    // Calculate the Derivative:

    // differentiate using 3-point backward formula
    if( channel->initialSamples )
    {
        channel->pid.err_deriv = 0;
        --channel->initialSamples;
    }
    else
    {
        channel->pid.err_deriv = (0.5 * channel->pid.err[2] -
                                  2.0 * channel->pid.err[1] +
                                  1.5 * channel->pid.err[0] ) / processingPeriod_ms;
    }


    ///////////////////////////////////
    // Calculate the Feed Forward:

    float feedForward = findFeedForward(channel->targetTemp,
                                        &channel->pid.gains->ff);


    ///////////////////////////////////
    // More Integral anti-windup (only allow I if D is below a threshold).

    if( channel->pid.gains->dGain < 0.1 )
    {
        if( fabs( channel->pid.err[0] ) > channel->pid.integral_threshold )
        {
            channel->pid.err_int = 0;
        }
    }
    else if( !control.rampEnabled &&
             fabs( channel->pid.gains->dGain * channel->pid.err_deriv ) >
             channel->pid.integral_threshold )
    {
      channel->pid.err_int = 0;
    }


    ///////////////////////////////////
    // Calculate new controller value:

    float pTerm = channel->pid.gains->pGain * channel->pid.err[0];
    float iTerm = channel->pid.gains->iGain * channel->pid.err_int;
    float dTerm = channel->pid.gains->dGain * channel->pid.err_deriv;
    float fTerm = channel->pid.gains->fGain * feedForward;

    u = pTerm + iTerm + dTerm + fTerm;

    // Limit effort as we get hot so we don't overheat.
    const float temp_limiter_start = channel->rampState == SMOOTH_RAMP ? 120 : 110;
    const float temp_limiter_end   = channel->rampState == SMOOTH_RAMP ? 125 : 115;

    if( ( channel->targetTemp < temp_limiter_start )  &&
        ( channel->currentTemp > temp_limiter_start ) && ( u > 0 ) )
    {
        if( channel->currentTemp > temp_limiter_end )
        {
            u = 0;
        }
        else
        {
            u *= 1 / ( 1 + ( channel->currentTemp - temp_limiter_start ) *
                           ( channel->currentTemp - temp_limiter_start ) );
        }
    }

    if(control.pidMonitorChannel == channel->channelNumber)
    {
        // target, sample, sensor, error, integ, deriv, fforward, u

        char monitorString[ 200 ];
        char* cursor = &monitorString[0];

        cursor = addFloat3ParamToString(cursor, channel->targetTemp, true);
        cursor = addFloat3ParamToString(cursor, channel->modeledTemp, true);
        cursor = addFloat3ParamToString(cursor, channel->currentTemp, true);
        cursor = addFloat3ParamToString(cursor, pTerm, true);
        cursor = addFloat3ParamToString(cursor, iTerm, true);
        cursor = addFloat3ParamToString(cursor, dTerm, true);
        cursor = addFloat3ParamToString(cursor, fTerm, true);
        cursor = addFloat3ParamToString(cursor, u, false);

        puts( monitorString );
    }

    int newPwm = (int)(u * 10 + 0.5); //calculate tenth percent fixed point

    if(newPwm > channel->maxPwm) newPwm = channel->maxPwm;
    if(newPwm < channel->minPwm) newPwm = channel->minPwm;

    return newPwm;
}



static float findFeedForward(float targetTemp, FeedForwardParams* params)
{
    if(targetTemp >= params->positiveTransition)
    {
        return targetTemp * params->positive.slope + params->positive.offset;
    }
    else if(targetTemp >= params->negativeTransition)
    {
        return ( targetTemp * params->transition.slope + params->transition.offset );
    }
    else
    {
        return targetTemp * params->negative.slope + params->negative.offset;
    }
}


static void controlTimerCallback(void* unused)
{
    if( control.state )
    {
        const char overrunString[] = "Temperature control processing overrun!";

        puts( "TCPO" );

        if( ++control.overrunCount > MAX_CONSECUTIVE_PROCESSING_OVERRUNS )
        {
            if( blockControlEnabled() )
            {
                postControlFailure( true, err_blockControlFailure, overrunString );
            }
            if( lidControlEnabled() )
            {
                postControlFailure( false, err_lidControlFailure, overrunString );
            }
        }
    }
    else
    {
        control.overrunCount = 0;
        control.state        = stateReadSensors;
        scheduleTask(controlTask, NULL, true);
    }

    if( control.chainedCallBack.func )
    {
        control.chainedCallBack.func( control.chainedCallBack.ref );
    }
}


static PidGains *gainTypeToGainPointer( gainType type )
{
    switch( type )
    {
    case LINEAR_SAMPLE_MODEL:
    case SMOOTH_SAMPLE_MODEL:
        return &control.sampleModelPidGains;

    case HEATBLOCK:
        return &control.heatBlockPidGains;

    case HEATED_LID_CENTER:
        return &control.heatedLidCenterPidGains;

    case HEATED_LID_RING:
        return &control.heatedLidRingPidGains;

    default:
        ASSERT( 0 ); // Unknown gain type
    }

    return NULL;
}


static void updateTemp(ChannelData *channel, calibrationType calType, bool stream)
{
    float tempReading = getSensorTemp(channel->sensorNumber, ( uint8 )calType);

#if USE_TEMP_AVERAGING
    channel->tempAccumulator =
        (channel->tempAccumulator *
         (TEMP_ACCUMULATOR_COUNT - 1) / TEMP_ACCUMULATOR_COUNT) +
        tempReading;

    channel->currentTemp = channel->tempAccumulator / TEMP_ACCUMULATOR_COUNT;
#else
    channel->currentTemp = tempReading;
#endif

    channel->modeledTemp = channelIsABlockChannel( channel ) ?
        modelTemp( &channel->model, tempReading ) : channel->currentTemp;

    // Compensate for ambient if using the SDA carrier.
    if( calType == CAL_TYPE_SDA_SAMPLE )
    {
        channel->modeledTemp += SDA_AMBIENT_COMPENSATION_SCALE_LID *
                                control.ambientChannel.currentTemp +
                                SDA_AMBIENT_COMPENSATION_OFFSET_LID;
    }
    else if( calType == CAL_TYPE_SDA_BLOCK )
    {
        channel->modeledTemp += SDA_AMBIENT_COMPENSATION_SCALE_NO_LID *
                                control.ambientChannel.currentTemp +
                                SDA_AMBIENT_COMPENSATION_OFFSET_NO_LID;
    }

    if( stream )
    {
        char ascii[ 5 ];

        uint16ToAsciiHex( ascii, getSensorRawReading( channel->sensorNumber ) );
        fputs( ascii, stdout );
    }
}


static ChannelData * channelNumberToChannelData(int channel,
                                                bool allowAllBlock,
                                                bool allowAllLid,
                                                bool allowSensors,
                                                int * numChannels)
{
    int localNumChannels;
    ChannelData * localChannelData;

    if(channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL)
    {
        localNumChannels = 1;
        localChannelData = &control.blockChannel[channel - FIRST_BLOCK_CHANNEL];
    }
    else if(channel >= FIRST_LID_CHANNEL && channel <= LAST_LID_CHANNEL)
    {
        localNumChannels = 1;
        localChannelData = &control.lidChannel[channel - FIRST_LID_CHANNEL];
    }
    else if(allowSensors && (channel == AMBIENT_CHANNEL))
    {
        localNumChannels = 1;
        localChannelData = &control.ambientChannel;
    }
    else if(allowSensors && (channel == HEAT_SINK_CHANNEL))
    {
        localNumChannels = 1;
        localChannelData = &control.heatSinkChannel;
    }
    else if(allowAllBlock && (channel == ALL_BLOCK_CHANNELS))
    {
        localNumChannels = BLOCK_CHANNEL_COUNT;
        localChannelData = &control.blockChannel[0];
    }
    else if(allowAllLid && (channel == ALL_LID_CHANNELS))
    {
        localNumChannels = LID_CHANNEL_COUNT;
        localChannelData = &control.lidChannel[0];
    }
    else
    {
        ASSERT(false); // Bad channel number
        localNumChannels = 0;
        localChannelData = NULL;
    }

    if( numChannels )
        *numChannels = localNumChannels;
    return localChannelData;
}



static void enableChannelControl(ChannelData* channelData)
{
    ASSERT(channelData);

    if(!channelData->tempControlOn && !channelData->bypassed)
    {
        if( channelIsABlockChannel( channelData ) )
        {
            startTimer( &control.fanTimer, SEC_TO_TICKS( FAN_STARTUP_TIME_s ) );
            setFanDutyCycle( FAN_BLOCK, calTypeIsPCR() ? FAN_PCR_DUTY_CYCLE :
                                                         FAN_SDA_DUTY_CYCLE );
        }

        channelData->tempControlOn  = true;
        channelData->initialSamples = NUM_INITIAL_SAMPLES;
        channelData->pid.err_int    = 0;
        channelData->rampState      = STARTING_RAMP;
    }
}


static char* addFloat3ParamToString(char* string, float value, bool delimit)
{
    int intValue;

    // Handle negative numbers
    if(value < 0.0)
    {
        *string++ = '-';
        intValue = (int)(value * (float)(-1000.0) + (float)0.5);
    }
    else
    {
        intValue = (int)(value * (float)1000.0 + (float)0.5);
    }

    int places = 4;
    int scale  = 10000;

    while(intValue >= scale)
    {
        ++places;
        scale *= 10;
    }

    while(places)
    {
        --places;

        int digit = intValue % scale;

        scale /= 10;
        digit /= scale;

        *string++ = '0' + digit;

        if(places == 3)
        {
            *string++ = '.';
        }
    }

    if( delimit )
    {
        *string++ = ',';
        *string++ = '\t';
    }

    *string = '\0';

    return string;
}


static void postControlFailure( bool blockError, ErrorCodes error, const char errorString[] )
{
    if( blockError )
    {
        if( !control.setBlockTempPending )
        {
            sendErrorMsg( error, errorString );
        }
        else
        {
            control.setBlockTempPending = false;
            if( control.blockCallback.function )
            {
                control.blockCallback.function( control.blockCallback.reference,
                                                error, errorString );
            }
        }

        disableChannel( ALL_BLOCK_CHANNELS );
    }
    else
    {
        if( !control.setLidTempPending )
        {
            sendErrorMsg( error, errorString );
        }
        else
        {
            control.setLidTempPending = false;
            if( control.lidCallback.function )
            {
                control.lidCallback.function( control.lidCallback.reference,
                                              error, errorString );
            }
        }

        disableChannel( ALL_LID_CHANNELS );
    }
}


static bool channelIsABlockChannel( ChannelData *channel )
{
    return( channel >= &control.blockChannel[ 0 ] &&
            channel <  &control.blockChannel[ BLOCK_CHANNEL_COUNT ] );
}


static bool calTypeIsPCR( void )
{
    return ( control.calType == CAL_TYPE_PCR_SAMPLE ||
             control.calType == CAL_TYPE_PCR_BLOCK );
}


static bool blockIsOff( void )
{
    int index;

    for( index = 0; index < BLOCK_CHANNEL_COUNT; index++ )
    {
        if( control.blockChannel[index].tempControlOn )
        {
            return false;
        }
    }

    return true;
}


static bool blockDirectionIsHeating( float targetTemp )
{
    int           numChannels;
    float         currentTemp = 0;
    ChannelData * endPtr;
    ChannelData * channelData = channelNumberToChannelData(ALL_BLOCK_CHANNELS,
                                                           true, false,
                                                           false, &numChannels);

    for( endPtr = &channelData[ numChannels ];
         channelData < endPtr; ++channelData )
    {
        if( channelData->tempControlOn )
        {
            currentTemp = channelData->rampTargetTemp;
            numChannels = 0;
            break;
        }

        if( channelData->bypassed )
        {
            --numChannels;
        }
        else
        {
            currentTemp += control.useModel ? channelData->modeledTemp :
                                              channelData->currentTemp;
        }
    }

    if( numChannels )
    {
        currentTemp /= numChannels;
    }

    return ( currentTemp < targetTemp );
}


static void checkFan( void )
{
    int fanDutyCycle = getFanDutyCycle( FAN_BLOCK );

    if( control.fanIsControllable &&
        ( abs( fanDutyCycle - FAN_PCR_DUTY_CYCLE ) < FAN_DUTY_CYLCE_DELTA ||
          abs( fanDutyCycle - FAN_SDA_DUTY_CYCLE ) < FAN_DUTY_CYLCE_DELTA ) )
    {
        int targetRPM = fanDutyCycle == FAN_PCR_DUTY_CYCLE ? FAN_PCR_TARGET_RPM :
                                                             FAN_SDA_TARGET_RPM;

        int fanRPM = getFanRPM( FAN_BLOCK );
        if( fanRPM > 0.8 * targetRPM )
        {
            startTimer( &control.fanTimer,
                        SEC_TO_TICKS( FAN_OUT_OF_SPEED_TIME_s ) );
        }
        else
        {
            const int errorMsgSize = 50;
            char errorMsg[errorMsgSize];
            snprintf(errorMsg, errorMsgSize, "Target RPM = %d, Actual RPM = %d", targetRPM, fanRPM);
            postControlFailure( true, err_blockHeatSinkFanLowRPM, errorMsg );
        }
    }
}


static void rampGenCompleteCallback( int channel, bool status )
{
    if( !status )
    {
        control.setBlockTempPending = false;
        if(control.blockCallback.function)
        {
            control.blockCallback.function(control.blockCallback.reference,
                                           err_blockControlFailure,
                                           "Generate Ramp failed!");
        }
    }
    else
    {
        int numChannels;
        ChannelData * endPtr;
        ChannelData * channelData =
            channelNumberToChannelData(channel, true, false, false, &numChannels);

        puts( "Beginning smooth ramp." );

        for( endPtr = &channelData[numChannels]; channelData < endPtr; ++channelData)
        {
            enableChannelControl(channelData);
            channelData->rampIndex      = 0;
            channelData->targetTemp     = control.ramp.data[0];
            channelData->initialSamples = NUM_INITIAL_SAMPLES;
            channelData->rampState      = SMOOTH_RAMP;
            channelData->maxPwm         = HEATBLOCK_MAX_SMOOTH_PID_PWM;
        }
    }
}


static bool setupSmoothRamp(int channel, float targetTemp,
                            OfflineTaskCompleteCallback callbackFunc,
                            int callbackRef)
{
    int           numChannels;
    ChannelData * endPtr;
    ChannelData * channelData = channelNumberToChannelData(channel, true, true,
                                                           false, &numChannels);
    float         startTemp   = channelData->rampTargetTemp;
    float         rampRate    = channelData->rampRate;

    control.ramp.size = MAX_RAMP_SIZE;

    if( !channelData->tempControlOn || channelData->rampState != HOLDING )
    {
        // Start the ramp at the average block temperature.
        float accumulatedTemp = 0;

        for( endPtr = &channelData[ numChannels ];
             channelData < endPtr; ++channelData )
        {
            if( channelData->bypassed )
            {
                --numChannels;
            }
            else
            {
                accumulatedTemp += control.useModel ? channelData->modeledTemp :
                                                      channelData->currentTemp;
            }
        }

        if( numChannels )
        {
            startTemp = accumulatedTemp / numChannels;
        }
        else
        {
            // Quietly pass a request for only bypassed channels.
            control.setBlockTempPending = false;
        }
    }
    else if( fabs( channelData->rampTargetTemp - targetTemp ) < TARGET_TEMP_DELTA )
    {
        // We are already holding the target temperature, we're done!
        control.setBlockTempPending = false;
    }

    if( control.setBlockTempPending )
    {
        if( !startGenerateRamp( startTemp, targetTemp, rampRate,
                                1000 / HEATBLOCK_CONTROL_PROCESS_PERIOD_ms,
                                control.ramp.data, &control.ramp.size,
                                rampGenCompleteCallback, channel ) )
        {
            return false;
        }

        channelData = channelNumberToChannelData(channel, true, true,
                                                 false, &numChannels);
        for( endPtr = &channelData[ numChannels ];
             channelData < endPtr; ++channelData )
        {
            channelData->rampState      = STARTING_SMOOTH_RAMP;
            channelData->rampTargetTemp = targetTemp;
        }
    }
    else if( callbackFunc )
    {
        callbackFunc( callbackRef, err_noError, NULL );
    }

    return true;
}


static void startSDACalibrationTransition( void )
{
    bool          allHolding = true;
    int           numChannels;
    int           index = 0;
    ChannelData * endPtr;
    ChannelData * channelData = channelNumberToChannelData(ALL_BLOCK_CHANNELS,
                                                           true, true,
                                                           false, &numChannels);

    if( control.setBlockTempPending )
    {
        sendLogMsg("SDA transition error - set block temperature is pending.");
        return;
    }

    for( endPtr = &channelData[ numChannels ];
         channelData < endPtr; ++channelData )
    {
        // We can only perform a "SetTargetTemp()" here if all are holding.
        if( channelData->rampState != HOLDING )
        {
            allHolding = false;
        }

        // Recalculate the temperatures using the new calibration.
        channelData->modeledTemp     =
            channelData->currentTemp = getSensorTemp(channelData->sensorNumber,
                                                     (uint8)control.calType);

#if USE_TEMP_AVERAGING
        // Prime the temperature average with the new temperature.
        channelData->tempAccumulator =
            channelData->currentTemp * TEMP_ACCUMULATOR_COUNT;
#endif

        // Reinitialize the model with the new temperature.
        modelDataInit( &channelData->model, model_50uL,
                       index++, channelData->currentTemp );
    }

    if( allHolding )
    {
        float savedRampRate = control.blockChannel[0].rampRate;
        int   intSavedRampRate;

        memcpy(&intSavedRampRate, &savedRampRate, sizeof(int));

        // We have to fake "tempControlOn" so "SetTargetTemp()" will ramp
        // from the current temperature instead of the target.
        channelData = channelNumberToChannelData(ALL_BLOCK_CHANNELS,
                                                 true, true,
                                                 false, &numChannels);
        for( endPtr = &channelData[ numChannels ];
             channelData < endPtr; ++channelData )
        {
            channelData->tempControlOn = false;
        }

        // Perform a controlled ramp from our newly calculated temperature
        // back to the temperature that we were holding before the
        // calibration change.
        control.transitioningCalibration = true;
        setRampRate( ALL_BLOCK_CHANNELS, SDA_TRANSITION_RAMP_RATE_C_s );
        setTargetTemp( ALL_BLOCK_CHANNELS,
                       control.blockChannel[0].rampTargetTemp,
                       transitionCalibrationCallback, intSavedRampRate );
    }
}


static void transitionCalibrationCallback(int intSavedRampRate, ErrorCodes error,
                                          const char* errorDesc)
{
    float savedRampRate;

    memcpy(&savedRampRate, &intSavedRampRate, sizeof(float));

    if( control.transitioningCalibration )
    {
        if( savedRampRate > MAX_RAMP_RATE_C_s ||
            savedRampRate < MIN_RAMP_RATE_C_s )
        {
            // If the saved ramp rate isn't valid, use the default.
            savedRampRate = DEFAULT_HEATBLOCK_RAMP_RATE;
        }

        setRampRate( ALL_BLOCK_CHANNELS, savedRampRate );
        control.transitioningCalibration = false;
    }
}


void bypassChannel(int channel, bool bypass)
{
    int numChannels;
    ChannelData * channelData =
        channelNumberToChannelData(channel, false, false, false, &numChannels);

    ASSERT(numChannels == 1); // Bad channel number

    if(bypass)
    {
        channelData->tempControlOn = false;
        channelData->bypassed      = true;
    }
    else
    {
        channelData->bypassed = false;
    }
}


static void postRampFailure( ChannelData* channel, float currentTemp )
{
    char tempFailureDescription[ 100 ];

    sprintf( tempFailureDescription,
             "Temperature Ramp Control Failure: Channel %s = %.03f, Target = %.03f",
             getSensorName( channel->sensorNumber ),
             currentTemp,
             channel->targetTemp );

    bool isBlockChannel = channelIsABlockChannel( channel );

    postControlFailure( isBlockChannel,
                        isBlockChannel ? err_blockTargetTemperatureNotReached :
                                         err_lidTargetTemperatureNotReached,
                        tempFailureDescription );
}


// EOF
