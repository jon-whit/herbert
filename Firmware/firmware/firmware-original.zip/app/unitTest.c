/////////////////////////////////////////////////////////////
//
//  unitTest.c
//
//  System Unit Tests
//
//  Copyright 2008 Idaho Technology
//  Created by Brett Gilbert

#include <unitTest.h>
#include <os.h>
#include <lcd.h>
#include <timer.h>
#include <pwm.h>
#include <spi.h>
#include <serial.h>
#include <xparameters.h>
#include <flash.h>



///////////////////////////////////////////////////
// Selected Tests

#define TEST_PWM          0
#define TEST_SPI          0
#define TEST_SERIAL       0
#define TEST_FLASH        0
#define TEST_ILLUMINATION 0



///////////////////////////////////////////////////
// Test functions

#if TEST_PWM

    #define PWM_TIMER_ms  50
    #define PWM_START_VAL -100
    #define PWM_END_VAL   100

    void testPwm()
    {
        while(1)
        {
            int i;
            for(i = PWM_START_VAL; i <= PWM_END_VAL; i++)
            {
                lcdLinePrintf(0, "PWM at %d%%", i);

                setPwmChannelDutyCycle(0, i);
                setPwmChannelDutyCycle(1, -i);

                mdelay(PWM_TIMER_ms);
            }

            for(i = PWM_START_VAL; i <= PWM_END_VAL; i++)
            {
                lcdLinePrintf(0, "PWM at %d%%", -i);

                setPwmChannelDutyCycle(0, -i);
                setPwmChannelDutyCycle(1, i);

                mdelay(PWM_TIMER_ms);
            }
        }
    }

#endif



#if TEST_SPI
    void testSpi()
    {
        while(1)
        {
            #define BUF_SIZE 50

            int i;
            uint8 txBuf[BUF_SIZE];
            uint8 rxBuf[BUF_SIZE];

            for(i = 0; i < 10; i++)
            {
                txBuf[i] = i;
            }

            SpiStatus status = spiStartTransmit(txBuf, 10);

            lcdLinePrintf(0, "SPI Tx Status %d", status);

            mdelay(1);

            unsigned rxReadCount = 0;
            status = spiReadData(rxBuf, 10, &rxReadCount);

            lcdLinePrintf(1, "SPI Rx %d, %d", status, rxReadCount);

            mdelay(5000);
            lcdClear();
            mdelay(500);
        }
    }
#endif


#if TEST_SERIAL
    void testSerial()
    {
        // This is a loopback test for the serial interface

        while(1)
        {
            #define BUF_SIZE 500

            uint8 buf[BUF_SIZE];

            unsigned count = serialGetPkt(SERIAL_PORT_DCE, buf, BUF_SIZE);

            if(count)
            {
                buf[count] = 0;
                lcdLinePrintf(0, "RX: %d %s", count, buf);
                if(serialSendPkt(SERIAL_PORT_DCE, buf, count))
                {
                    lcdLinePrintf(1, "TX: %d Success", count);
                }
                else
                {
                    lcdLinePrintf(1, "TX: %d Failed", count);
                }
            }
        }
    }
#endif


#if TEST_FLASH
    #include <M29DW323D.h>

    void testFlash()
    {
        resetNvram();

        uint16 val = 0xaa55;
        int i;

        for(i = 0; i < 10; i++)
        {
            if(!nvramWriteWord(5, val))
            {
                lcdLinePrintf(0, "Flash Write Failed");
            }

            if(!nvramWriteWord(5, val))
            {
                lcdLinePrintf(0, "Flash Write Failed");
            }

            if(!nvramWriteWord(5, val & 0xff00))
            {
                lcdLinePrintf(0, "Flash Write Failed");
            }

            val++;
        }
    }
#endif



#if TEST_ILLUMINATION
    #include <illumination.h>

    void testIllumination()
    {
        lcdClear();
        lcdLinePrintf(0, "IlluminationTest");

        #define LEDTEST_ONTIME_ms 2000

        while(1)
        {
            lcdLinePrintf(1, "Blue");
            turnOnIlluminationLed(BLUE_ILLUMINATION);
            mdelay(LEDTEST_ONTIME_ms);
            turnOffIlluminationLed(BLUE_ILLUMINATION);
            mdelay(1);

            lcdLinePrintf(1, "Green");
            turnOnIlluminationLed(GREEN_ILLUMINATION);
            mdelay(LEDTEST_ONTIME_ms);
            turnOffIlluminationLed(GREEN_ILLUMINATION);
            mdelay(1);

            lcdLinePrintf(1, "Orange");
            turnOnIlluminationLed(ORANGE_ILLUMINATION);
            mdelay(LEDTEST_ONTIME_ms);
            turnOffIlluminationLed(ORANGE_ILLUMINATION);
            mdelay(1);

            lcdLinePrintf(1, "Red");
            turnOnIlluminationLed(RED_ILLUMINATION);
            mdelay(LEDTEST_ONTIME_ms);
            turnOffIlluminationLed(RED_ILLUMINATION);
            mdelay(1);

            lcdLinePrintf(1, "Crimson");
            turnOnIlluminationLed(CRIMSON_ILLUMINATION);
            mdelay(LEDTEST_ONTIME_ms);
            turnOffIlluminationLed(CRIMSON_ILLUMINATION);

            lcdLinePrintf(1, "Off");
            mdelay(3000);

        }
    }
#endif


///////////////////////////////////////////////////
// Interface functions

void runUnitTests()
{
    #if TEST_PWM
        testPwm();
    #endif

    #if TEST_SPI
        testSpi();
    #endif

    #if TEST_SERIAL
        testSerial();
    #endif

    #if TEST_FLASH
        testFlash();
    #endif

    #if TEST_ILLUMINATION
        testIllumination();
    #endif
}


// EOF
