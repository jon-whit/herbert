/////////////////////////////////////////////////////////////
//
//  startup.c
//
//  System Startup
//
//  Copyright 2010 Idaho Technology
//  Created by Brett Gilbert


#include <startup.h>
#include <stdio.h>
#include <types.h>
#include <interrupt.h>
#include <led.h>
#include <pwm.h>
#include <fan.h>
#include <lcd.h>
#include <timer.h>
#include <processor.h>
#include <assert.h>
#include <sensors.h>
#include <serial.h>
#include <comm.h>
#include <control.h>
#include <version.h>
#include <cache.h>
#include <illumination.h>
#include <model.h>
#include <AT45DB161D.h>
#include <motion.h>
#include <os.h>
#include <selfTest.h>
#include <system.h>
#include <initialization.h>
#include <ramp.h>



///////////////////////////////////////////////////
// Constants



///////////////////////////////////////////////////
// Local types and macros



///////////////////////////////////////////////////
// Local function prototypes



///////////////////////////////////////////////////
// Local data



///////////////////////////////////////////////////
// Interface functions

void systemStartup()
{
    disableInterrupts();

    SYSTEM.bootloaderLED = LED_OFF;
    SYSTEM.heartbeatLED  = LED_ON;
    SYSTEM.activityLED   = LED_ON;

    printf("\n\n");
    printf("-------------------------------------------\n");
    printf("   Plate Cycler App Firmware\n");
    printf("     FPGA Version: %lu.%lu\n", FPGA_MAJOR_VER(), FPGA_MINOR_VER());
    printf("     FW Version:   " FW_VER "\n");
    printf("     Built:        " __DATE__ " " __TIME__ "\n");
    printf("-------------------------------------------\n\n");

    // Pre-interrupt initialization
    cacheInit();
    osInit();
    intcInit();
    timerInit();
    lcdInit();
    ledInit();
    pwmInit();
    fanInit();
    serialInit();
    commInit();
    initializationInit();
    selfTestInit();
    rampInit();

    // Enable interrupts
    enableInterrupts();

    // Post-interrupt initialization
    illuminationInit();
    sensorsInit();
    modelInit();
    serialFlashInit();
    motionInit();
    controlInit();

    // Schedule Tasks
    scheduleTask(ledProcess, NULL, false);
    scheduleTask(commProcess, NULL, false);
    scheduleTask(motionProcess, NULL, false);

    // Start Systems
    systemStart();

    printf("System Ready.\n");

    sendLogMsg("FPGA Firmware version " FW_VER " starting.");

    // Start task processor - never returns
    osStart();
}



void systemStart()
{
    controlStart();
    illuminationStart();
}



void systemStop()
{
    controlStop();
    illuminationStop();
}




///////////////////////////////////////////////////
// Local functions



// EOF
