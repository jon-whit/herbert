/////////////////////////////////////////////////////////////
//
//  illumination.c
//
//  Illumination LED driver
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#include <illumination.h>
#include <spi.h>
#include <assert.h>
#include <xparameters.h>
#include <signal.h>
#include <timer.h>
#include <stdio.h>
#include <stdlib.h>
#include <os.h>
#include <system.h>
#include <version.h>
#include <eeprom.h>
#include <motion.h>
#include <math.h>



///////////////////////////////////////////////////
// Constants

#define ILLUMINATION_MINIMUM_FPGA_MAJOR_VER    2
#define ILLUMINATION_MINIMUM_FPGA_MINOR_VER    2

#define POWER_OFF                              0x0000
#define POWER_FULL                             0xFFFF
#define DEFAULT_POWER                          0x8000
#define OVER_ONE_AMP_THRESHOLD                 3200 // Roughly 10%

// These help compensate for the negative bias voltage after the DAC.
#define DRIVE_BASE                             28500
#define DRIVE_RANGE                            (65535 - DRIVE_BASE)

#define DEFAULT_FEEDBACK_ADC_VALUE             POWER_FULL
#define SPI_TIMEOUT_us                         1000

#define ILLUMINATION_CONTROL_PROCESS_PERIOD_ms 10
#define ERROR_THRESHOLD                        8
#define SETTLE_SAMPLE_COUNT                    2
#define FEEDBACK_CALIBRATION_SAMPLES           64

#define ILLUMINATION_INTEGRAL_MAX              DRIVE_RANGE
#define ILLUMINATION_INTEGRAL_MIN             -DRIVE_RANGE

#define UPPER_CAL_LIMIT                        0xFF00
#define LOWER_CAL_LIMIT                        0x00FF

#define MAX_HIGH_CURRENT_ON_TIME_s             60
#define LED_STABILIZATION_TIME_ms              250
#define LED_FIRST_STABILIZATION_TIME_ms        500

#define LED_ANALOG_CONTROL_DISABLE             1
#define LED_ANALOG_CONTROL_ENABLE              0

#define FEEDBACK_ERROR_THRESHOLD_PERCENT       10

enum EepromSizes
{
    EEPROM_ADDR_SENSOR_CALIBRATION_VALUES_SIZE = 5 * 2,  // 5 channels * 2 bytes
};

enum EepromMap
{
    EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES = 0x0000, // 5 channels * 2 bytes (per calibration)
    EEPROM_SIZE_LED_CALIBRATED_FEEDBACK_VALUES = 0x0100,

    EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES         = 0x0100, // 5 channels * 2 bytes (per calibration)
    EEPROM_SIZE_LED_1_AMP_DRIVE_VALUES         = 0x0100,

    EEPROM_ADDR_LED_SERIAL_NUMBER              = 0x7800, // 32 bytes
    EEPROM_SIZE_LED_SERIAL_NUMBER              = 0x0100,
};


///////////////////////////////////////////////////
// Local types and macros

typedef enum
{
    LED_SPI_ADDR_DRIVE    = 0,
    LED_SPI_ADDR_FEEDBACK = 1,
    LED_SPI_ADDR_EEPROM   = 2,
    LED_SPI_ADDR_TEMP_1   = 3,
    LED_SPI_ADDR_TEMP_2   = 4,
    LED_SPI_ADDR_TEMP_3   = 5,
    LED_SPI_ADDR_TEMP_4   = 6,
    LED_SPI_ADDR_OFF      = 7
} ledSpiAddress;

typedef enum
{
    LED_CHANNEL_BLUE               = 0x0,
    LED_CHANNEL_GREEN              = 0x1,
    LED_CHANNEL_ORANGE             = 0x2,
    LED_CHANNEL_RED                = 0x3,
    LED_CHANNEL_CRIMSON            = 0x4,
    LED_CHANNEL_PRIMARY_FEEDBACK   = 0x5,
    LED_CHANNEL_NONE               = 0x7,
    LED_CHANNEL_SECONDARY_FEEDBACK = 0xD
} ledChannel;


typedef enum
{
    MODE_OFF,
    MODE_OPEN_LOOP,
    MODE_CLOSED_LOOP,
    MODE_SETTLING
} ControlMode;


// Note: IlluminationIndex order is important
typedef enum
{
    BLUE_INDEX,
    GREEN_INDEX,
    ORANGE_INDEX,
    RED_INDEX,
    CRIMSON_INDEX,
    ILLUMINATION_CHANNELS
} IlluminationIndex;


typedef struct
{
    uint16 power;
    uint16 feedback;
    float  intensity;
    float  storedIState;
    float  storedIntensity;
    uint16 oneAmpPower;
} ControlData;


typedef struct
{
    OfflineTaskCompleteCallback function;
    int                         reference;
} OperationCallback;


typedef struct
{
    float dState;   //!< Last position input.
    float iState;   //!< Integrator state.

    float iMax;     //!< Maximum allowable integrator state.
    float iMin;     //!< Minimum allowable integrator state.

    float iGain;    //!< Integral gain.
    float pGain;    //!< Proportional gain.
    float dGain;    //!< Differential gain.

    float ffScale;  //!< Feed forward scale.
    float ffOffset; //!< Feed forward offset.
} pid_struct;


typedef struct
{
    SpiInterface      spiInterface;
    Eeprom            eeprom;

    ControlMode       mode;
    int               settlingSamplesRemaining;
    uint16            feedbackTarget;
    uint16            feedbackThreshold;
    uint16            currentDrive;
    uint16            currentDacValue;
    uint16            dacValues[ ILLUMINATION_CHANNELS ];

    IlluminationColor color;
    TimerCallBackInfo chainedCallBack;
    bool              stream;

    ControlData       control[ ILLUMINATION_CHANNELS ];
    uint16            lowLEDPower;
    uint16            highLEDPower;
    pid_struct        pid[ ILLUMINATION_CHANNELS ];

    bool              initialized;
    bool              closedLoop;
    OperationCallback callback;
    Timer             onTimer;
    bool              timerIsOn;
    Timer             stableTimer;

    IlluminationColor oneAmpColor;
} IlluminationData;


//////////////////////////////////////////////////
// Local function prototypes

static bool   illuminationTask(void* unused);
static void   setIlluminationPower( IlluminationColor color, uint16 power,
                                    bool refreshAllChannels );
/* static void   setCalibratedPower(IlluminationColor color, uint16 power); */
/* static uint16 getCalibratedPower(IlluminationColor color); */
static void   setStoredIState( IlluminationColor color, float iState );
static float  getStoredIState(IlluminationColor color);
static void   setStoredIntensity( IlluminationColor color );
static float  getStoredIntensity(IlluminationColor color);
static uint16 getFeedbackTarget(IlluminationColor color);
static void   illuminationTimerCallback(void* chainedCyclePeriod);
static uint16 readFeedbackADC(ledChannel channel);
static void   writeDriveDac( uint16 value );
static void   setLedChannelAndDac( ledChannel channel, uint16 dacValue,
                                   bool refreshAllChannels );
static uint16 getChannelDacValue( ledChannel channel );
static bool   channelIsADriveChannel( ledChannel channel );

static ledChannel        indexToChannel( IlluminationIndex index );
static IlluminationIndex channelToIndex( ledChannel channel );
static IlluminationIndex colorToIndex( IlluminationColor color );
static ledChannel        colorToChannel(IlluminationColor color);
static ControlData *     getControlDataPointer(IlluminationColor color);

static bool   getFeedbackCalibration(uint8 index, bool validateCRC,
                                     uint16 *calibration);
static bool   setFeedbackCalibration(uint8 index, uint16 feedback);
static bool   getOneAmpCalibration(uint8 index, bool validateCRC, uint16 * cal);
static void   setOneAmpCalibration(uint8 index, uint16 feedback);
static void   setSpiAddress( volatile uint32* reg, uint32 addr);
static float  update_pid( pid_struct *pid, float error, float feedback );
static void   saveClosedLoopParameters( IlluminationColor color );
static void   setIntensity( IlluminationColor color, float intensity );
static float  getIntensity( IlluminationColor color );
static uint16 getOneAmpPower( IlluminationColor color );
static void   streamIlluminationData( int target, int feedback,
                                      int prop, int integ, int deriv,
                                      int ff, int drive );
static void   turnOnClosedLoop( IlluminationColor color,
                                OfflineTaskCompleteCallback func, int ref );
static int    countColors( IlluminationColor color );
static bool   okayToGoClosedLoop( bool lidIsLowered );
static void   postControlFailure( ErrorCodes error, const char errorString[] );

///////////////////////////////////////////////////
// Local data

static IlluminationData illuminationData;

static const int defaultCalValues[ ILLUMINATION_CHANNELS ] =
{
    24600, // blue
    7150,  // green
    4320,  // orange
    22500, // red
    6870   // crimson
};


static const int defaultOneAmpCalValues[ ILLUMINATION_CHANNELS ] =
{
    34000, // blue
    34000, // green
    34000, // orange
    34000, // red
    34000  // crimson
};


static const float defaultPidGains[ ILLUMINATION_CHANNELS ][ 5 ] =
{
    { 0.0, 0.1, 0.0, 0.0, 0.0 }, // blue
    { 0.0, 0.4, 0.0, 0.0, 0.0 }, // green
    { 0.0, 0.4, 0.0, 0.0, 0.0 }, // orange
    { 0.0, 0.1, 0.0, 0.0, 0.0 }, // red
    { 0.0, 0.4, 0.0, 0.0, 0.0 }  // crimson
};


static const int chainedCyclePeriod = 5;

///////////////////////////////////////////////////
// Interface functions

const char* getIlluminationName(IlluminationColor color)
{
    switch(color)
    {
    case BLUE_ILLUMINATION:     return "Blue";
    case GREEN_ILLUMINATION:    return "Green";
    case ORANGE_ILLUMINATION:   return "Orange";
    case RED_ILLUMINATION:      return "Red";
    case CRIMSON_ILLUMINATION:  return "Crimson";
    default:
        ASSERT(false);
    }
    
    return NULL;
}



void illuminationInit()
{
    int  i;
    bool success = true;

    illuminationData.initialized = false;

    if( FPGA_MAJOR_VER() < ILLUMINATION_MINIMUM_FPGA_MAJOR_VER ||
       ( FPGA_MAJOR_VER() == ILLUMINATION_MINIMUM_FPGA_MAJOR_VER &&
         FPGA_MINOR_VER() < ILLUMINATION_MINIMUM_FPGA_MINOR_VER ) )
    {
        printf("************************************************\n"
               "  Illumination Error - Incompatible FPGA Image\n"
               "      Expecting version: %u.%u\n",
               ILLUMINATION_MINIMUM_FPGA_MAJOR_VER,
               ILLUMINATION_MINIMUM_FPGA_MINOR_VER);
        printf("      Actual version:    %lu.%lu\n",
               FPGA_MAJOR_VER(), FPGA_MINOR_VER());
        printf("    Module not initialized!\n"
               "************************************************\n");
        return;
    }

    spiInterfaceInit(&illuminationData.spiInterface,
                     XPAR_LED_SPI_DEVICE_ID,
                     XPAR_INTC_LED_SPI_IP2INTC_IRPT_INTR,
                     XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION |
                     XSP_CLK_ACTIVE_LOW_OPTION,
                     0);

    eepromInterfaceInit(&illuminationData.eeprom, &illuminationData.spiInterface,
                        &SPI_CONTROL.ledSpiAddr,
                        LED_SPI_ADDR_EEPROM, LED_SPI_ADDR_OFF,
                        &setSpiAddress);

    turnOffIllumination(ALL_ILLUMINATION);

    illuminationData.mode              = MODE_OFF;
    illuminationData.stream            = false;
    illuminationData.currentDacValue   = 0;

    SPI_CONTROL.ledAnalogControl       = LED_ANALOG_CONTROL_DISABLE;

    illuminationData.initialized       = true;
    illuminationData.closedLoop        = true;
    illuminationData.timerIsOn         = false;
    illuminationData.callback.function = NULL;

    for( i = 0; i < ILLUMINATION_CHANNELS; ++i )
    {
        illuminationData.pid[i].dState   = 0;
        illuminationData.pid[i].iState   = 0;

        illuminationData.pid[i].pGain    = defaultPidGains[ i ][ 0 ];
        illuminationData.pid[i].iGain    = defaultPidGains[ i ][ 1 ];
        illuminationData.pid[i].dGain    = defaultPidGains[ i ][ 2 ];
        illuminationData.pid[i].ffScale  = defaultPidGains[ i ][ 3 ];
        illuminationData.pid[i].ffOffset = defaultPidGains[ i ][ 4 ];

        illuminationData.pid[i].iMax     = ILLUMINATION_INTEGRAL_MAX /
                                           illuminationData.pid[i].iGain;
        illuminationData.pid[i].iMin     = ILLUMINATION_INTEGRAL_MIN /
                                           illuminationData.pid[i].iGain;

        success &= getFeedbackCalibration( i, false, &illuminationData.control[ i ].feedback );
        success &= getOneAmpCalibration( i, false, &illuminationData.control[ i ].oneAmpPower );

        illuminationData.control[ i ].power           = DEFAULT_POWER;
        illuminationData.control[ i ].intensity       = 1.0;
        illuminationData.control[ i ].storedIState    = 0.0;
        illuminationData.control[ i ].storedIntensity = 0.0;

        illuminationData.dacValues[ i ]  = 0;
    }

    if( !success ||
        !validateEepromCRC( &illuminationData.eeprom,
                            EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES,
                            EEPROM_SIZE_LED_CALIBRATED_FEEDBACK_VALUES ) ||
        !validateEepromCRC( &illuminationData.eeprom,
                            EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES,
                            EEPROM_SIZE_LED_1_AMP_DRIVE_VALUES ) )
    {
        sendErrorMsg( err_ledNotCalibrated,
                      "Error reading LED calibration!" );
    }
}


void illuminationStart()
{
    if(!illuminationData.initialized)
    {
        return;
    }

    // Start timer
    enablePeriodicTimer(illuminationTimerCallback, ( void * )&chainedCyclePeriod,
                        MSEC_TO_TICKS(ILLUMINATION_CONTROL_PROCESS_PERIOD_ms),
                        &illuminationData.chainedCallBack);
}



void illuminationStop()
{
    //TODO: Should we restore the chained callback function here?
    if(!illuminationData.initialized)
    {
        return;
    }

    disablePeriodicTimer();
}



void illuminationAbort()
{
    illuminationData.callback.function = NULL;
    turnOffIllumination(ALL_ILLUMINATION);
}



void turnOnIllumination(IlluminationColor color, bool oneAmp,
                        OfflineTaskCompleteCallback callbackFunc, int callbackRef)
{
    IlluminationColor oldColor = illuminationData.color;
    int colorCount = countColors( illuminationData.color | color );
    
    ASSERT(!(color & ~ALL_ILLUMINATION));

    if(!illuminationData.initialized || !color)
    {
        if( callbackFunc )
        {
            callbackFunc( callbackRef, err_noError, NULL);
        }

        return;
    }

    illuminationData.color |= color;

    if( oneAmp )
    {
        illuminationData.oneAmpColor |= color;
    }
    else
    {
        illuminationData.oneAmpColor &= (~color & ALL_ILLUMINATION);
    }


    if( okayToGoClosedLoop( getLidPosition() == lid_lowered ) )
    {
        if( oldColor != illuminationData.color )
        {
            turnOnClosedLoop( color, callbackFunc, callbackRef );
        }
        else if( callbackFunc )
        {
            callbackFunc( callbackRef, err_noError, NULL);
        }
    }
    else
    {
        saveClosedLoopParameters( oldColor );
        illuminationData.mode = MODE_OPEN_LOOP;

        if( !oneAmp && colorCount == 1 )
        {
            if( oldColor != illuminationData.color )
            {
                setIlluminationPower(color, getCalibratedPower(color) * getIntensity(color), true);
                printf( "Turning LED %d On (open loop)\n", color );

                if( illuminationData.currentDacValue >
                    getOneAmpPower( color ) + OVER_ONE_AMP_THRESHOLD )
                {
                    startTimer(&illuminationData.onTimer,
                               SEC_TO_TICKS(MAX_HIGH_CURRENT_ON_TIME_s));
                    illuminationData.timerIsOn = true;
                }
            }
        }
        else
        {
            int mask;

            illuminationData.timerIsOn = false;
            for(mask = BLUE_ILLUMINATION; mask <= CRIMSON_ILLUMINATION; mask <<= 1)
            {
                if( ( illuminationData.color & mask ) &&
                    ( ( oldColor == mask ) || !( oldColor & mask ) ) )
                {
                    setIlluminationPower(mask, getOneAmpPower( mask ), true);
                    printf( "Turning LED %d On (low power)\n", mask );
                }
            }
        }

        if( callbackFunc )
        {
            callbackFunc( callbackRef, err_noError, NULL);
        }
    }

    SPI_CONTROL.ledEnable    = 1;
    SPI_CONTROL.ledFanEnable = 1;
}



void turnOffIllumination(IlluminationColor color)
{
    ASSERT(!(color & ~ALL_ILLUMINATION));

    // Return if we are not initialized or we have nothing to do.
    if( !illuminationData.initialized || !color )
    {
        return;
    }

    if( illuminationData.color & color )
    {
        saveClosedLoopParameters( illuminationData.color );
    }

    illuminationData.color       &= (~color & ALL_ILLUMINATION);
    illuminationData.oneAmpColor &= (~color & ALL_ILLUMINATION);

    int colorCount = 0;
    int mask;
    
    for(mask = BLUE_ILLUMINATION; mask <= CRIMSON_ILLUMINATION; mask <<= 1)
    {
        if(illuminationData.color & mask)
        {
            ++colorCount;
        }
        else if( color & mask )
        {
            setIlluminationPower(mask, POWER_OFF, true);
            printf( "Turning LED %d Off\n", mask );
        }
    }

    if( !colorCount )
    {
        illuminationData.mode      = MODE_OFF;
        illuminationData.timerIsOn = false;
        SPI_CONTROL.ledEnable      = 0;
        SPI_CONTROL.ledFanEnable   = 0;
    }
    else if( okayToGoClosedLoop( getLidPosition() == lid_lowered ) )
    {
        turnOnClosedLoop( illuminationData.color, NULL, 0 );
    }
}



bool getIllumination(IlluminationColor color)
{
    return illuminationData.color & color;
}


void setIlluminationIntensity( IlluminationColor color, float intensity )
{
    int colorCount = countColors( color );

    if( illuminationData.initialized && colorCount == 1 )
    {
        setIntensity( color, intensity );
    }
}


void restoreIlluminationIntensity( void )
{
    int i;

    for( i = 0; i < ILLUMINATION_CHANNELS; ++i )
    {
        illuminationData.control[ i ].intensity = 1.0;
    }
}


float getIlluminationIntensity( IlluminationColor color )
{
    float intensity  = 0.0;
    int   colorCount = countColors( color );

    if( illuminationData.initialized && colorCount == 1 )
    {
        intensity = getIntensity( color );
    }

    return intensity;
}


void setLedStreaming( bool stream )
{
    illuminationData.stream = stream;
}


uint16 getIlluminationCurrent(IlluminationColor color)
{
    uint16 feedback = readFeedbackADC( colorToChannel( color ) );

    return ( uint16 )( ( ( uint32 )feedback * 50000 ) >> 16 );
}


bool setIlluminationCalibration( IlluminationColor color, uint16 calibration )
{
    if( ( calibration < UPPER_CAL_LIMIT ) &&
        ( calibration > LOWER_CAL_LIMIT ) &&
        setFeedbackCalibration( colorToIndex( color ), calibration ) )
    {
        getControlDataPointer( color )->feedback = calibration;
        return true;
    }
    return false;
}


bool calibrateIllumination( void )
{
    ControlData * channelPointer = getControlDataPointer(illuminationData.color);

    if( channelPointer )
    {
        uint32 accumulator = 0;
        int i;

        // Average many samples to get a good feedback calibration value.
        for( i = 0; i < FEEDBACK_CALIBRATION_SAMPLES; ++i )
        {
            accumulator += readFeedbackADC( LED_CHANNEL_PRIMARY_FEEDBACK );
        }
        accumulator /= FEEDBACK_CALIBRATION_SAMPLES;

        if( ( accumulator < UPPER_CAL_LIMIT ) &&
            ( accumulator > LOWER_CAL_LIMIT ) )
        {
            illuminationData.feedbackTarget    = ( uint16 )accumulator;
            illuminationData.feedbackThreshold = ( uint16) ( accumulator /
                                                             FEEDBACK_ERROR_THRESHOLD_PERCENT );
            setFeedbackCalibration( colorToIndex( illuminationData.color ),
                                    illuminationData.feedbackTarget );
            channelPointer->feedback = illuminationData.feedbackTarget;
            channelPointer->power = illuminationData.currentDrive;
            return true;
        }
    }

    return false;
}


bool getIlluminationCalibration( IlluminationColor color, uint16 *calibration )
{
    return getFeedbackCalibration( colorToIndex( color ), true, calibration );
}


bool setOneAmpIlluminationCalibration( IlluminationColor color, uint16 calibration )
{
    if( ( calibration < UPPER_CAL_LIMIT ) &&
        ( calibration > LOWER_CAL_LIMIT ) )
    {
        setOneAmpCalibration( colorToIndex( color ), calibration );
        getControlDataPointer( color )->oneAmpPower = calibration;
        return true;
    }
    return false;
}


bool getOneAmpIlluminationCalibration( IlluminationColor color, uint16 *calibration )
{
    return getOneAmpCalibration( colorToIndex( color ), true, calibration );
}


uint16 getIlluminationFeedback( bool primary )
{
    return readFeedbackADC( primary ? LED_CHANNEL_PRIMARY_FEEDBACK :
                                      LED_CHANNEL_SECONDARY_FEEDBACK );
}


void toggleIlluminationControl( bool closedLoop )
{
    illuminationData.closedLoop = closedLoop;
}


void setIlluminationPidGain( IlluminationColor color,
                             pid_gain_type which_gain, float new_gain )
{
    IlluminationIndex index = colorToIndex( color );

    switch( which_gain )
    {
    case proportional_gain:
        illuminationData.pid[index].pGain = new_gain;
        break;
    case integral_gain:
        illuminationData.pid[index].iState = 0;
        illuminationData.pid[index].iGain  = new_gain;

        if( new_gain != 0.0 )
        {
            illuminationData.pid[index].iMax =
                ILLUMINATION_INTEGRAL_MAX / new_gain;
            illuminationData.pid[index].iMin =
                ILLUMINATION_INTEGRAL_MIN / new_gain;
        }
        break;
    case derivative_gain:
        illuminationData.pid[index].dGain = new_gain;
        break;
    case feed_forward_scale:
        illuminationData.pid[index].ffScale = new_gain;
        break;
    case feed_forward_offset:
        illuminationData.pid[index].ffOffset = new_gain;
        break;
    default:
        ASSERT(false);
    }
}


float getIlluminationPidGain( IlluminationColor color, pid_gain_type which_gain )
{
    IlluminationIndex index = colorToIndex( color );
    float gain = 0.0;

    switch( which_gain )
    {
    case proportional_gain:
        gain = illuminationData.pid[index].pGain;
        break;
    case integral_gain:
        gain = illuminationData.pid[index].iGain;
        break;
    case derivative_gain:
        gain = illuminationData.pid[index].dGain;
        break;
    case feed_forward_scale:
        gain = illuminationData.pid[index].ffScale;
        break;
    case feed_forward_offset:
        gain = illuminationData.pid[index].ffOffset;
        break;
    default:
        ASSERT(false);
    }

    return gain;
}


void transitionIllumination( bool lidIsLowered )
{
    if( illuminationData.mode != MODE_OFF )
    {
        if( okayToGoClosedLoop( lidIsLowered ) )
        {
            if( illuminationData.mode != MODE_CLOSED_LOOP )
            {
                turnOnClosedLoop( illuminationData.color, NULL, 0 );
            }
        }
        else if( illuminationData.mode != MODE_OPEN_LOOP )
        {
            saveClosedLoopParameters( illuminationData.color );
            illuminationData.mode = MODE_OPEN_LOOP;
            puts( "Transition Illumination to Open Loop" );
        }
    }
}


void illuminationNVWriteAllCRCs( void )
{
    writeEepromCRC(&illuminationData.eeprom,
                   EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES,
                   EEPROM_SIZE_LED_CALIBRATED_FEEDBACK_VALUES);
    writeEepromCRC(&illuminationData.eeprom,
                   EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES,
                   EEPROM_SIZE_LED_1_AMP_DRIVE_VALUES);
}


///////////////////////////////////////////////////
// Local functions

static bool illuminationTask(void* unused)
{
    IlluminationData * data = &illuminationData;
    uint16 feedback;
    float  drive;

    feedback = readFeedbackADC(LED_CHANNEL_PRIMARY_FEEDBACK);

    if( illuminationData.stream && data->mode != MODE_CLOSED_LOOP )
    {
        streamIlluminationData( illuminationData.feedbackTarget,
                                feedback, 0, 0, 0, 0,
                                data->currentDacValue );
    }

    if( data->timerIsOn && timerExpired( &data->onTimer ) )
    {
        turnOffIllumination( data->color );
    }

    switch( data->mode )
    {
    case MODE_OPEN_LOOP:
    case MODE_OFF:
        break;

    case MODE_SETTLING:
        if( !--data->settlingSamplesRemaining )
        {
            data->feedbackTarget    = getFeedbackTarget( data->color ) *
                                      getIntensity( data->color );
            data->feedbackThreshold = data->feedbackTarget /
                                      FEEDBACK_ERROR_THRESHOLD_PERCENT;
            data->pid[colorToIndex( data->color )].iState = getStoredIState( data->color );
            data->mode = MODE_CLOSED_LOOP;
        }
        break;

    case MODE_CLOSED_LOOP:
        if( data->callback.function && timerExpired( &data->stableTimer ) )
        {
            data->callback.function(data->callback.reference, err_noError, NULL);
            data->callback.function = NULL;
        }

        drive = update_pid( &data->pid[colorToIndex( data->color )],
                            ( float )data->feedbackTarget - ( float )feedback,
                            ( float )feedback ) + DRIVE_BASE;

        if( drive < 0 )
        {
            drive = 0;
        }
        else if( drive >= POWER_FULL )
        {
            drive = POWER_FULL;

            if( abs( data->feedbackTarget - feedback ) > data->feedbackThreshold )
            {
                postControlFailure( err_ledControlFailure, NULL );
                break;
            }
        }

        data->currentDrive = ( uint16 )drive;

        setIlluminationPower( data->color, data->currentDrive, false );

        if( data->currentDrive <= getOneAmpPower( data->color ) + OVER_ONE_AMP_THRESHOLD )
        {
            illuminationData.timerIsOn = false;
        }
        else if( !illuminationData.timerIsOn )
        {
            startTimer(&data->onTimer, SEC_TO_TICKS(MAX_HIGH_CURRENT_ON_TIME_s));
            illuminationData.timerIsOn = true;
        }
        break;

    default:
        ASSERT( 0 );
    }

    // Refresh sample and hold circuits and ensure the light feedback
    // channel is selected.
    setLedChannelAndDac( LED_CHANNEL_PRIMARY_FEEDBACK, 0, true );
    return false;
}


static ledChannel indexToChannel( IlluminationIndex index )
{
    ledChannel channel;

    switch( index )
    {
    case BLUE_INDEX:
        channel = LED_CHANNEL_BLUE;
        break;

    case GREEN_INDEX:
        channel = LED_CHANNEL_GREEN;
        break;

    case ORANGE_INDEX:
        channel = LED_CHANNEL_ORANGE;
        break;

    case RED_INDEX:
        channel = LED_CHANNEL_RED;
        break;

    case CRIMSON_INDEX:
        channel = LED_CHANNEL_CRIMSON;
        break;

    default:
        ASSERT(false);
        break;
    }

    return channel;
}


static ledChannel colorToChannel(IlluminationColor color)
{
    ledChannel channel;

    switch( color )
    {
    case BLUE_ILLUMINATION:
        channel = LED_CHANNEL_BLUE;
        break;

    case GREEN_ILLUMINATION:
        channel = LED_CHANNEL_GREEN;
        break;

    case ORANGE_ILLUMINATION:
        channel = LED_CHANNEL_ORANGE;
        break;

    case RED_ILLUMINATION:
        channel = LED_CHANNEL_RED;
        break;

    case CRIMSON_ILLUMINATION:
        channel = LED_CHANNEL_CRIMSON;
        break;

    default:
        ASSERT(false);
        break;
    }

    return channel;
}


static IlluminationIndex channelToIndex( ledChannel channel )
{
    IlluminationIndex index;

    switch( channel )
    {
    case LED_CHANNEL_BLUE:
        index = BLUE_INDEX;
        break;
    case LED_CHANNEL_GREEN:
        index = GREEN_INDEX;
        break;
    case LED_CHANNEL_ORANGE:
        index = ORANGE_INDEX;
        break;
    case LED_CHANNEL_RED:
        index = RED_INDEX;
        break;
    case LED_CHANNEL_CRIMSON:
        index = CRIMSON_INDEX;
        break;
    default:
        ASSERT( 0 );
        break;
    }
    return index;
}


static IlluminationIndex colorToIndex( IlluminationColor color )
{
    IlluminationIndex index;

    switch( color )
    {
    case BLUE_ILLUMINATION:
        index = BLUE_INDEX;
        break;

    case GREEN_ILLUMINATION:
        index = GREEN_INDEX;
        break;

    case ORANGE_ILLUMINATION:
        index = ORANGE_INDEX;
        break;

    case RED_ILLUMINATION:
        index = RED_INDEX;
        break;

    case CRIMSON_ILLUMINATION:
        index = CRIMSON_INDEX;
        break;

    default:
        ASSERT(false);
        break;
    }

    return index;
}


static bool channelIsADriveChannel( ledChannel channel )
{
    switch( channel )
    {
    case LED_CHANNEL_BLUE:
    case LED_CHANNEL_GREEN:
    case LED_CHANNEL_ORANGE:
    case LED_CHANNEL_RED:
    case LED_CHANNEL_CRIMSON:
        return true;
    default:
        break;
    }
    return false;
}


static uint16 getChannelDacValue( ledChannel channel )
{
    uint16 dacValue = POWER_OFF;

    if( channelIsADriveChannel( channel ) )
    {
        dacValue = illuminationData.dacValues[ channelToIndex( channel ) ];
    }

    return dacValue;
}


static void setLedChannelAndDac( ledChannel channel, uint16 dacValue,
                                 bool refreshAllChannels )
{
    // We may need to change the LED channel, the DAC value, both, or
    // neither.
    //
    // If the new channel is a drive channel, then the shadow register
    // containing a record of the DAC value for that channel must be
    // updated.
    //
    // If we are already on the right drive channel and the DAC is not
    // holding the correct value, then we can just write the new value to
    // the DAC.
    //
    // If we must change the channel and the DAC value, then first we must
    // select an open channel so we don't disturb the current channel.  We
    // can then write the new value to the DAC.  We must also wait for the
    // DAC output to stabilize before we select the new channel.
    //
    // Finally, we can select the new channel.

    if( refreshAllChannels )
    {
        int i;

        for( i = 0; i < ILLUMINATION_CHANNELS; ++i )
        {
            if( indexToChannel( i ) != channel )
            {
                if( SPI_CONTROL.ledChannel != indexToChannel( i ) )
                {
                    if( illuminationData.currentDacValue !=
                        illuminationData.dacValues[ i ] )
                    {
                        SPI_CONTROL.ledChannel = LED_CHANNEL_NONE;
                        writeDriveDac( illuminationData.dacValues[ i ] );
                        udelay( 20 );
                    }
                    SPI_CONTROL.ledChannel = indexToChannel( i );
                    udelay( 5 );
                }
            }
        }
    }

    if( channelIsADriveChannel( channel ) )
    {
        if( illuminationData.currentDacValue != dacValue )
        {
            if( SPI_CONTROL.ledChannel == channel )
            {
                writeDriveDac( dacValue );
            }
            else
            {
                SPI_CONTROL.ledChannel = LED_CHANNEL_NONE;
                writeDriveDac( dacValue );
                udelay( 20 );
            }
        }

        illuminationData.dacValues[ channelToIndex( channel ) ] = dacValue;
    }

    SPI_CONTROL.ledChannel = channel;
}


static void setIlluminationPower( IlluminationColor color, uint16 power,
                                  bool refreshAllChannels )
{
    setLedChannelAndDac( colorToChannel( color ), power, refreshAllChannels );
}


/* static */ void setCalibratedPower(IlluminationColor color, uint16 power)
{
    getControlDataPointer( color )->power = power;
}


/* static */ uint16 getCalibratedPower(IlluminationColor color)
{
    return getControlDataPointer( color )->power;
}


static void setStoredIState( IlluminationColor color, float iState )
{
    getControlDataPointer( color )->storedIState = iState;
}


static float getStoredIState(IlluminationColor color)
{
    return getControlDataPointer( color )->storedIState;
}


static void setStoredIntensity( IlluminationColor color )
{
    getControlDataPointer( color )->storedIntensity =
        getControlDataPointer( color )->intensity;
}


static float getStoredIntensity(IlluminationColor color)
{
    return getControlDataPointer( color )->storedIntensity;
}


static uint16 getFeedbackTarget(IlluminationColor color)
{
    return getControlDataPointer( color )->feedback;
}


static void setIntensity( IlluminationColor color, float intensity )
{
    getControlDataPointer( color )->intensity = intensity;
}


static float getIntensity(IlluminationColor color)
{
    return getControlDataPointer( color )->intensity;
}


static uint16 getOneAmpPower( IlluminationColor color )
{
    return getControlDataPointer( color )->oneAmpPower;
}


static uint16 readFeedbackADC(ledChannel channel)
{
    enum { ADC_BYTES = 3 };

    uint32 result;
    uint8  buffer[ADC_BYTES];
    uint16 readCount;

    // Select the channel
    if( SPI_CONTROL.ledChannel != channel )
    {
        setLedChannelAndDac( channel, getChannelDacValue( channel ), false );
        // Allow ADC input to settle
        mdelay( 5 );
    }

    // Clock in the data
    SPI_CONTROL.ledSpiAddr = LED_SPI_ADDR_FEEDBACK;
    spiWaitAndStartTransmit(&illuminationData.spiInterface,
                            buffer, 3, SPI_TIMEOUT_us);

    // Read the data
    spiWaitAndReadData(&illuminationData.spiInterface,
                       buffer, ADC_BYTES, &readCount, SPI_TIMEOUT_us);
    SPI_CONTROL.ledSpiAddr = LED_SPI_ADDR_OFF;

    // Parse the data
    result   = ( uint32 )buffer[0];
    result <<= 8;
    result  |= ( uint32 )buffer[1];
    result <<= 8;
    result  |= ( uint32 )buffer[2];
    result >>= 1;

    SPI_CONTROL.ledSpiAddr = LED_SPI_ADDR_OFF;

    if( readCount != ADC_BYTES )
        result = DEFAULT_FEEDBACK_ADC_VALUE;

    return ( uint16 )result;
}


static void writeDriveDac( uint16 value )
{
    enum { DAC_BYTES = 3 };

    uint8 buffer[DAC_BYTES];

    SPI_CONTROL.ledSpiAddr = LED_SPI_ADDR_DRIVE;

    buffer[0] = 0;
    buffer[1] = ( uint8 )( value >> 8 );
    buffer[2] = ( uint8 )value;

    spiWaitAndStartTransmit(&illuminationData.spiInterface,
                            buffer, DAC_BYTES, SPI_TIMEOUT_us);
    spiWaitForReady(&illuminationData.spiInterface, SPI_TIMEOUT_us);

    SPI_CONTROL.ledSpiAddr = LED_SPI_ADDR_OFF;
    illuminationData.currentDacValue = value;
}


static void illuminationTimerCallback(void* chainedCyclePeriod)
{
    static int chainedCycleCount = 0;

    scheduleTask(illuminationTask, NULL, true);
    if( illuminationData.chainedCallBack.func &&
        ++chainedCycleCount >= *( int * )chainedCyclePeriod )
    {
        chainedCycleCount = 0;
        illuminationData.chainedCallBack.func( illuminationData.chainedCallBack.ref );
    }
}


static ControlData * getControlDataPointer(IlluminationColor color)
{
    ControlData * controlDataPointer = NULL;

    switch(color)
    {
        case BLUE_ILLUMINATION:
            controlDataPointer = &illuminationData.control[ BLUE_INDEX    ];
            break;

        case GREEN_ILLUMINATION:
            controlDataPointer = &illuminationData.control[ GREEN_INDEX   ];
            break;

        case ORANGE_ILLUMINATION:
            controlDataPointer = &illuminationData.control[ ORANGE_INDEX  ];
            break;

        case RED_ILLUMINATION:
            controlDataPointer = &illuminationData.control[ RED_INDEX     ];
            break;

        case CRIMSON_ILLUMINATION:
            controlDataPointer = &illuminationData.control[ CRIMSON_INDEX ];
            break;

        default:
            ASSERT(false);
    }

    return controlDataPointer;
}


static void setSpiAddress( volatile uint32* reg, uint32 addr)
{
    // The EEPROM is half a clock out of phase from the other devices on
    // the SPI bus.  We have to change the options of the SPI hardware when
    // changing to or from the EEPROM.
    if( addr == LED_SPI_ADDR_EEPROM )
    {
        spiSetOptions(&illuminationData.spiInterface,
                      XSP_CLK_ACTIVE_LOW_OPTION |
                      XSP_MASTER_OPTION         |
                      XSP_MANUAL_SSELECT_OPTION |
                      XSP_CLK_PHASE_1_OPTION);
    }
    else if( addr == LED_SPI_ADDR_OFF )
    {
        spiSetOptions(&illuminationData.spiInterface,
                      XSP_CLK_ACTIVE_LOW_OPTION |
                      XSP_MASTER_OPTION         |
                      XSP_MANUAL_SSELECT_OPTION);
    }

    ASSERT( reg );
    *reg = addr;
}


static bool getFeedbackCalibration(uint8 index, bool validateCRC,
                                   uint16 *calibration)
{
    *calibration = readEepromUint16(&illuminationData.eeprom,
                                    EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES +
                                    index * sizeof(uint16));

    if( *calibration > UPPER_CAL_LIMIT || *calibration < LOWER_CAL_LIMIT ||
        ( validateCRC &&
          !validateEepromCRC( &illuminationData.eeprom,
                              EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES,
                              EEPROM_SIZE_LED_CALIBRATED_FEEDBACK_VALUES ) ) )
    {
        *calibration = defaultCalValues[ index ];
        return false;
    }

    return true;
}


static bool setFeedbackCalibration(uint8 index, uint16 feedback)
{
    writeEepromUint16(&illuminationData.eeprom,
                      EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES +
                      index * sizeof(uint16), feedback);

    writeEepromCRC(&illuminationData.eeprom,
                   EEPROM_ADDR_LED_CALIBRATED_FEEDBACK_VALUES,
                   EEPROM_SIZE_LED_CALIBRATED_FEEDBACK_VALUES);

    return true;
}


static bool getOneAmpCalibration(uint8 index, bool validateCRC, uint16 * cal)
{
    *cal = readEepromUint16(&illuminationData.eeprom,
                            EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES +
                            index * sizeof(uint16));

    if( *cal > UPPER_CAL_LIMIT || *cal < LOWER_CAL_LIMIT ||
        ( validateCRC && !validateEepromCRC( &illuminationData.eeprom,
                                             EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES,
                                             EEPROM_SIZE_LED_1_AMP_DRIVE_VALUES ) ) )
    {
        *cal = defaultOneAmpCalValues[ index ];
        return false;
    }

    return true;
}


static void setOneAmpCalibration(uint8 index, uint16 feedback)
{
    writeEepromUint16(&illuminationData.eeprom,
                      EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES +
                      index * sizeof(uint16), feedback);

    writeEepromCRC(&illuminationData.eeprom,
                   EEPROM_ADDR_LED_1_AMP_DRIVE_VALUES,
                   EEPROM_SIZE_LED_1_AMP_DRIVE_VALUES);
}


static float update_pid( pid_struct *pid, float error, float feedback )
{
    float pTerm;
    float iTerm;
    float dTerm;
    float fTerm;
    float drive;

    // calculate the proportional term
    pTerm = pid->pGain * error;

    // calculate the integral state with appropriate limiting
    pid->iState += error;

    if( pid->iState > pid->iMax )
        pid->iState = pid->iMax;
    else if( pid->iState < pid->iMin )
        pid->iState = pid->iMin;

    iTerm = pid->iGain * pid->iState;

    // calculate the differential term
    dTerm = pid->dGain * ( feedback - pid->dState );
    pid->dState = feedback;

    // calculate the feed forward term
    fTerm = pid->ffScale * getIntensity( illuminationData.color ) + pid->ffOffset;

    // calculate the total effort
    drive = pTerm + iTerm - dTerm + fTerm;

    streamIlluminationData( illuminationData.feedbackTarget, ( int )feedback,
                            ( int )pTerm, ( int )iTerm, ( int )dTerm,
                            ( int )fTerm, ( int )drive );

    return drive;
}


static void saveClosedLoopParameters( IlluminationColor color )
{
    // If we are running closed loop, update the "calibrated" power level
    // to enable us to settle quicker when we turn this light back on.
    if( illuminationData.mode == MODE_CLOSED_LOOP )
    {
        setCalibratedPower( color, illuminationData.currentDrive );
        setStoredIState( color, illuminationData.pid[colorToIndex( color )].iState );
        setStoredIntensity( color );
    }
}


void streamIlluminationData( int target, int feedback,
                             int prop, int integ, int deriv,
                             int ff, int drive )
{
    if( illuminationData.stream )
    {
        // target, feedback, prop, integ, deriv, ff, u
        char monitorString[ 200 ];
        char* cursor = &monitorString[0];

        cursor += sprintf( cursor, "%d,\t%d,\t%d,\t%d,\t%d,\t%d,\t%d",
                           target, feedback, prop, integ, deriv, ff, drive );
        puts( monitorString );
    }
}


static void turnOnClosedLoop( IlluminationColor color,
                              OfflineTaskCompleteCallback func, int ref )
{
    illuminationData.callback.function        = func;
    illuminationData.callback.reference       = ref;
    illuminationData.settlingSamplesRemaining = SETTLE_SAMPLE_COUNT;
    illuminationData.mode                     = MODE_SETTLING;
    illuminationData.currentDrive             = getCalibratedPower(color);
    setIlluminationPower(color, illuminationData.currentDrive, true);

    if( func )
    {
        startTimer( &illuminationData.stableTimer,
                    fabs( getStoredIntensity(color) - getIntensity(color) ) < 0.01 ?
                    MSEC_TO_TICKS( LED_STABILIZATION_TIME_ms ) :
                    MSEC_TO_TICKS( LED_FIRST_STABILIZATION_TIME_ms ) );
    }

    printf( "Turning LED %d On (closed loop)\n", color );
}


static int countColors( IlluminationColor color )
{
    int colorCount = 0;
    int mask;
    
    for(mask = BLUE_ILLUMINATION; mask <= CRIMSON_ILLUMINATION; mask <<= 1)
    {
        if(color & mask)
        {
            ++colorCount;
        }
    }

    return colorCount;
}


static bool okayToGoClosedLoop( bool lidIsLowered )
{
    return ( illuminationData.closedLoop                                &&
             lidIsLowered                                               &&
             !( illuminationData.oneAmpColor & illuminationData.color ) &&
             countColors( illuminationData.color ) == 1 );
}


static void postControlFailure( ErrorCodes error, const char errorString[] )
{
    turnOffIllumination( illuminationData.color );

    if( !illuminationData.callback.function )
    {
        sendErrorMsg( error, NULL );
    }
    else
    {
        illuminationData.callback.function(illuminationData.callback.reference,
                                           error, NULL);
        illuminationData.callback.function = NULL;
    }
}
// EOF
