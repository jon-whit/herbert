/////////////////////////////////////////////////////////////
//
//  performance.c
//
//  Plate Cycler Hardware Performanc Test
//
//  Copyright 2010 Idaho Technology
//  Created by David Hawks

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <performance.h>
#include <comm.h>
#include <timer.h>
#include <control.h>
#include <os.h>
#include <assert.h>
#include <sensors.h>
#include <illumination.h>
#include <motion.h>
#include <fan.h>


///////////////////////////////////////////////////
// Constants

typedef struct
{
    int failed;
    int major;
    int minor;
} Limits;

static const Limits blockLimits =
{
    70,                  /* Failed */
    50,                  /* Major Degradation */
    30                   /* Minor Degradation */
};

static const Limits lidLimits =
{
    70,                  /* Failed */
    50,                  /* Major Degradation */
    30                   /* Minor Degradation */
};

static const Limits ledLimits =
{
    10,                  /* Failed */
    7,                   /* Major Degradation */
    5                    /* Minor Degradation */
};

static const Limits heatsinkFanLimits =
{
    2400,                /* Failed */
    2550,                /* Major Degradation */
    2700                 /* Minor Degradation */
};

static const float defaultThermalPerformanceTargetDelta[numThermalTypes][numDirections] =
{
    { 70.0,   70.0 },    /* Lid */
    { -10.0,  60.0  }    /* Block */
};

static const int defaultThermalBaselineEffort[numThermalTypes][numDirections] =
{
    { 250,  250 },       /* Lid */
    { -300, 600 }        /* Block */
};

static const uint32 maxCavityWaitTime_ms = 60000;


#define STATUS_DESC_SIZE    200

#define LID_TARGET_OFFSET   0
#define BLOCK_TARGET_OFFSET 2 * sizeof( uint32 )
#define LID_EFFORT_OFFSET   BLOCK_TARGET_OFFSET + 2 * sizeof( uint32 )
#define BLOCK_EFFORT_OFFSET LID_EFFORT_OFFSET + 4 * sizeof( int )

///////////////////////////////////////////////////
// Local types and macros

typedef void ( *StateFunction )( void );

typedef struct
{
    int              baseline;
    int              delta;
} TestResults;

typedef struct
{
    StateFunction    state;
    Timer            timer;
    float            targetTemp;
    int              status;
    int              channel;
    ThermalDirection direction;
    ErrorCodes       error;
} ThermalTest;

typedef struct
{
    StateFunction     state;
    Timer             timer;
    IlluminationColor color;
    TestDevices       device;
    int               status;
} IlluminationTest;

typedef struct
{
    StateFunction     state;
    Timer             timer;
    int               maxRPM;
    int               slowCount;
    int               status;
} FanTest;

typedef enum
{
    PerformanceState_Idle,
    PerformanceState_Running,
} PerformanceStates;

typedef struct
{
    OfflineTaskCompleteCallback completedCallbackFunc;
    OfflineTaskInfoCallback     infoCallbackFunc;
    int                         reference;
} OperationCallback;

typedef struct
{
    PerformanceStates state;
    OperationCallback callback;

    ThermalTest       blockTest;
    ThermalTest       lidThermalTest;
    IlluminationTest  illuminationTest;
    FanTest           heatsinkFanTest;

    TestResults       blockTestResults[ BLOCK_CHANNEL_COUNT ][ numDirections ];
    TestResults       lidTestResults[ LID_CHANNEL_COUNT ];

    ErrorCodes        error;
    char              errorDesc[ STATUS_DESC_SIZE ];

    bool              baseline;
} PerformanceData;


///////////////////////////////////////////////////
// Local function prototypes

static bool startPerformanceTestTask(void* unused);
static bool runPerformanceTestTask(void* state);

static ErrorCodes statusToError( int status );

// Block Performance Test State Functions
static void blockTestState_Starting( void );
static void blockTestState_WaitingOnCavity( void );
static void blockTestState_Setting( void );
static void blockTestState_Ramping( void );
static void blockTestState_Checking( void );
static void blockTestState_Completed( void );

// Lid Performance Test State Functions
static void lidThermalTestState_Starting( void );
static void lidThermalTestState_Setting( void );
static void lidThermalTestState_Ramping( void );
static void lidThermalTestState_Checking( void );
static void lidThermalTestState_Completed( void );

// Illumination Performance Test State Functions
static void illuminationTestState_Starting( void );
static void illuminationTestState_WaitingOnCavityClose( void );
static void illuminationTestState_TestStart( void );
static void illuminationTestState_TestCheck( void );
static void illuminationTestState_Finishing( void );
static void illuminationTestState_WaitingOnCavityOpen( void );
static void illuminationTestState_Completed( void );

// Fan Performance Test State Functions
static void fanTestState_Starting( void );
static void fanTestState_Checking( void );

// Thermal Test Helper Functions
static void blockPerformanceTestCallback(int reference, ErrorCodes error,
                                         const char* errorDesc);
static void lidPerformanceTestCallback(int reference, ErrorCodes error,
                                       const char* errorDesc);
static ThermalType getChannelType( int channel );
static uint16      findNVOffset( ThermalType type, int channel,
                                 ThermalDirection direction, bool target );
static bool        getBaselineEffort( int channel,
                                      ThermalDirection direction, int *effort );
static void        setBaselineEffort( int channel,
                                      ThermalDirection direction, int effort );
static bool        getPerformanceTarget( ThermalType type,
                                         ThermalDirection direction,
                                         float *target );
static bool        getPerformanceTargetDelta( ThermalType type,
                                              ThermalDirection direction,
                                              float *target );

// Illumination Performance Test Helper Functions
static void illuminationPerformanceTestCallback(int reference, ErrorCodes error,
                                                const char* errorDesc);
static int  illuminationPerformanceVerifyLED(IlluminationColor color,
                                             TestDevices device);

static IlluminationColor iterateIllumination( IlluminationColor color );

static TestDevices illuminationToDevice( IlluminationColor color );



///////////////////////////////////////////////////
// Local data

static PerformanceData performanceData;


///////////////////////////////////////////////////
// Interface functions

void performanceInit()
{
    performanceData.state = PerformanceState_Idle;
}


bool startPerformanceTest( OfflineTaskCompleteCallback completedCallbackFunc,
                           OfflineTaskInfoCallback     infoCallbackFunc,
                           int                         callbackRef,
                           bool                        baseline )
{
    if( performanceData.state != PerformanceState_Idle)
    {
        return false;
    }

    performanceData.callback.completedCallbackFunc = completedCallbackFunc;
    performanceData.callback.infoCallbackFunc      = infoCallbackFunc;
    performanceData.callback.reference             = callbackRef;

    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
    enableModel(false);
    setCalibrationType(CAL_TYPE_PCR_BLOCK);

    performanceData.baseline = baseline ? true : false;
    performanceData.state    = PerformanceState_Running;

    scheduleTask(startPerformanceTestTask, NULL, false);

    return true;
}


void abortPerformanceTest()
{
    performanceData.callback.completedCallbackFunc = NULL;
    performanceData.callback.infoCallbackFunc      = NULL;
    performanceData.state                          = PerformanceState_Idle;

    performanceData.blockTest.state                = NULL;
    performanceData.lidThermalTest.state           = NULL;
    performanceData.illuminationTest.state         = NULL;

    resetTempControl(ALL_BLOCK_CHANNELS);
    resetTempControl(ALL_LID_CHANNELS);
}


bool getThermalPerformanceTarget( ThermalType type,
                                  ThermalDirection direction, float *target )
{
    if( type < numThermalTypes && direction < numDirections )
    {
        return getPerformanceTargetDelta( type, direction, target );
    }

    return false;
}

bool getThermalBaselineEffort( int channel,
                               ThermalDirection direction, int *effort )
{
    *effort = 0;

    if( ( ( channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL ) ||
          ( channel >= FIRST_LID_CHANNEL   && channel <= LAST_LID_CHANNEL   ) ) &&
        direction < numDirections )
    {
        return getBaselineEffort( channel, direction, effort );
    }

    return false;
}

///////////////////////////////////////////////////
// Local functions


static bool startPerformanceTestTask(void* unused)
{
    performanceData.error                 = err_noError;
    performanceData.errorDesc[0]          = '\0';

    performanceData.blockTest.status      = NONE;
    performanceData.blockTest.state       = blockTestState_Starting;

    performanceData.lidThermalTest.status = NONE;
    performanceData.lidThermalTest.state  = lidThermalTestState_Starting;

    if( !performanceData.baseline )
    {
        performanceData.illuminationTest.status = NONE;
        performanceData.illuminationTest.state  = illuminationTestState_Starting;

        if( fanIsControllable() )
        {
            performanceData.heatsinkFanTest.status = NONE;
            performanceData.heatsinkFanTest.state  = fanTestState_Starting;
        }
    }

    scheduleTask(runPerformanceTestTask, &performanceData.blockTest.state, false);

    //TODO: Add timeout for tests

    return false;
}


static bool runPerformanceTestTask(void* state)
{
    if( !state || !*(StateFunction *)state )
    {
        return false;
    }

    (*(StateFunction *)state)();

    return *(StateFunction *)state ? true : false;
}


static void completeTest()
{
    if(performanceData.state == PerformanceState_Running &&
       !performanceData.heatsinkFanTest.state            &&
       !performanceData.blockTest.state                  &&
       !performanceData.lidThermalTest.state               )
    {
        if(performanceData.baseline)
        {
            performanceData.baseline = false;
            performanceData.illuminationTest.state =
                illuminationTestState_Finishing;
            scheduleTask(runPerformanceTestTask,
                         &performanceData.illuminationTest.state, false);
        }
        else if(performanceData.illuminationTest.state ==
                illuminationTestState_Starting)
        {
            scheduleTask(runPerformanceTestTask,
                         &performanceData.illuminationTest.state, false);
        }
        else if(!performanceData.illuminationTest.state)
        {
            if(performanceData.callback.completedCallbackFunc)
            {
                performanceData.callback.
                    completedCallbackFunc(performanceData.callback.reference,
                                          performanceData.error,
                                          performanceData.errorDesc);
            }

            performanceData.callback.infoCallbackFunc = NULL;
            performanceData.state                     = PerformanceState_Idle;

            resetTempControl(ALL_BLOCK_CHANNELS);
            resetTempControl(ALL_LID_CHANNELS);
        }
    }
}


static ErrorCodes statusToError( int status )
{
    switch( status )
    {
    case BAD_BASELINE:
        return err_performanceTestComponentBadBaseline;
    case FAILED:
        return err_performanceTestComponentFailure;
    case MAJOR:
        return err_performanceTestComponentMajor;
    case MINOR:
        return err_performanceTestComponentMinor;
    case NONE:
        return err_noError;
    default:
        ASSERT( 0 );
    }

    return err_noError;
}


static void sendInfoStatus(TestDevices device, ErrorCodes error, const char* errorDesc)
{
    if(error != err_noError                       &&
       error != err_performanceTestComponentMinor &&
       error != err_performanceTestComponentMajor &&
       error != err_performanceTestComponentSkipped )
    {
        performanceData.error = err_performanceTestFailure;
    }

    if(performanceData.callback.infoCallbackFunc)
    {
        performanceData.callback.infoCallbackFunc(device, error, errorDesc);
    }
}


static int testDriveEffort( int channel, ThermalDirection direction,
                            TestResults *results )
{
    Limits const * limits = channel > LAST_BLOCK_CHANNEL ? &lidLimits :
                                                           &blockLimits;
    int status;
    int absDelta;

    if( !getBaselineEffort( channel, direction, &results->baseline ) )
    {
        results->delta    = 0;
        results->baseline = 0;

        printf( "    Bad Baseline for Channel: %02d\n", channel );
        return BAD_BASELINE;
    }

    results->delta = getPwm( channel, pwmCurrent ) - results->baseline;
    absDelta       = abs( results->delta );

    if( ( direction == heat && results->delta < 0 ) ||
        ( direction == cool && results->delta > 0 ) ||
        ( absDelta < limits->minor ) )
    {
        status = NONE;
    }
    else if( absDelta < limits->major )
    {
        status = MINOR;
    }
    else if( absDelta < limits->failed )
    {
        status = MAJOR;
    }
    else
    {
        status = FAILED;
    }

    return status;
}


static int setDriveBaseline( int channel, ThermalDirection direction,
                             TestResults *results )
{
    Limits const * limits = channel > LAST_BLOCK_CHANNEL ? &lidLimits :
                                                           &blockLimits;
    int status = BAD_BASELINE;

    results->baseline = getPwm( channel, pwmCurrent );
    results->delta    = 0;

    // Don't allow a baseline that is so close to the PWM limit that a
    // failure cannot be detected.
    if( ( direction == heat &&
          results->baseline + limits->failed < getPwm( channel, pwmMax ) ) ||
        ( direction == cool &&
          results->baseline - limits->failed > getPwm( channel, pwmMin ) ) )
    {
        setBaselineEffort( channel, direction, results->baseline );
        status = NONE;
    }
    else
    {
        printf("    Could not set baseline - Channel: %s, Direction: %d, Effort: %d.%d%%\n",
               getSensorName(channel), direction,
               results->baseline/10, abs(results->baseline%10) );
    }

    return status;
}


static bool getPerformanceTarget( ThermalType type,
                                  ThermalDirection direction, float *target )
{
    if( getPerformanceTargetDelta( type, direction, target ) )
    {
        *target += getCurrentTemp( type == lid ? AMBIENT_CHANNEL :
                                                 HEAT_SINK_CHANNEL );
        return true;
    }

    return false;
}


static bool getPerformanceTargetDelta( ThermalType type,
                                       ThermalDirection direction, float *target )
{
    uint32 value =
        sensorsNVReadPerfData( findNVOffset( type, 0, direction, true ) );

    if( sensorsNVValidatePerfDataCRC() && value != 0xFFFFFFFF )
    {
        memcpy( target, &value, 4 );

        if( ( type == block && ( ( *target > -10.1 ) && ( *target < 60.1 ) ) ) ||
            ( type == lid   && ( ( *target > 59.9  ) && ( *target < 70.1 ) ) ) )
        {
            return true;
        }
    }

    printf( "Bad Performance Target Delta: Type %d, Direction %d, Target = %.03f\n",
            type, direction, *target );

    return false;
}


static void setPerformanceTargetDelta( ThermalType type,
                                       ThermalDirection direction, float target )
{
    sensorsNVWritePerfData( findNVOffset( type, 0, direction, true ),
                            *( ( uint32 * )&target ) );
    sensorsNVWritePerfDataCRC();

    printf("    Setting Target Delta - Type: %d, Direction: %d, Delta: %0.3f\n",
           type, direction, target );
}


static bool getBaselineEffort( int channel,
                               ThermalDirection direction, int *effort )
{
    ThermalType type = getChannelType( channel );

    channel -= type == lid ? FIRST_LID_CHANNEL : FIRST_BLOCK_CHANNEL;

    *effort =
        sensorsNVReadPerfData( findNVOffset( type, channel, direction, false ) );

    if( sensorsNVValidatePerfDataCRC() && 
        ( ( type == block && *effort >= -1000 && *effort <= 1000 ) ||
          ( type == lid   && *effort >= 0     && *effort <= 1000 ) ) )
    {
        return true;
    }

    return false;
}


static void setBaselineEffort( int channel,
                               ThermalDirection direction, int effort )
{
    ThermalType type = getChannelType( channel );

    channel -= type == lid ? FIRST_LID_CHANNEL : FIRST_BLOCK_CHANNEL;

    sensorsNVWritePerfData( findNVOffset( type, channel, direction, false ),
                            ( uint32 )effort );
    sensorsNVWritePerfDataCRC();
}


static ThermalType getChannelType( int channel )
{
    ThermalType type;

    if( channel >= FIRST_BLOCK_CHANNEL && channel <= LAST_BLOCK_CHANNEL )
    {
        type = block;
    }
    else if( channel >= FIRST_LID_CHANNEL && channel <= LAST_LID_CHANNEL )
    {
        type = lid;
    }
    else
    {
        ASSERT( 0 );
    }

    return type;
}


static uint16 findNVOffset( ThermalType type, int channel,
                            ThermalDirection direction, bool target )
{
    uint16 baseOffset;

    if( target )
    {
        channel = 0;
        baseOffset = type == lid ? LID_TARGET_OFFSET : BLOCK_TARGET_OFFSET;
    }
    else
    {
        baseOffset = type == lid ? LID_EFFORT_OFFSET : BLOCK_EFFORT_OFFSET;
    }

    return baseOffset + ( channel   * sizeof( int ) * numDirections +
                          direction * sizeof( int ) );
}


///////////////////////////////////////////////////
// Block Test

static void blockTestState_Starting( void )
{
    puts("Testing Block");

    if( performanceData.baseline )
    {
        setPerformanceTargetDelta( block, cool,
                                   defaultThermalPerformanceTargetDelta[ block ][ cool ] );
        setPerformanceTargetDelta( block, heat,
                                   defaultThermalPerformanceTargetDelta[ block ][ heat ] );
    }

    resetTempControl(ALL_BLOCK_CHANNELS);
    performanceData.blockTest.direction = cool;
    performanceData.blockTest.error     = err_blockCoolingTestFailure;

    if( getLidPosition() == lid_raised && getDoorPosition() == door_closed )
    {
        performanceData.blockTest.state = blockTestState_Setting;
    }
    else
    {
        performanceData.blockTest.state = blockTestState_WaitingOnCavity;

        if( getLidPosition() != lid_raised )
        {
            raiseLid( blockPerformanceTestCallback, 0 );
        }
        else
        {
            closeDoor( blockPerformanceTestCallback, 0 );
        }

        startTimer(&performanceData.blockTest.timer,
                   MSEC_TO_TICKS(maxCavityWaitTime_ms));
    }
}

static void blockTestState_WaitingOnCavity( void )
{
    if(timerExpired(&performanceData.blockTest.timer))
    {
        performanceData.errorDesc[ 0 ] = '\0';
        performanceData.error =
            getLidPosition() == lid_raised ? err_doorCloseFailure :
                                             err_lidRaiseFailure;

        // Go ahead and kill the tests if the mechanics won't cooperate.
        if( performanceData.blockTest.state == blockTestState_WaitingOnCavity )
        {
            performanceData.lidThermalTest.state   = NULL;
            performanceData.illuminationTest.state = NULL;
            performanceData.heatsinkFanTest.state  = NULL;
        }
        performanceData.blockTest.state = blockTestState_Completed;
    }
}

static void blockTestState_Setting( void )
{
    ThermalTest *testPtr = &performanceData.blockTest;
    const uint32 maxRampTime_ms = testPtr->direction == cool ? 40000 : 90000;

    // Now that cavity is in place, we can start the lid test.
    if(performanceData.lidThermalTest.state == lidThermalTestState_Starting)
    {
        scheduleTask(runPerformanceTestTask,
                     &performanceData.lidThermalTest.state, false);
    }

    if( getPerformanceTarget( block, testPtr->direction, &testPtr->targetTemp ) )
    {
        testPtr->state = blockTestState_Ramping;
        setTargetTemp(ALL_BLOCK_CHANNELS, testPtr->targetTemp,
                      blockPerformanceTestCallback, 0);
        startTimer(&testPtr->timer, MSEC_TO_TICKS(maxRampTime_ms));
    }
    else
    {
        sendInfoStatus(TestDevice_BlockThermal,
                       err_performanceTestComponentBadBaseline, NULL);
        testPtr->state = blockTestState_Completed;
    }
}

static void blockTestState_Ramping( void )
{
    if(timerExpired(&performanceData.blockTest.timer))
    {
        sendInfoStatus(TestDevice_BlockThermal,
                       err_performanceTestComponentFailure,
                       "Timed out waiting to reach target temp");
        performanceData.blockTest.state = blockTestState_Completed;
    }
}

static void blockTestState_Checking( void )
{
    ThermalTest *testPtr = &performanceData.blockTest;
    TestResults *resultsPtr =
        &performanceData.blockTestResults[testPtr->channel][testPtr->direction];

    if(timerExpired(&testPtr->timer))
    {
        int status;
        int ( *checkFunctionPtr )( int, ThermalDirection, TestResults * ) =
            performanceData.baseline ? &setDriveBaseline :
                                       &testDriveEffort;

        // Only check one channel per invocation to allow other tasks to run.
        if( testPtr->channel < BLOCK_CHANNEL_COUNT )
        {
            status = checkFunctionPtr(FIRST_BLOCK_CHANNEL + testPtr->channel++,
                                      testPtr->direction, resultsPtr);

            if( status < testPtr->status )
            {
                testPtr->status = status;
            }
        }

        if( testPtr->channel >= BLOCK_CHANNEL_COUNT )
        {
            if( testPtr->direction == cool )
            {
                testPtr->direction = heat;
                testPtr->error     = err_blockHeatingTestFailure;
                testPtr->state     = blockTestState_Setting;
            }
            else
            {
                int  channel;
                char resultString[ 1024 ];
                char *resultStringPtr = &resultString[ 0 ];

                for( channel = 0; channel < BLOCK_CHANNEL_COUNT; ++channel )
                {
                    int direction;

                    sprintf( resultStringPtr, "%s:",
                             getSensorName( FIRST_BLOCK_CHANNEL + channel ) );
                    resultStringPtr += strlen( resultStringPtr );

                    for( direction = cool; direction < numDirections; ++direction )
                    {
                        TestResults *resultPtr =
                            &performanceData.blockTestResults[ channel ][ direction ];

                        sprintf( resultStringPtr, "%d.%d,%d.%d,",
                                 resultPtr->baseline/10, abs( resultPtr->baseline%10 ),
                                 resultPtr->delta/10, abs( resultPtr->delta%10 ) );

                        resultStringPtr += strlen( resultStringPtr );
                    }

                    *--resultStringPtr = ' ';
                    ++resultStringPtr;
                }

                *--resultStringPtr = '\0';

                sendInfoStatus(TestDevice_BlockThermal,
                               statusToError(testPtr->status), resultString);

                testPtr->state = blockTestState_Completed;
            }
        }
    }
}

static void blockTestState_Completed( void )
{
    resetTempControl(ALL_BLOCK_CHANNELS);
    performanceData.blockTest.state = NULL;
    scheduleTask(runPerformanceTestTask,
                 &performanceData.heatsinkFanTest.state, false);
    completeTest();
}

static void blockPerformanceTestCallback(int reference, ErrorCodes error,
                                         const char* errorDesc)
{
    const uint32 holdTime_ms = 10000;

    if(error != err_noError)
    {
        // Go ahead and kill the tests if the mechanics won't cooperate.
        if( performanceData.blockTest.state == blockTestState_WaitingOnCavity )
        {
            performanceData.lidThermalTest.state   = NULL;
            performanceData.illuminationTest.state = NULL;
            performanceData.heatsinkFanTest.state  = NULL;

            performanceData.error = 
                getLidPosition() == lid_raised ? err_doorCloseFailure :
                                                 err_lidRaiseFailure;
            strcpy( performanceData.errorDesc, errorDesc );
            performanceData.blockTest.state = blockTestState_Completed;
        }
        else
        {
            sendInfoStatus(TestDevice_BlockThermal,
                           err_performanceTestComponentFailure, errorDesc);
            performanceData.blockTest.state = blockTestState_Completed;
        }
    }
    else if( performanceData.blockTest.state == blockTestState_Ramping )
    {
        performanceData.blockTest.channel = 0;
        performanceData.blockTest.state   = blockTestState_Checking;
        startTimer(&performanceData.blockTest.timer, MSEC_TO_TICKS(holdTime_ms));
    }
    else if( performanceData.blockTest.state == blockTestState_WaitingOnCavity )
    {
        performanceData.blockTest.state = blockTestState_Setting;
    }
}


///////////////////////////////////////////////////
// Lid Thermal Test

static void lidThermalTestState_Starting( void )
{
    puts("Testing Lid");

    if( performanceData.baseline )
    {
        setPerformanceTargetDelta( lid, heat,
                                   defaultThermalPerformanceTargetDelta[ lid ][ heat ] );
    }

    resetTempControl(ALL_LID_CHANNELS);
    performanceData.lidThermalTest.state = lidThermalTestState_Setting;
}

static void lidThermalTestState_Setting( void )
{
    const uint64 maxHeatRampTime_ms = 135000;

    if( getPerformanceTarget( lid, heat,
                              &performanceData.lidThermalTest.targetTemp ) )
    {
        performanceData.lidThermalTest.state = lidThermalTestState_Ramping;
        setTargetTemp(ALL_LID_CHANNELS, performanceData.lidThermalTest.targetTemp,
                      lidPerformanceTestCallback, 0);
        startTimer(&performanceData.lidThermalTest.timer,
                   MSEC_TO_TICKS(maxHeatRampTime_ms));
    }
    else
    {
        sendInfoStatus(TestDevice_LidThermal,
                       err_performanceTestComponentBadBaseline, NULL);
        performanceData.lidThermalTest.state = lidThermalTestState_Completed;
    }
}

static void lidThermalTestState_Ramping( void )
{
    if(timerExpired(&performanceData.lidThermalTest.timer))
    {
        sendInfoStatus(TestDevice_LidThermal,
                       err_performanceTestComponentFailure,
                       "Timed out waiting to reach target temp");
        performanceData.lidThermalTest.state = lidThermalTestState_Completed;
    }
}

static void lidThermalTestState_Checking( void )
{
    if(timerExpired(&performanceData.lidThermalTest.timer))
    {
        int  status;
        int  channel;
        int ( *checkFunctionPtr )( int, ThermalDirection, TestResults * ) =
            performanceData.baseline ? &setDriveBaseline :
                                       &testDriveEffort;

        char resultString[ 1024 ];
        char *resultStringPtr = &resultString[ 0 ];

        for(channel = 0; channel < LID_CHANNEL_COUNT; channel++)
        {
            TestResults *resultPtr = &performanceData.lidTestResults[ channel ];

            status = checkFunctionPtr(FIRST_LID_CHANNEL + channel,
                                      heat, resultPtr);

            if( status < performanceData.lidThermalTest.status )
            {
                performanceData.lidThermalTest.status = status;
            }

            sprintf( resultStringPtr, "%s:%d.%d,%d.%d ",
                     getSensorName( FIRST_LID_CHANNEL + channel ),
                     resultPtr->baseline/10, abs( resultPtr->baseline%10 ),
                     resultPtr->delta/10, abs( resultPtr->delta%10 ) );

            resultStringPtr += strlen( resultStringPtr );
        }

        *--resultStringPtr = '\0';

        sendInfoStatus(TestDevice_LidThermal,
                       statusToError(performanceData.lidThermalTest.status),
                       resultString);

        performanceData.lidThermalTest.state = lidThermalTestState_Completed;
    }
}

static void lidThermalTestState_Completed( void )
{
    resetTempControl(ALL_LID_CHANNELS);
    performanceData.lidThermalTest.state = NULL;
    completeTest();
}


static void lidPerformanceTestCallback(int reference, ErrorCodes error,
                                       const char* errorDesc)
{
    const uint32 heatHoldTime_ms = 30000;

    if(error != err_noError)
    {
        sendInfoStatus(TestDevice_LidThermal,
                       err_performanceTestComponentFailure, errorDesc);
        performanceData.lidThermalTest.state = lidThermalTestState_Completed;
    }
    else if( performanceData.lidThermalTest.state == lidThermalTestState_Ramping )
    {
        performanceData.lidThermalTest.state = lidThermalTestState_Checking;
        startTimer(&performanceData.lidThermalTest.timer,
                   MSEC_TO_TICKS(heatHoldTime_ms));
    }
}


///////////////////////////////////////////////////
// Illumination Test

static void illuminationTestState_Starting( void )
{
    puts("Testing Illumination");

    turnOffIllumination(ALL_ILLUMINATION);

    performanceData.illuminationTest.color =
        iterateIllumination( NO_ILLUMINATION );
    performanceData.illuminationTest.device =
        illuminationToDevice( performanceData.illuminationTest.color );

    if( getLidPosition() == lid_lowered )
    {
        performanceData.illuminationTest.state = illuminationTestState_TestStart;
    }
    else
    {
        performanceData.illuminationTest.state =
            illuminationTestState_WaitingOnCavityClose;
        lowerLid(illuminationPerformanceTestCallback, 0);
        startTimer(&performanceData.illuminationTest.timer,
                   MSEC_TO_TICKS(maxCavityWaitTime_ms));
    }
}

static void illuminationTestState_WaitingOnCavityClose( void )
{
    if(timerExpired(&performanceData.illuminationTest.timer))
    {
        performanceData.error = err_lidLowerFailure;
        strcpy( performanceData.errorDesc, "Timed out waiting for cavity" );
        performanceData.illuminationTest.state = illuminationTestState_Completed;
    }
}

static void illuminationTestState_TestStart( void )
{
    const uint32 settleTime_ms = 1000;

    turnOnIllumination(performanceData.illuminationTest.color, false, NULL, 0);
    performanceData.illuminationTest.state = illuminationTestState_TestCheck;
    startTimer(&performanceData.illuminationTest.timer,
               MSEC_TO_TICKS(settleTime_ms));
}

static void illuminationTestState_TestCheck( void )
{
    IlluminationTest *testPtr = &performanceData.illuminationTest;

    if(timerExpired(&testPtr->timer))
    {
        int status = illuminationPerformanceVerifyLED(testPtr->color,
                                                      testPtr->device);

        if( status < testPtr->status )
        {
            testPtr->status = status;
        }

        testPtr->color = iterateIllumination( testPtr->color );

        if( testPtr->color == NO_ILLUMINATION )
        {
            testPtr->state = illuminationTestState_Finishing;
        }
        else
        {
            testPtr->device = illuminationToDevice( testPtr->color );
            testPtr->state  = illuminationTestState_TestStart;
        }
    }
}

static void illuminationTestState_Finishing( void )
{
    puts("Finishing");

    performanceData.illuminationTest.state =
        illuminationTestState_WaitingOnCavityOpen;
    openCavity(illuminationPerformanceTestCallback, 0);
    startTimer(&performanceData.illuminationTest.timer,
               MSEC_TO_TICKS(maxCavityWaitTime_ms));
}

static void illuminationTestState_WaitingOnCavityOpen( void )
{
    if(timerExpired(&performanceData.illuminationTest.timer))
    {
        performanceData.error =
            getLidPosition() == lid_raised ? err_doorOpenFailure :
                                             err_lidRaiseFailure;
        strcpy( performanceData.errorDesc, "Timed out waiting for cavity" );
        performanceData.illuminationTest.state = illuminationTestState_Completed;
    }
}

static void illuminationTestState_Completed( void )
{
    performanceData.illuminationTest.state = NULL;
    completeTest();
}

static void illuminationPerformanceTestCallback(int reference, ErrorCodes error,
                                                const char* errorDesc)
{
    if(error != err_noError)
    {
        if( performanceData.illuminationTest.state ==
            illuminationTestState_WaitingOnCavityClose )
        {
            performanceData.error = err_lidLowerFailure;
        }
        else if( getLidPosition() == lid_raised )
        {
            performanceData.error = err_doorOpenFailure;
        }
        else
        {
            performanceData.error = err_lidRaiseFailure;
        }

        strcpy( performanceData.errorDesc, errorDesc );
        performanceData.illuminationTest.state = illuminationTestState_Completed;
    }
    else if( performanceData.illuminationTest.state ==
             illuminationTestState_WaitingOnCavityClose )
    {
        performanceData.illuminationTest.state = illuminationTestState_TestStart;
    }
    else if( performanceData.illuminationTest.state ==
             illuminationTestState_WaitingOnCavityOpen )
    {
        performanceData.illuminationTest.state = illuminationTestState_Completed;
    }
}

static IlluminationColor iterateIllumination( IlluminationColor color )
{
    switch( color )
    {
    case NO_ILLUMINATION:
        color = BLUE_ILLUMINATION;
        break;

    case BLUE_ILLUMINATION:
        color = GREEN_ILLUMINATION;
        break;

    case GREEN_ILLUMINATION:
        color = ORANGE_ILLUMINATION;
        break;

    case ORANGE_ILLUMINATION:
        color = RED_ILLUMINATION;
        break;

    case RED_ILLUMINATION:
        color = CRIMSON_ILLUMINATION;
        break;

    case CRIMSON_ILLUMINATION:
        color = NO_ILLUMINATION;
        break;

    default:
        ASSERT(false);
        break;
    }

    return color;
}

static TestDevices illuminationToDevice( IlluminationColor color )
{
    TestDevices device;

    switch( color )
    {
    case BLUE_ILLUMINATION:
        device = TestDevice_IlluminationBlue;
        break;

    case GREEN_ILLUMINATION:
        device = TestDevice_IlluminationGreen;
        break;

    case ORANGE_ILLUMINATION:
        device = TestDevice_IlluminationOrange;
        break;

    case RED_ILLUMINATION:
        device = TestDevice_IlluminationRed;
        break;

    case CRIMSON_ILLUMINATION:
        device = TestDevice_IlluminationCrimson;
        break;

    default:
        ASSERT(false);
        break;
    }

    return device;
}


static int illuminationPerformanceVerifyLED(IlluminationColor color,
                                            TestDevices device)
{
    int        status;
    char       resultString[ STATUS_DESC_SIZE ];
    uint16     calibration;
    uint16     primaryFeedback;
    float      percentDelta = 0;
    ErrorCodes error;

    primaryFeedback = getIlluminationFeedback(true);
    turnOffIllumination( ALL_ILLUMINATION );

    if( !getIlluminationCalibration( color, &calibration ) )
    {
        status = BAD_BASELINE;
        error  = err_ledNotCalibrated;
    }
    else
    {
        percentDelta = 100.0 * fabs( (float)1.0 - ( float )primaryFeedback /
                                                  ( float )calibration );

        if( percentDelta >= ledLimits.failed )
        {
            status = FAILED;
        }
        else if( percentDelta >= ledLimits.major )
        {
            status = MAJOR;
        }
        else if( percentDelta >= ledLimits.minor )
        {
            status = MINOR;
        }
        else
        {
            status = NONE;
        }

        error = statusToError(status);
    }

    sprintf( resultString, "%u,%0.1f", calibration, percentDelta );

    sendInfoStatus( device, error, resultString );

    return status;
}


///////////////////////////////////////////////////
// Fan Test

static void fanTestState_Starting( void )
{
    const int dutyCycle      = 500;
    const int startupTime_ms = 10000;

    puts("Testing Fan");

    performanceData.heatsinkFanTest.slowCount = 0;
    performanceData.heatsinkFanTest.maxRPM    = 0;
    performanceData.heatsinkFanTest.state     = fanTestState_Checking;
    setFanDutyCycle(FAN_BLOCK, dutyCycle);
    startTimer(&performanceData.heatsinkFanTest.timer,
               MSEC_TO_TICKS(startupTime_ms));
}

static void fanTestState_Checking( void )
{
    if(timerExpired(&performanceData.heatsinkFanTest.timer))
    {
        const int maxSlowCount = 5;
        const int retryTicks   = SEC_TO_TICKS(1);

        char resultString[ STATUS_DESC_SIZE ];
        int  fanRPM = getFanRPM(FAN_BLOCK);

        if(fanRPM > performanceData.heatsinkFanTest.maxRPM)
        {
            performanceData.heatsinkFanTest.maxRPM = fanRPM;
        }

        if(performanceData.heatsinkFanTest.maxRPM < heatsinkFanLimits.minor &&
           ++performanceData.heatsinkFanTest.slowCount < maxSlowCount)
        {
            startTimer(&performanceData.heatsinkFanTest.timer, retryTicks);
            return;
        }

        if(performanceData.heatsinkFanTest.maxRPM < heatsinkFanLimits.failed)
        {
            performanceData.heatsinkFanTest.status = FAILED;
        }
        else if(performanceData.heatsinkFanTest.maxRPM < heatsinkFanLimits.major)
        {
            performanceData.heatsinkFanTest.status = MAJOR;
        }
        else if(performanceData.heatsinkFanTest.maxRPM < heatsinkFanLimits.minor)
        {
            performanceData.heatsinkFanTest.status = MINOR;
        }
        else
        {
            performanceData.heatsinkFanTest.status = NONE;
        }

        sprintf(resultString, "%u", performanceData.heatsinkFanTest.maxRPM);

        sendInfoStatus(TestDevice_HeatsinkFan,
                       statusToError(performanceData.heatsinkFanTest.status),
                       resultString);

        performanceData.heatsinkFanTest.state = NULL;
        completeTest();
    }
}
