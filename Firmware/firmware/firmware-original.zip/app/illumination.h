/////////////////////////////////////////////////////////////
//
//  illumination.h
//
//  Illumination LED driver
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef illumination_h
#define illumination_h


#include <types.h>
#include <comm.h>

typedef enum
{
    NO_ILLUMINATION      = 0x00,

    BLUE_ILLUMINATION    = 0x01,
    GREEN_ILLUMINATION   = 0x02,
    ORANGE_ILLUMINATION  = 0x04,
    RED_ILLUMINATION     = 0x08,
    CRIMSON_ILLUMINATION = 0x10,
    
    ALL_ILLUMINATION     = 0x1F,
} IlluminationColor;


typedef enum
{
    proportional_gain,
    integral_gain,
    derivative_gain,
    feed_forward_scale,
    feed_forward_offset
} pid_gain_type;



const char* getIlluminationName(IlluminationColor color);

void   illuminationInit();
void   illuminationStart();
void   illuminationStop();
void   illuminationAbort();

void   turnOnIllumination(IlluminationColor color, bool oneAmp,
                          OfflineTaskCompleteCallback callbackFunc, int callbackRef);
void   turnOffIllumination(IlluminationColor color);

bool   getIllumination(IlluminationColor color);

void   setLedStreaming( bool stream );

uint16 getIlluminationCurrent(IlluminationColor color);
bool   setIlluminationCalibration( IlluminationColor color, uint16 calibration );
bool   calibrateIllumination( void );
bool   getIlluminationCalibration( IlluminationColor color, uint16 *calibration );
bool   setOneAmpIlluminationCalibration( IlluminationColor color, uint16 calibration );
bool   getOneAmpIlluminationCalibration( IlluminationColor color, uint16 *calibration );
uint16 getIlluminationFeedback( bool primary );
void   toggleIlluminationControl( bool closedLoop );
void   setIlluminationPidGain( IlluminationColor color,
                               pid_gain_type which_gain, float new_gain );
float  getIlluminationPidGain( IlluminationColor color, pid_gain_type which_gain );
void   transitionIllumination( bool lidIsLowered );

float  getIlluminationIntensity( IlluminationColor color );
void   setIlluminationIntensity( IlluminationColor color, float intensity );
void   restoreIlluminationIntensity( void );

void   illuminationNVWriteAllCRCs( void );


//! \todo: Temporarily public to allow the user to set the power level.
/* static */ void   setCalibratedPower(IlluminationColor color, uint16 power);
/* static */ uint16 getCalibratedPower(IlluminationColor color);

#endif
