/////////////////////////////////////////////////////////////
//
//  fixedPoint.c
//
//  Fixed-Point Number Utility Functions
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#include <fixedPoint.h>
#include <assert.h>


///////////////////////////////////////////////////
// Utility Functions

FixedPointInt separateFixedPoint(int fixedPointNumber, int decimalPlaces)
{
    ASSERT(decimalPlaces >= 0 && decimalPlaces < 32);

    FixedPointInt fp;
    
    int power = 1;
    
    int i;
    for(i = 0; i < decimalPlaces; i++)
    {
        power *= 10;
    }
    
    fp.wholePart = fixedPointNumber / power;
    
    fp.fractionalPart = (fixedPointNumber < 0) ? (fixedPointNumber * -1) % power : fixedPointNumber % power;
    
    return fp;
}



// EOF
