/////////////////////////////////////////////////////////////
//
//  version.h
//
//  Bootloader Firmware Version defines
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef version_h
#define version_h


#define FW_VER "2.7"


#endif
