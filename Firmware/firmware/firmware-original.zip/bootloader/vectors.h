/////////////////////////////////////////////////////////////
//
//  vectors.h
//
//  Exception Vectors utility functions
//
//  Copyright 2009 Idaho Technology
//  Created by Brett Gilbert

#ifndef vectors_h
#define vectors_h


void loadExceptionVectors();


#endif
